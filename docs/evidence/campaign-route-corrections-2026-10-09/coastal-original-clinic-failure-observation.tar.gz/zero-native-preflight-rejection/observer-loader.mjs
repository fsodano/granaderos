import {registerHooks} from 'node:module';
import {readFileSync,writeFileSync,appendFileSync,mkdirSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const out="/tmp/granaderos-coastal-hired-first-aid-observer-20261010-_g3z67xg",repo="/Users/fsodano/.codex/worktrees/blast-structures/granaderos",sha=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(process.execPath,'/opt/homebrew/Cellar/node/25.9.0_2/bin/node');
assert.ok(!process.env.NODE_OPTIONS,'Undeclared Node hooks are forbidden');
const hooks=process.execArgv.flatMap((arg,index)=>arg==='--import'?[process.execArgv[index+1]]:arg.startsWith('--import=')?[arg.slice(9)]:[]);
assert.deepEqual(hooks,[out+'/observer-loader.mjs'],'Only the reviewed observation preload is allowed');
assert.ok(!process.execArgv.some(arg=>arg==='-r'||arg.startsWith('--require')||arg.startsWith('--loader')||arg.startsWith('--experimental-loader')),'Undeclared source loaders are forbidden');
const preparedRaw=readFileSync(out+'/preparation.json'),preparedSha=sha(preparedRaw);assert.equal(preparedSha,process.env.GRANADEROS_COASTAL_OBSERVER_PREPARATION_SHA,'Observer preparation changed');
const prepared=JSON.parse(preparedRaw),bindings=Object.entries(prepared.files).map(([name,proof])=>{const bytes=readFileSync(out+'/'+name);assert.equal(sha(bytes),proof.sha256,'External observer binding changed: '+name);assert.equal(bytes.length,proof.bytes);return {name,...proof};});
const manifest=JSON.parse(readFileSync(out+'/full942-before-source-hashes.json'));assert.equal(manifest['tests/fresh-coastal-fixture.mjs'],'a2ebef6cad6237d78bbafdae5b839687645fd1098a8623a7ab332b71a660511d');
const launchPath=out+'/launch.lock';if(!existsSync(launchPath))writeFileSync(launchPath,JSON.stringify({pid:process.pid,ppid:process.ppid,preparationSha256:preparedSha})+'\n',{flag:'wx'});else{const launch=JSON.parse(readFileSync(launchPath));assert.equal(launch.preparationSha256,preparedSha);assert.ok(launch.pid===process.ppid,'This unique observer directory was already launched');}
const processOut=out+'/process-'+process.pid;mkdirSync(processOut);writeFileSync(processOut+'/entry.json',JSON.stringify({pid:process.pid,ppid:process.ppid,runtime:process.execPath,nodeVersion:process.version,args:process.argv,execArgv:process.execArgv,preparationSha256:preparedSha,externalFiles:bindings})+'\n',{flag:'wx'});
const rows=[];
function transform(source){
 const changes=[
  ["import {takeFiniteCache,leaveFiniteCache} from './finite-cache-driver.mjs';", "import {coastalObserve,coastalObserveOrder} from "+JSON.stringify(out+'/observer-capture.mjs')+";\nimport {takeFiniteCache,leaveFiniteCache} from './finite-cache-driver.mjs';"],
  ["const tactical=(p,a)=>{const battle=a.type==='endTurn'?endTurn(p.battle):actBattle(p.battle,a);assert.equal(battle.lastError,null,battle.lastError);return sync({campaign:p.campaign,battle});};", "const tactical=(p,a)=>{const battle=a.type==='endTurn'?endTurn(p.battle):actBattle(p.battle,a);assert.equal(battle.lastError,null,battle.lastError);const result=sync({campaign:p.campaign,battle});coastalObserveOrder(p,a,result);return result;};"],
  ["  const {battle,orders,actions}=engage(request,previous,", "  coastalObserve('before-existing-battle',{kind,sector,campaign:s,request,previous});\n  const {battle,orders,actions}=engage(request,previous,"],
  ["onBattleFinished?.({sector,battle,orders,actions});assert.equal(battle.status,'victory'", "coastalObserve('after-existing-battle',{kind,sector,campaign:s,request,previous,battle,orders,actions});onBattleFinished?.({sector,battle,orders,actions});assert.equal(battle.status,'victory'"],
  ["  for(const actor of p.battle.units.filter(u=>u.side==='player'&&u.hp>0&&!u.routed&&!u.unconscious).sort((a,b)=>a.hp-b.hp)){", "  coastalObserve('before-existing-one-stroke-aid',{kind,sector,pair:p});\n  for(const actor of p.battle.units.filter(u=>u.side==='player'&&u.hp>0&&!u.routed&&!u.unconscious).sort((a,b)=>a.hp-b.hp)){"],
  ["  p=saved(p);const resultReport={type:'battleResult'", "  coastalObserve('after-existing-one-stroke-aid',{kind,sector,pair:p});\n  p=saved(p);const resultReport={type:'battleResult'"],
  ["    if(auxiliary!==undefined){for(const id of field){assert.ok(s.operativeState[id].hp>=15&&!s.operativeState[id].bleeding,'stabilize the actual clinic patients before waiting for a physician');", "    coastalObserve('before-unchanged-clinic-admission',{kind,sector,campaign:s,field,clinic,fieldSquad,auxiliary,hires,arrivals,quotes});\n    if(auxiliary!==undefined){for(const id of field){assert.ok(s.operativeState[id].hp>=15&&!s.operativeState[id].bleeding,'stabilize the actual clinic patients before waiting for a physician');"]
 ];
 for(const [from,to]of changes){assert.equal(source.split(from).length-1,1,'Observer anchor changed');source=source.replace(from,to);}return source;
}
registerHooks({load(url,context,nextLoad){
 const result=nextLoad(url,context);if(!url.startsWith('file:')||result.source==null)return result;
 const path=fileURLToPath(url),original=readFileSync(path),originalSha=sha(original),runtimeBytes=typeof result.source==='string'?Buffer.from(result.source):Buffer.from(result.source);
 if(path.startsWith(repo+'/')){
  const relative=path.slice(repo.length+1);assert.equal(originalSha,manifest[relative],'Original imported source differs from full942: '+relative);assert.equal(sha(runtimeBytes),originalSha,'Undeclared prior runtime transform: '+relative);
  let source=runtimeBytes;if(relative==='tests/fresh-coastal-fixture.mjs')source=Buffer.from(transform(source.toString('utf8')));if(relative==='tests/fresh-coastal-fixture.mjs')assert.equal(sha(source),prepared.files['fresh-coastal-fixture.runtime.mjs'].sha256,'Declared observation transform changed');
  const row={url,path:relative,absolutePath:path,external:false,originalSha256:originalSha,runtimeSha256:sha(source),declaredObservationTransform:relative==='tests/fresh-coastal-fixture.mjs',bytes:source.length};rows.push(row);appendFileSync(processOut+'/imports.jsonl',JSON.stringify(row)+'\n');return {...result,source};
 }
 if(path.startsWith(out+'/')){
  const name=path.slice(out.length+1);assert.ok(prepared.files[name],'Undeclared external module: '+name);assert.equal(originalSha,prepared.files[name].sha256);assert.equal(sha(runtimeBytes),originalSha,'External module runtime changed');const row={url,path:name,absolutePath:path,external:true,originalSha256:originalSha,runtimeSha256:originalSha,bytes:original.length};rows.push(row);appendFileSync(processOut+'/imports.jsonl',JSON.stringify(row)+'\n');return result;
 }
 throw Error('Unbound external module: '+path);
}});
process.on('exit',code=>{
 const drift=[];for(const row of rows){const finalSha=sha(readFileSync(row.absolutePath));row.finalSha256=finalSha;if(finalSha!==row.originalSha256)drift.push(row);}
 const externalDrift=[];for(const row of bindings){const bytes=readFileSync(out+'/'+row.name);if(sha(bytes)!==row.sha256||bytes.length!==row.bytes)externalDrift.push(row.name);}
 const finalPrepSha=sha(readFileSync(out+'/preparation.json'));if(finalPrepSha!==preparedSha)externalDrift.push('preparation.json');
 const runtimeDifferences=rows.filter(row=>row.originalSha256!==row.runtimeSha256&&!row.declaredObservationTransform);
 writeFileSync(processOut+'/closure.json',JSON.stringify({pid:process.pid,exitCode:code,actualModuleLoads:rows.length,preparedEntrySha256:preparedSha,preparedFinalSha256:finalPrepSha,sourceDrift:drift,externalDrift,undeclaredRuntimeDifferences:runtimeDifferences,declaredTransforms:rows.filter(row=>row.declaredObservationTransform),records:rows},null,2)+'\n',{flag:'wx'});if(drift.length||externalDrift.length||runtimeDifferences.length)process.exitCode=1;
});
