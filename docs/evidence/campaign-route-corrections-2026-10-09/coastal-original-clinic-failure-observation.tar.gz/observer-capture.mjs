import assert from 'node:assert/strict';
import {writeFileSync,appendFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const out="/tmp/granaderos-coastal-hired-first-aid-observer-fixed-20261010-fde248wf"+'/process-'+process.pid,sha=value=>createHash('sha256').update(value).digest('hex');let event=0,order=0;
export function coastalObserve(name,value){
 const before=JSON.stringify(value),copy=structuredClone(value),raw=JSON.stringify(copy);assert.equal(JSON.stringify(value),before,'Passive capture changed an existing value');assert.deepEqual(copy,value);
 const filename=String(++event).padStart(3,'0')+'-'+name+'.json.gz',bytes=gzipSync(raw,{mtime:0});writeFileSync(out+'/'+filename,bytes,{flag:'wx'});appendFileSync(out+'/captures.jsonl',JSON.stringify({event,name,path:filename,rawSha256:sha(raw),gzipSha256:sha(bytes),rawBytes:Buffer.byteLength(raw),gzipBytes:bytes.length,inputUnchanged:true})+'\n');
}
export function coastalObserveOrder(before,action,after){
 const actor=pair=>pair.battle.units.find(unit=>unit.id===action.unitId),summary=unit=>unit?{id:unit.id,hp:unit.hp,bleeding:unit.bleeding,medkits:unit.medkits,ap:unit.ap,energy:unit.energy,activeSlot:unit.activeSlot}:null;
 appendFileSync(out+'/actual-tactical-orders.jsonl',JSON.stringify({index:order++,action:structuredClone(action),actorBefore:summary(actor(before)),actorAfter:summary(actor(after)),elapsedBefore:before.battle.elapsedSeconds,elapsedAfter:after.battle.elapsedSeconds,lastError:after.battle.lastError})+'\n');
}
