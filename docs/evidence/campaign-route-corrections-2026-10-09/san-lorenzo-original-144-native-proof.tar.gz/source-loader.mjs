import {registerHooks} from 'node:module';
import {readFileSync,writeFileSync,appendFileSync,mkdirSync,realpathSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const sha=b=>createHash('sha256').update(b).digest('hex'),out=realpathSync(fileURLToPath(new URL('.',import.meta.url))),repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos';
assert.equal(process.execPath,'/opt/homebrew/Cellar/node/25.9.0_2/bin/node');assert.ok(!process.env.NODE_OPTIONS,'Undeclared Node hooks are forbidden');
const hooks=process.execArgv.flatMap((a,i)=>a==='--import'?[process.execArgv[i+1]]:a.startsWith('--import=')?[a.slice(9)]:[]);
assert.deepEqual(hooks.map(p=>realpathSync(p)),[realpathSync(out+'/source-loader.mjs')]);
assert.ok(!process.execArgv.some(a=>a==='-r'||a.startsWith('--require')||a.startsWith('--loader')||a.startsWith('--experimental-loader')));
const prepRaw=readFileSync(out+'/preparation.json'),prepSha=sha(prepRaw);assert.equal(prepSha,process.env.GRANADEROS_SANL_ORIGINAL_REPLAY_PREPARATION_SHA);const prep=JSON.parse(prepRaw);
assert.equal(prep.ordersAuthorized,144);assert.equal(prep.alternativeActionsAuthorized,0);
for(const [path,row]of Object.entries(prep.files)){const b=readFileSync(out+'/'+path);assert.equal(sha(b),row.sha256,path);assert.equal(b.length,row.bytes,path);}
const sources=JSON.parse(readFileSync(out+'/current-production-source-hashes.json'));
for(const [path,h]of Object.entries(sources))assert.equal(sha(readFileSync(repo+'/'+path)),h,'Entry production drift: '+path);
writeFileSync(out+'/launch.lock',JSON.stringify({pid:process.pid,ppid:process.ppid,preparationSha256:prepSha})+'\n',{flag:'wx'});
const results=out+'/result';mkdirSync(results);writeFileSync(results+'/entry.json',JSON.stringify({pid:process.pid,ppid:process.ppid,runtime:process.execPath,version:process.version,args:process.argv,execArgv:process.execArgv,preparationSha256:prepSha})+'\n',{flag:'wx'});
const rows=[];
registerHooks({load(url,context,nextLoad){const loaded=nextLoad(url,context);if(!url.startsWith('file:')||loaded.source==null)return loaded;const path=realpathSync(fileURLToPath(url)),raw=readFileSync(path),original=sha(raw),runtime=sha(Buffer.from(loaded.source));
 assert.equal(original,runtime,'Undeclared runtime transform: '+path);
 if(path.startsWith(repo+'/')){const relative=path.slice(repo.length+1);assert.ok(sources[relative],'Unbound production module: '+relative);assert.equal(original,sources[relative],'Imported production drift: '+relative);rows.push({path:relative,absolutePath:path,external:false,originalSha256:original,runtimeSha256:runtime,bytes:raw.length});}
 else if(path.startsWith(out+'/')){const relative=path.slice(out.length+1);assert.ok(prep.files[relative],'Unbound external module: '+relative);assert.equal(original,prep.files[relative].sha256);rows.push({path:relative,absolutePath:path,external:true,originalSha256:original,runtimeSha256:runtime,bytes:raw.length});}
 else throw Error('Unbound external module: '+path);
 appendFileSync(results+'/imports.jsonl',JSON.stringify(rows.at(-1))+'\n');return loaded;
}});
process.on('exit',code=>{const sourceDrift=[],externalDrift=[];for(const row of rows){row.finalSha256=sha(readFileSync(row.absolutePath));if(row.finalSha256!==row.originalSha256)(row.external?externalDrift:sourceDrift).push(row);}
 for(const [path,h]of Object.entries(sources))if(sha(readFileSync(repo+'/'+path))!==h)sourceDrift.push({path,manifestSourceChanged:true});
 for(const [path,row]of Object.entries(prep.files)){const b=readFileSync(out+'/'+path);if(sha(b)!==row.sha256||b.length!==row.bytes)externalDrift.push({path});}
 if(sha(readFileSync(out+'/preparation.json'))!==prepSha)externalDrift.push({path:'preparation.json'});
 const undeclaredRuntimeDifferences=rows.filter(r=>r.originalSha256!==r.runtimeSha256);
 writeFileSync(results+'/source-closure.json',JSON.stringify({pid:process.pid,exitCode:code,imports:rows.length,entryPreparationSha256:prepSha,finalPreparationSha256:sha(readFileSync(out+'/preparation.json')),sourceDrift,externalDrift,undeclaredRuntimeDifferences,records:rows},null,2)+'\n',{flag:'wx'});
 if(sourceDrift.length||externalDrift.length||undeclaredRuntimeDifferences.length)process.exitCode=1;
});
