import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos',out='/tmp/granaderos-full942-salta-exhausted-gun-forensics-20261010',full='/tmp/granaderos-campaign-final-posture-full-2026-10-10T040806965Z',sha=value=>createHash('sha256').update(value).digest('hex'),jsonSha=value=>sha(JSON.stringify(value)),write=(name,value)=>writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n');
// All simulation remains gated. Preparing/parsing this script does not run it.
assert.equal(process.execPath,'/opt/homebrew/Cellar/node/25.9.0_2/bin/node');
assert.ok(process.argv.includes('--root-terminal-confirmed'),'Root must first confirm session33195 terminal');
assert.ok(existsSync(full+'/final-receipt.json'),'Full942 is not terminal');
const finalGate=JSON.parse(readFileSync(full+'/final-receipt.json','utf8'));assert.equal(finalGate.complete,true);assert.deepEqual(finalGate.sourceDrift,[]);
const prepRaw=readFileSync(out+'/bounded-script-preparation.json'),prepShaArgument=process.argv.find(argument=>argument.startsWith('--preparation-sha256='))?.slice('--preparation-sha256='.length);
assert.equal(sha(prepRaw),prepShaArgument,'Prepared observer receipt changed');
const prep=JSON.parse(prepRaw);for(const [name,proof] of Object.entries(prep.files)){const bytes=readFileSync(out+'/'+name);assert.equal(sha(bytes),proof.sha256,'Prepared external file changed: '+name);assert.equal(bytes.length,proof.bytes);}
assert.ok(existsSync(out+'/bounded-run.lock'),'Observer loader did not acquire the first-launch lock');

const manifest=JSON.parse(readFileSync(full+'/before-source-hashes.json','utf8'));
const rawInput=gunzipSync(readFileSync(out+'/native-input.json.gz')),rawResult=gunzipSync(readFileSync(out+'/native-result.json.gz'));
assert.equal(sha(rawInput),'30b6c7539b81f2643fb331160b48e9af669136f308536eb03c3489d8038dd12c');assert.equal(sha(rawResult),'d9a459cd43997729eaf24caab61b0012cf1e545b23b90efc1778ea0652386f33');
const nativeInput=JSON.parse(rawInput),nativeResult=JSON.parse(rawResult),inputBefore=jsonSha(nativeInput),resultBefore=jsonSha(nativeResult),gunId='arsenal:cordoba:2',actorId='11',count=334;
assert.equal(nativeResult.orders.length,447);assert.deepEqual(nativeResult.orders[333],{type:'stance',unitId:actorId,stance:'standing'});assert.deepEqual(nativeResult.orders[334],{type:'stance',unitId:actorId,stance:'crouched'});
for(const path of ['tests/fresh-northern-fixture.mjs','tests/mountain-battery-driver.mjs','tests/northern-route.mjs','game/world.js','game/tactical.js','game/time.js','game/save.js'])assert.equal(sha(readFileSync(repo+'/'+path)),manifest[path]);
const [{enterSector},{actBattle,endTurn},{syncBattleTime},{encodeSave,decodeSave},originalModule,candidateModule,{mountainBatteryOrder}]=await Promise.all([import(repo+'/game/world.js'),import(repo+'/game/tactical.js'),import(repo+'/game/time.js'),import(repo+'/game/save.js'),import(repo+'/tests/fresh-northern-fixture.mjs'),import(repo+'/tests/fresh-northern-fixture.mjs?salta-candidate=1'),import(repo+'/tests/mountain-battery-driver.mjs')]);
const receipt={scope:'One exact canonical native prefix0..333 from the genuine retained full942 Salta input, then pure original/proposed selectors at one fixed standing-Paz/spent-gun checkpoint and at most one ordinary proposed native action. No full fight/controller/seed/prefix alternatives or victory claim.',runtime:process.execPath,nodeVersion:process.version,pid:process.pid,fullGateReceiptSha256:sha(readFileSync(full+'/final-receipt.json')),rootTerminalConfirmed:true,inputRawSha256:sha(rawInput),resultRawSha256:sha(rawResult),sourceBaselineSha256:manifest['tests/fresh-northern-fixture.mjs'],externalCandidateSha256:'1a7d2e2ebf82a7bd8d2a41e119d04b40e1f560eb101a0c5906c0f668efd5d424',originalCanonicalOrdersApplied:0,proposedOrdersApplied:0,prefixRestart:false,initialLimit:'Initial battle is derived with the frozen native constructor; it was not independently captured before the original battle.',canonicalTerminalReplay:false,winningChangeUnproved:true};
write('bounded-process-start.json',receipt);
const originalRecipe={placement:false};let battle=enterSector(nativeInput.request,undefined,originalRecipe);assert.equal(jsonSha(nativeInput),inputBefore);
write('bounded-derived-initial.native.json',{campaign:nativeInput.campaign,battle});
const trace=[];
try{
 for(let index=0;index<count;index++){
  const order=structuredClone(nativeResult.orders[index]),before=jsonSha(battle),priorUnit=order.unitId&&battle.units.find(unit=>unit.id===order.unitId),beforeAP=priorUnit?.ap,next=order.type==='endTurn'?endTurn(battle):actBattle(battle,order);
  assert.equal(next.lastError,null,'Canonical order '+index+' '+JSON.stringify(order));
  trace.push({zeroBasedOrder:index,order,beforeBattleSha256:before,afterBattleSha256:jsonSha(next),beforeAP,afterAP:order.unitId?next.units.find(unit=>unit.id===order.unitId)?.ap:undefined,nativeAccepted:true});battle=next;receipt.originalCanonicalOrdersApplied++;
 }
 assert.equal(jsonSha(nativeInput),inputBefore);assert.equal(jsonSha(nativeResult),resultBefore);
 const actor=battle.units.find(unit=>unit.id===actorId),gun=battle.artillery.find(piece=>piece.id===gunId);assert.ok(actor&&gun);assert.equal(battle.status,'active');assert.equal(actor.stance,'standing');assert.equal(gun.loaded,false);assert.equal(gun.ammo,0);
 write('bounded-prefix334.native.json',{campaign:nativeInput.campaign,battle});write('bounded-canonical-prefix-trace.json',trace);
 const rawCheckpointHash=jsonSha(battle),synced=syncBattleTime(structuredClone(nativeInput.campaign),structuredClone(battle));assert.equal(synced.error,null);const encoded=encodeSave(synced.campaign,synced.battle),official=decodeSave(encoded);assert.deepEqual(official,{campaign:synced.campaign,battle:synced.battle});assert.equal(jsonSha(battle),rawCheckpointHash);writeFileSync(out+'/bounded-prefix334.save.json.gz',gzipSync(encoded,{mtime:0}));
 write('bounded-prefix334.provenance.json',{scope:'Genuine fixed exact334-order prefix from full942 retained447-order Salta tape. No alternative order, controller-generated prefix, deploy or state grant. Raw tactical state and official clock-synced pair are separate.',sourceInputSha256:sha(rawInput),sourceResultSha256:sha(rawResult),derivedInitialSha256:sha(readFileSync(out+'/bounded-derived-initial.native.json')),canonicalPrefixOrders:count,nextOriginalZeroBasedOrder:334,rawBattleSha256:rawCheckpointHash,officialSaveRawSha256:sha(encoded),officialSaveGzipSha256:sha(readFileSync(out+'/bounded-prefix334.save.json.gz')),sourceSnapshot:full+'/before-source-hashes.json',baselineHelperSha256:manifest['tests/fresh-northern-fixture.mjs'],candidateHelperSha256:receipt.externalCandidateSha256,fullTerminalReplayUnproved:true,initialIndependentlyPreCaptured:false});
 const decide=(fn,state)=>{const input=structuredClone(state),before=jsonSha(input),unit=input.units.find(unit=>unit.id===actorId),action=fn(input,unit,gunId);assert.equal(jsonSha(input),before,'Selector input mutated');return action;};
 const original=decide(originalModule.northernOfficerSaltaOrder,battle),candidate=decide(candidateModule.northernOfficerSaltaOrder,battle),delegated=decide((state,unit)=>mountainBatteryOrder(state,unit,{leaderId:'9',helperId:'11',artilleryId:gunId,keepCrewTogether:true,screenDistance:3}),battle);
 assert.deepEqual(original,{type:'stance',unitId:actorId,stance:'crouched'});assert.deepEqual(candidate,delegated);
 receipt.checkpoint={zeroBasedNextOrder:334,actor:{id:actor.id,stance:actor.stance,hp:actor.hp,ap:actor.ap,loaded:actor.loaded,ammo:actor.ammo,activeSlot:actor.activeSlot},gun,rawBattleSha256:rawCheckpointHash,officialSaveRawSha256:sha(encoded)};receipt.selectors={original,candidate,unchangedDelegate:delegated,inputsUnchanged:true,selectorsEvaluatedWithoutApplying:true};write('bounded-selectors.json',receipt.selectors);
 if(!candidate||candidate.type==='stance'&&candidate.stance==='crouched'){
  receipt.controlResult='The exhausted-gun override is removed but the unchanged lower policy still returns crouch/null. No corrected useful action proved and no alternative order applied.';receipt.nativeTerminal=official.battle.status;write('bounded-control-receipt.json',receipt);console.log(JSON.stringify(receipt));process.exitCode=2;
 }else{
  const controlBefore=jsonSha(official),unitBefore=structuredClone(official.battle.units.find(unit=>unit.id===actorId)),gunBefore=structuredClone(official.battle.artillery.find(piece=>piece.id===gunId)),next=actBattle(official.battle,candidate);
  assert.equal(next.lastError,null,JSON.stringify(candidate));receipt.proposedOrdersApplied=1;
  const pair=syncBattleTime(official.campaign,next);assert.equal(pair.error,null);const saved=encodeSave(pair.campaign,pair.battle),restored=decodeSave(saved);assert.deepEqual(restored,{campaign:pair.campaign,battle:pair.battle});assert.equal(jsonSha(official),controlBefore,'Control input mutated');
  writeFileSync(out+'/bounded-one-action-final.save.json.gz',gzipSync(saved,{mtime:0}));write('bounded-one-action-final.native.json',restored);
  receipt.paidOrder={action:candidate,beforeActor:unitBefore,afterActor:next.units.find(unit=>unit.id===actorId),beforeGun:gunBefore,afterGun:next.artillery.find(piece=>piece.id===gunId),elapsedBefore:official.battle.elapsedSeconds,elapsedAfter:next.elapsedSeconds,beforeSha256:controlBefore,afterNativeBattleSha256:jsonSha(next),officialFinalSaveSha256:sha(saved)};
  receipt.nextPureDecision=next.status==='active'?decide(candidateModule.northernOfficerSaltaOrder,next):null;receipt.controlResult='One ordinary delegated action replaced the redundant forced crouch and paid native costs; no full battle outcome proof.';receipt.nativeTerminal=next.status;write('bounded-control-receipt.json',receipt);console.log(JSON.stringify({scope:receipt.scope,originalOrders:receipt.originalCanonicalOrdersApplied,proposedOrders:receipt.proposedOrdersApplied,original,candidate,nextPureDecision:receipt.nextPureDecision,nativeTerminal:receipt.nativeTerminal,winningChangeUnproved:true}));
 }
}catch(error){write('bounded-canonical-prefix-trace.json',trace);receipt.failure={message:error.message,stack:error.stack};write('bounded-control-receipt.json',receipt);throw error;}
