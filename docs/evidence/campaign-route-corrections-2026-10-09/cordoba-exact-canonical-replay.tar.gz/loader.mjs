import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/';
const out='/tmp/granaderos-opening-current-safe-fire-observer-20261010/exact-canonical-replay';
const sha=raw=>createHash('sha256').update(raw).digest('hex'),rows=new Map();
const pinned=JSON.parse(readFileSync(out+'/pinned-selectors.json','utf8'));
const overlays=new Map(Object.keys(pinned).filter(p=>p.startsWith('tests/')).map(p=>[p,`${out}/original-${p.split('/').at(-1)}`]));
registerHooks({load(url,context,next){
 const result=next(url,context);if(!url.startsWith('file://'))return result;const absolute=fileURLToPath(url);if(!absolute.startsWith(repo)||result.source==null)return result;
 const path=absolute.slice(repo.length),disk=readFileSync(absolute),diskSha256=sha(disk),overlay=overlays.get(path),runtime=overlay?readFileSync(overlay):result.source;
 if(pinned[path])assert.equal(sha(runtime),pinned[path].sha256,`Pinned native selector/engine bytes differ: ${path}`);
 rows.set(path,{path,loadedSha256:sha(runtime),loadedBytes:Buffer.byteLength(runtime),originalOverlay:overlay??null,candidateDiskSha256:diskSha256,candidateDiskBytes:disk.length});
 return overlay?{...result,source:runtime}:result;
}});
process.on('exit',code=>{const values=[...rows].map(row=>({...row,finalLoadedSha256:sha(readFileSync(row.originalOverlay??repo+row.path)),finalCandidateDiskSha256:sha(readFileSync(repo+row.path))}));writeFileSync(out+'/imports.json',JSON.stringify({pid:process.pid,exitCode:code,policy:'Exactly recorded native orders; pinned original selector overlay. No API wrappers or controller replacement. Original overlay versus current candidate disk identity remains explicit.',actualImports:values.length,loadedDrift:values.filter(row=>row.loadedSha256!==row.finalLoadedSha256),candidateDiskDrift:values.filter(row=>row.candidateDiskSha256!==row.finalCandidateDiskSha256),rows:values},null,2)+'\n');});
