import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {actBattle,endTurn,getReachable,firearmShotOptions,actionCosts,stanceCost,canSee,teamCanSee,lookPreview,weaponFor,interruptAvailable} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/tactical.js';
import {chooseEnemyAction} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/tactical-ai.js';
import {directionTo} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/tactical-awareness.js';
import {spaceKey,tacticalLevel} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/tactical-space.js';
import {playerKnownBattle} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/player-known-state.js';
import {syncBattleTime} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/time.js';
import {encodeSave,decodeSave} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/save.js';
import {northernCombatOrder} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/northern-route.mjs';
import {tucumanCombatOrder} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/tucuman-driver.mjs';
import {hiredAssaultOrder} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/hired-assault-driver.mjs';

const parent='/tmp/granaderos-opening-current-safe-fire-observer-20261010',out=parent+'/exact-canonical-replay';
const sha=raw=>createHash('sha256').update(raw).digest('hex'),digest=value=>sha(JSON.stringify(value));
const save=(name,value)=>writeFileSync(`${out}/${name}`,JSON.stringify(value,null,2)+'\n');
const initialPath=parent+'/cordoba-before-first-controller.native.json',inputRaw=readFileSync(initialPath),input=JSON.parse(inputRaw);
const expected=JSON.parse(readFileSync(parent+'/cordoba-fight-3-terminal.native.json','utf8')),orders=JSON.parse(readFileSync(parent+'/cordoba-fight-3-native-orders.json','utf8')),chain=JSON.parse(readFileSync(parent+'/cordoba-canonical-api-chain.json','utf8'));
const decisions=readFileSync(parent+'/cordoba-blocked-decisions-59537.ndjson','utf8').trim().split('\n').map(JSON.parse).filter(row=>row.current===null);
assert.equal(orders.length,162);assert.equal(decisions.length,10);
const checkpoints=new Map();for(const row of decisions){const ordinal=chain.findIndex(link=>link.afterSha256===row.inputSha256)+1;assert.ok(ordinal);checkpoints.set(ordinal,row);}
const inspection=[];let battle=structuredClone(input.battle),inputChecks=0;
const pure=(state,fn)=>{const before=digest(state),result=fn();assert.equal(digest(state),before);inputChecks++;return result;};
const safe=option=>!option.interveningFriendly&&!option.shots?.some(shot=>shot.interveningFriendly);

function inspect(b,row,ordinal){
 assert.equal(digest(b),row.inputSha256);const rawBefore=digest(b),u=b.units.find(v=>v.id===row.actor.id),known=playerKnownBattle(b),ids=new Set(known.units.map(v=>v.id)),npcIds=new Set(known.npcs.map(v=>v.id)),artilleryIds=new Set(known.artillery.map(v=>v.id));
 const clone=structuredClone(b);clone.units=clone.units.filter(v=>v.side==='player'||ids.has(v.id));clone.npcs=(clone.npcs??[]).filter(v=>npcIds.has(v.id));clone.artillery=clone.artillery.filter(v=>v.side==='player'||artilleryIds.has(v.id));
 const own=clone.units.find(v=>v.id===u.id),targets=clone.units.filter(v=>v.side!==own.side&&v.hp>=15&&!v.unconscious&&!v.routed&&!v.surrendered&&!v.departure&&ids.has(v.id)),knownCells=new Set([...(known.tiles??[]),...(known.upperSurfaces??[])].map(spaceKey));
 const shotRows=(scene,shooter)=>targets.flatMap(t=>{
  const costs=actionCosts(scene,shooter,t);if(shooter.ap<costs.fire)return [];
  const aim=Math.min(4,Math.floor((shooter.ap-costs.fire)/costs.aim));
  return firearmShotOptions(scene,shooter,t,aim).filter(o=>o.chance>0&&o.damageFactor>0).map(o=>({target:t.id,aim:o.aim,hitLocation:o.hitLocation,chance:o.chance,damageFactor:o.damageFactor,expectedDamage:o.expectedDamage??null,shotLoad:Boolean(o.shotLoad),safe:safe(o),pa:costs.fire+o.aim*costs.aim,personal:canSee(scene,shooter,t)}));
 });
 const current=pure(clone,()=>shotRows(clone,own)),currentSafe=current.filter(o=>o.safe);
 const originalNorth=pure(b,()=>northernCombatOrder(b,u)),originalTucuman=pure(b,()=>tucumanCombatOrder(b,u)),nativeAI=pure(clone,()=>chooseEnemyAction(clone,own)),hired=pure(clone,()=>hiredAssaultOrder(clone,own));
 assert.equal(originalNorth,null);assert.equal(nativeAI,null);
 const stances=[];
 for(const stance of ['standing','crouched','prone']){
  if(stance===own.stance)continue;const pa=stanceCost(own,stance);if(pa>own.ap)continue;
  const proxy={...own,stance,weaponReady:false,ap:own.ap-pa},scene={...clone,units:clone.units.map(v=>v.id===own.id?proxy:v)},shots=pure(scene,()=>shotRows(scene,proxy)).filter(o=>o.safe);
  stances.push({action:{type:'stance',unitId:own.id,stance},pa,remainingPA:proxy.ap,safeShots:shots.length,safeAtLeast25:shots.filter(o=>o.chance>=25).length,best:shots.sort((a,c)=>c.chance-a.chance||a.pa-c.pa)[0]??null,unapplied:true});
 }
 const looks=[];
 for(const target of targets){
  const preview=pure(clone,()=>lookPreview(clone,own,target));if(!preview.valid||preview.pa>own.ap)continue;
  const proxy={...own,facing:preview.facing,ap:own.ap-preview.pa,...(own.stance==='prone'&&preview.pa?{weaponReady:false}:{})},scene={...clone,units:clone.units.map(v=>v.id===own.id?proxy:v)},shots=pure(scene,()=>shotRows(scene,proxy)).filter(o=>o.safe);
  looks.push({action:{type:'look',unitId:own.id,x:target.x,y:target.y},pa:preview.pa,facing:preview.facing,personalVisible:targets.filter(v=>canSee(scene,proxy,v)).map(v=>v.id),safeShots:shots.length,best:shots.sort((a,c)=>c.chance-a.chance||a.pa-c.pa)[0]??null,unapplied:true});
 }
 const moves=[];
 const paths=pure(clone,()=>getReachable(clone,own));
 for(const p of paths.filter(p=>p.cost>0&&p.cost<=24&&p.path.length<=3&&tacticalLevel(p)===tacticalLevel(own)&&p.path.every(step=>tacticalLevel(step)===tacticalLevel(own)&&knownCells.has(spaceKey(step))))){
  const proxy={...own,x:p.x,y:p.y,tacticalLevel:tacticalLevel(p),ap:own.ap-p.cost,weaponReady:false,facing:directionTo(p.path.at(-2)??own,p)},scene={...clone,units:clone.units.map(v=>v.id===own.id?proxy:v)},shots=pure(scene,()=>shotRows(scene,proxy)).filter(o=>o.safe);
  moves.push({action:{type:'move',unitId:own.id,x:p.x,y:p.y,tacticalLevel:tacticalLevel(p)},pa:p.cost,path:p.path,remainingPA:proxy.ap,safeShots:shots.length,safeAtLeast25:shots.filter(o=>o.chance>=25).length,best:shots.sort((a,c)=>c.chance-a.chance||a.pa-c.pa)[0]??null,unapplied:true});
 }
 moves.sort((a,c)=>a.pa-c.pa||a.action.y-c.action.y||a.action.x-c.action.x);
 const prefix=`blocked-after-${String(ordinal).padStart(3,'0')}`;save(prefix+'.native.json',{campaign:input.campaign,battle:b});
 const official=pure(b,()=>{const c=structuredClone(input.campaign),copy=structuredClone(b),cb=digest(c),bb=digest(copy),synced=syncBattleTime(c,copy);assert.equal(synced.error,null);assert.equal(digest(c),cb);assert.equal(digest(copy),bb);const text=encodeSave(synced.campaign,synced.battle),restored=decodeSave(text);assert.deepEqual(restored.campaign,synced.campaign);assert.deepEqual(restored.battle,synced.battle);writeFileSync(`${out}/${prefix}.save.json`,text+'\n');return {saveSha256:sha(text+'\n'),roundTripExact:true};});
 assert.equal(digest(b),rawBefore);
 const result={afterCanonicalOrders:ordinal,decision:row.decision,inputSha256:rawBefore,official,actor:{...row.actor,weapon:own.weapon,weaponName:weaponFor(own).name,activeSlot:own.activeSlot,facing:own.facing,medical:own.medical,weaponReady:own.weaponReady},phase:row.battle.phase,personalTargets:targets.filter(v=>canSee(clone,own,v)).map(v=>v.id),teamTargets:targets.map(v=>v.id),currentShots:{positive:current.length,unsafe:current.filter(o=>!o.safe).length,safe:currentSafe.length,safeBelow25:currentSafe.filter(o=>o.chance<25).length,safeAtLeast25:currentSafe.filter(o=>o.chance>=25).length,best:currentSafe.sort((a,c)=>c.chance-a.chance||a.pa-c.pa)[0]??null},originalNorth,originalTucuman,nativeAI,hiredAssault:hired,stances,looks,moves,interruptAvailable:interruptAvailable(b,u),inputUnchanged:true};
 inspection.push(result);save(prefix+'-inspection.json',result);
 console.log(JSON.stringify({checkpoint:ordinal,decision:row.decision,personal:result.personalTargets,team:result.teamTargets,safeCurrent:result.currentShots.safe,safeBelow25:result.currentShots.safeBelow25,hired,moves:moves.length,safeMoves:moves.filter(m=>m.safeShots).length,safeStances:stances.filter(m=>m.safeShots).length,safeLooks:looks.filter(m=>m.safeShots).length}));
}

save('start.json',{pid:process.pid,node:process.execPath,nodeVersion:process.version,inputPath:initialPath,inputSha256:sha(inputRaw),orders:162,expectedTerminalSha256:digest(expected),scope:'One exact retained tape replay, with pinned original selectors. All diagnostic alternatives remain unapplied.'});
for(let i=0;i<orders.length;i++){
 assert.equal(digest(battle),chain[i].beforeSha256,`recorded before state${i}`);
 const next=orders[i].type==='endTurn'?endTurn(battle):actBattle(battle,orders[i]);assert.equal(next.lastError,null,`recorded order${i}`);assert.equal(digest(next),chain[i].afterSha256,`recorded after state${i}`);battle=next;
 const row=checkpoints.get(i+1);if(row)inspect(battle,row,i+1);
}
assert.deepEqual(battle,expected);assert.equal(digest(input.battle),chain[0].beforeSha256);assert.equal(sha(readFileSync(initialPath)),sha(inputRaw));assert.equal(inspection.length,10);
save('terminal.native.json',battle);save('inspection.json',inspection);save('receipt.json',{pid:process.pid,node:process.execPath,nodeVersion:process.version,nativeRecordedOrdersApplied:162,alternativeOrdersApplied:0,all162BeforeAfterHashesExact:true,terminalDeepEqual:true,terminalSha256:digest(battle),terminalStatus:battle.status,inputUnchanged:true,pureDiagnosticInputChecks:inputChecks,inspectionCount:inspection.length,scope:'Fixed canonical tape only. No new battle/prefix, controller execution to choose orders, outcome or resource grant. All shot/posture/look/movement/hired alternatives are read-only forecasts or selectors; none is admitted/executed.'});
console.log(JSON.stringify({status:'exact native replay pass',orders:162,alternativesApplied:0,terminal:battle.status,inspection:inspection.length}));
