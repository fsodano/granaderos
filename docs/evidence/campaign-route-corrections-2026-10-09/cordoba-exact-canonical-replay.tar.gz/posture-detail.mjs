import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {firearmShotOptions,actionCosts,stanceCost,canSee,teamCanSee,weaponFor,interruptAvailable} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/tactical.js';
import {playerKnownBattle} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/player-known-state.js';
const out='/tmp/granaderos-opening-current-safe-fire-observer-20261010/exact-canonical-replay';
const digest=v=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const inspections=JSON.parse(readFileSync(out+'/inspection.json','utf8'));
const results=[];let checks=0;
for(const r of inspections){
 const b=JSON.parse(readFileSync(out+'/blocked-after-'+String(r.afterCanonicalOrders).padStart(3,'0')+'.native.json','utf8')).battle;
 const original=digest(b);assert.equal(original,r.inputSha256);
 const k=playerKnownBattle(b),ids=new Set(k.units.map(v=>v.id)),npcs=new Set(k.npcs.map(v=>v.id)),guns=new Set(k.artillery.map(v=>v.id)),scene=structuredClone(b);
 scene.units=scene.units.filter(v=>v.side==='player'||ids.has(v.id));scene.npcs=scene.npcs.filter(v=>npcs.has(v.id));scene.artillery=scene.artillery.filter(v=>v.side==='player'||guns.has(v.id));
 const u=scene.units.find(v=>v.id==='113'),targets=scene.units.filter(v=>v.side==='enemy'&&v.hp>=15&&!v.unconscious&&!v.routed&&!v.surrendered&&!v.departure&&ids.has(v.id));
 const originalPersonal=targets.filter(t=>canSee(scene,u,t)).map(t=>t.id);
 const rows=[];
 for(const stance of ['crouched','standing']){
  const pa=stanceCost(u,stance),p={...u,stance,movementMode:stance==='crouched'?'crouch':'walk',momentum:0,weaponReady:false,ap:u.ap-pa},s={...scene,units:scene.units.map(v=>v.id===u.id?p:v)};
  const before=digest(s),shots=[];
  for(const t of targets){
   const c=actionCosts(s,p,t),max=Math.min(4,Math.floor((p.ap-c.fire)/c.aim));if(p.ap<c.fire)continue;
   for(const o of firearmShotOptions(s,p,t,max))if(o.chance>0&&o.damageFactor>0&&!o.interveningFriendly&&!o.shots?.some(shot=>shot.interveningFriendly)){
    const effectiveness=o.shotLoad?100*Math.min(t.hp,o.expectedDamage)/Math.max(1,Math.min(t.hp,weaponFor(p).damage)):null;
    shots.push({target:t.id,hp:t.hp,hitLocation:o.hitLocation,aim:o.aim,shotPA:c.fire+o.aim*c.aim,aimIncrementPA:c.aim,totalWithPosturePA:pa+c.fire+o.aim*c.aim,chance:o.chance,expectedDamage:o.expectedDamage,damageFactor:o.damageFactor,effectiveness,personal:canSee(s,p,t),team:teamCanSee(s,'player',t),originalPersonal:originalPersonal.includes(t.id)});
   }
  }
  assert.equal(digest(s),before);checks++;
  const maxEff=a=>[...a].sort((a,b)=>b.effectiveness-a.effectiveness||a.shotPA-b.shotPA||a.hitLocation.localeCompare(b.hitLocation))[0]??null;
  rows.push({stance,posturePA:pa,remainingPA:p.ap,personalAfter:targets.filter(t=>canSee(s,p,t)).map(t=>t.id),teamAfter:targets.filter(t=>teamCanSee(s,'player',t)).map(t=>t.id),safeShotCount:shots.length,bestTeam:maxEff(shots),bestPersonal:maxEff(shots.filter(v=>v.personal)),bestOriginalPersonal:maxEff(shots.filter(v=>v.originalPersonal&&v.personal)),safePersonalAtNative25:shots.filter(v=>v.personal&&v.originalPersonal&&v.effectiveness>=25).length,shots});
 }
 assert.equal(digest(b),original);checks++;
 results.push({afterCanonicalOrders:r.afterCanonicalOrders,actorAP:u.ap,actorHp:u.hp,loaded:u.loaded,ammo:u.ammo,weapon:u.weapon,weaponDamage:weaponFor(u).damage,mounted:Boolean(u.mounted),knockedDown:Boolean(u.knockedDown),personalBefore:originalPersonal,teamBefore:targets.map(t=>t.id),interruptAdmitted:interruptAvailable(b,b.units.find(v=>v.id===u.id)),postures:rows,inputUnchanged:true});
}
writeFileSync(out+'/posture-detail.json',JSON.stringify({policy:'Read-only proxy forecasts on retained blocked checkpoints. No order admitted/applied, no battle continuation; current team-known units/NPCs only.',alternativesApplied:0,pureInputChecks:checks,results},null,2)+'\n');
console.log(JSON.stringify(results.map(r=>({order:r.afterCanonicalOrders,personalBefore:r.personalBefore,rows:r.postures.map(p=>({stance:p.stance,pa:p.posturePA,personalAfter:p.personalAfter,teamAfter:p.teamAfter,bestTeam:p.bestTeam,bestPersonal:p.bestPersonal,bestOriginalPersonal:p.bestOriginalPersonal,native25:p.safePersonalAtNative25}))})),null,2));
