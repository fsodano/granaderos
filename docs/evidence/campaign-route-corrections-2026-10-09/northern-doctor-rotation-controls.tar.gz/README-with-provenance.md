# Northern care correction and exact native proof

Source patch5333716b is unchanged. Use install-review-with-provenance.json for the final exact source/test/fixture copy list. The final persistent test adds fixture gzip/payload/capture hash checks before execution.

The one completed external native control used executed-relative-control.test.mjs (e4bb78e2). Its exact input/source/closure receipts are preserved. The later provenance guard does not change the care plan and has not triggered another external native sequence. Root will run the final persistent controls in the repository.

The native control restored112 from15/64 to64/64 after9hours, then returned it to doctor duty. All three actual patients reached full health after17hours. It accepted24orders (7assignCare,17wait), used17of30real dressings, preserved all8earlier dead records, produced4official save round trips and replayed the exact native order tape to the complete final campaign. SourceDrift and externalDrift were empty at control closure.

The pure declared controls test doctor pair selection, sleep and finite transfer needs. The actual earned sequence did not need the transfer branch. No campaign prefix, battle, alternate plan, seed change, health or supply grant, or outcome relaxation was used. This proves the care correction for the retained input; actual full route validation remains required.

The initial archive is preserved separately. This expanded archive also contains its original manifest under initial-archive-manifest.json, plus the final provenance files and executed test copy. portable-archive-manifest.json describes all current payloads except itself.
