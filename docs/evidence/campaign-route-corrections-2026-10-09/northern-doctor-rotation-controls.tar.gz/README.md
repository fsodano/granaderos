# Northern doctor rotation: bounded native care proof

The original unchanged recovery test retained patient 112 at 15/64 health. Its selected doctor assignment prevented ordinary native patient care. This reviewed external patch selects a different fit doctor, keeps the wounded doctor a patient, and resumes doctor duty after actual recovery.

One genuine observed after-gather state was used. The control accepted 24 orders (7 native role assignments, 17 one-hour waits), used 17 of 30 real dressings, and restored patients 112, 113 and 141 to full health. The eight earlier dead records remain byte-equivalent as native objects. Four official saves round-trip the complete campaign; the exact recorded order tape replays to the complete final native campaign.

No prefix, battle, route, seed change, health grant, supply grant, retry or outcome relaxation was used. Pure declared variants test healthy and wounded doctor pairs, sleep and empty kits; they are not earned native outcomes. The earned control did not exercise the optional ordinary sector dressing transfer. See bounded-native-care-summary.json for scope and limits.

Install the reviewed northern-doctor-rotation.patch, the relative test, and its exact gzip fixture using the explicit install file list in bounded-native-care-summary.json. Keep the actual route health assertion. The archive retains source input/closure hashes, loader/runner, original input, exact tape, native costs and official saves.
