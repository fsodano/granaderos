import {registerHooks} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/',output=new URL('./imported-source-provenance-'+process.pid+'.json',import.meta.url),seen=new Map();
registerHooks({load(url,context,next){const result=next(url,context);if(url.startsWith('file:')){const path=fileURLToPath(url);if(path.startsWith(repo)&&/\.(js|mjs)$/.test(path)){const bytes=readFileSync(path);seen.set(path.slice(repo.length),{path:path.slice(repo.length),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}}return result;}});
process.on('exit',()=>writeFileSync(output,JSON.stringify({runtime:process.execPath,nodeVersion:process.version,imports:[...seen.values()].sort((a,b)=>a.path.localeCompare(b.path))},null,2)+'\n',{flag:'wx'}));
