import datetime,hashlib,json,pathlib,subprocess,sys
folder=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/fsodano/.codex/worktrees/blast-structures/granaderos')
baseline=pathlib.Path('/tmp/granaderos-campaign-final-posture-full-2026-10-10T040806965Z/before-source-hashes.json')
snapshot=json.loads(baseline.read_text())
expected={path:sha for path,sha in snapshot.items() if path.startswith(('game/','tests/')) and path.endswith(('.js','.mjs','.json'))}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def source_receipt():return [{'path':path,'expectedSha256':value,'actualSha256':sha(repo/path),'equal':sha(repo/path)==value} for path,value in sorted(expected.items())]
external=[path for path in folder.rglob('*') if path.is_file() and 'game' not in path.relative_to(folder).parts]
external_before={str(p.relative_to(folder)):sha(p) for p in external}
entry=source_receipt();assert all(row['equal'] for row in entry),'Repository input drift before native control'
command=['/opt/homebrew/Cellar/node/25.9.0_2/bin/node','--import',str(folder/'source-provenance-loader.mjs'),'--test',str(folder/'overlay/tests/northern-care-roles.test.mjs')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (folder/'native-control-run.log').open('x') as output:
 process=subprocess.Popen(command,cwd=folder/'overlay',stdout=output,stderr=subprocess.STDOUT)
 (folder/'live-native-control.json').write_text(json.dumps({'pid':process.pid,'command':command,'startedAt':start,'nativeSequenceCount':1,'recordedOrderReplayCount':1,'repoSourceTransforms':0,'prefixCount':0,'battleCount':0},indent=2)+'\n')
 print('LIVE_NATIVE_CARE_PID',process.pid,flush=True)
 code=process.wait()
closure=source_receipt();imports=[]
for p in sorted(folder.glob('imported-source-provenance-*.json')):
 data=json.loads(p.read_text())
 for row in data['imports']:
  row['expectedSha256']=snapshot.get(row['path']);row['baselineEqual']=row['sha256']==row['expectedSha256'];row['closureSha256']=sha(repo/row['path']);row['closureEqual']=row['sha256']==row['closureSha256'];imports.append(row)
external_drift=[path for path,value in external_before.items() if sha(folder/path)!=value]
log=(folder/'native-control-run.log').read_text()
result={'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'command':command,'repoSourceTransforms':0,'nativeSequenceCount':1,'recordedOrderReplayCount':1,'prefixCount':0,'battleCount':0,'sourceSnapshot':{'path':str(baseline),'sha256':sha(baseline)},'entry':entry,'closure':closure,'sourceDrift':[row for row in closure if not row['equal']],'imports':imports,'externalInputs':external_before,'externalDrift':external_drift,'log':{'bytes':len(log.encode()),'sha256':hashlib.sha256(log.encode()).hexdigest()}}
for line in log.splitlines():
 if 'NATIVE_CARE_CONTROL_OUTPUT=' in line:result['nativeOutput']=line.split('NATIVE_CARE_CONTROL_OUTPUT=',1)[1].strip()
 if 'NATIVE_CARE_CONTROL_RECEIPT=' in line:result['nativeReceipt']=line.split('NATIVE_CARE_CONTROL_RECEIPT=',1)[1].strip()
(folder/'terminal-native-control-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(log)
print('TERMINAL_RECEIPT',folder/'terminal-native-control-receipt.json',sha(folder/'terminal-native-control-receipt.json'))
assert not result['sourceDrift'] and not external_drift and all(row['baselineEqual'] and row['closureEqual'] for row in imports),'Source proof drift'
sys.exit(code)
