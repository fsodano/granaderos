import {registerHooks} from 'node:module';
import {readFileSync,appendFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/',out='/tmp/granaderos-full940-readonly-helper-audit-20261010/second-correction',rows=new Map(),sha=value=>createHash('sha256').update(value).digest('hex');
registerHooks({load(url,context,next){const result=next(url,context);if(!url.startsWith('file://')||result.source==null)return result;const path=fileURLToPath(url);if(!path.startsWith(repo))return result;const row={path:path.slice(repo.length),originalSha256:sha(readFileSync(path)),runtimeSha256:sha(result.source),bytes:Buffer.byteLength(result.source)};rows.set(path,row);appendFileSync(out+'/runtime-imports.jsonl',JSON.stringify(row)+'\n');return result;}});
process.on('exit',exitCode=>{const records=[...rows.entries()].map(([path,row])=>({...row,finalSha256:sha(readFileSync(path))}));writeFileSync(out+'/runtime-import-closure.json',JSON.stringify({exitCode,actualImports:records.length,sourceTransforms:[],originalRuntimeDifferences:records.filter(row=>row.originalSha256!==row.runtimeSha256),sourceDrift:records.filter(row=>row.originalSha256!==row.finalSha256),records},null,2)+'\n');});
