// EXTERNAL PROPOSAL ONLY. Not executed. Adds passive snapshots to the exact
// frozen northern helper. It does not choose or execute simulation orders.
import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {mkdirSync,mkdtempSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
const target="file:///Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/northern-route.mjs";
const expectedSha256="ce34ec82c0caf30aa905ef3d06363d6de80f766c773727266c8a91c82eefd3ec";
const output="/tmp/granaderos-medical-preparation-readonly-20261010T043331543729Z/observer-captures";
let sequence=0;
const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
export function recordMedicalPreparationState({phase,campaign,...context}){
 try{
  const original=structuredClone(campaign),raw=JSON.stringify({phase,campaign:original,context},null,2)+'\n';
  assert.deepEqual(campaign,original);
  mkdirSync(output,{recursive:true});
  const leaf=mkdtempSync(join(output,`${process.pid}-${++sequence}-${phase}-`));
  writeFileSync(join(leaf,'native-state.json'),raw);
  const receipt={phase,pid:process.pid,runtime:process.execPath,nodeVersion:process.version,
   source:target,baselineSourceSha256:expectedSha256,
   capture:'raw clone at the original native code position',officialSaveAttempted:false,
   additionalSimulationOrders:0,additionalDeployment:0,additionalSettlement:0,
   fullInputCloneUnchanged:true,artifact:{path:'native-state.json',bytes:Buffer.byteLength(raw),sha256:sha256(raw)}};
  writeFileSync(join(leaf,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 }catch(error){console.error('Medical preparation observation error:',String(error));}
}
registerHooks({load(url,context,nextLoad){
 const loaded=nextLoad(url,context);if(url!==target)return loaded;
 const source=typeof loaded.source==='string'?loaded.source:Buffer.from(loaded.source).toString();
 if(sha256(source)!==expectedSha256){console.error('Medical observer baseline source mismatch; original helper is unchanged.');return loaded;}
 const replacements=[[" const staged=stageNorthernCare(start);let campaign=staged.campaign;", " _medicalStateObserver({phase:'northern-prepare-input',campaign:start});\n const staged=stageNorthernCare(start);let campaign=staged.campaign;"], [" const patients=campaign.recruited.filter(id=>{const r=campaign.operativeState[id];return r.alive&&!r.captured&&r.location==='san_nicolas'&&r.hp<r.maxHp;});", " const patients=campaign.recruited.filter(id=>{const r=campaign.operativeState[id];return r.alive&&!r.captured&&r.location==='san_nicolas'&&r.hp<r.maxHp;});\n _medicalStateObserver({phase:'northern-staged-patients',campaign,doctors,patients,staging});"], [" for(const operativeId of doctors)order({type:'assignCare',operativeId,assignment:'doctor'});\n for(let i=0;patients.some(id=>campaign.operativeState[id].hp<campaign.operativeState[id].maxHp)&&i<60;i++){", " for(const operativeId of doctors)order({type:'assignCare',operativeId,assignment:'doctor'});\n _medicalStateObserver({phase:'northern-assigned-roles',campaign,doctors,patients});\n for(let i=0;patients.some(id=>campaign.operativeState[id].hp<campaign.operativeState[id].maxHp)&&i<60;i++){"], [" for(const id of patients)assert.equal(campaign.operativeState[id].hp,campaign.operativeState[id].maxHp,`patient ${id} must finish paid care`);", " _medicalStateObserver({phase:'northern-pre-full-health-assertion',campaign,doctors,patients,events,gathered,donors,medicalTrips,careRenewals,medicalStart,recoveredDressings,donatedDressings,laterRecoveredDressings});\n for(const id of patients)assert.equal(campaign.operativeState[id].hp,campaign.operativeState[id].maxHp,`patient ${id} must finish paid care`);"]];
 if(replacements.some(([anchor])=>source.split(anchor).length!==2)){
  console.error('Medical observer anchor mismatch; original helper is unchanged.');return loaded;
 }
 let observed=source;for(const [anchor,replacement]of replacements)observed=observed.replace(anchor,replacement);
 observed=`import {recordMedicalPreparationState as _medicalStateObserver} from ${JSON.stringify(import.meta.url)};\n`+observed;
 return {...loaded,source:observed};
}});
