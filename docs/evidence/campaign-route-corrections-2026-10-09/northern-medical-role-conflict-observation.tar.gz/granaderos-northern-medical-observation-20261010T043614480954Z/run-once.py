import pathlib,json,hashlib,subprocess,datetime,os,sys
folder=pathlib.Path(__file__).parent
repo=pathlib.Path("/Users/fsodano/.codex/worktrees/blast-structures/granaderos")
node="/opt/homebrew/Cellar/node/25.9.0_2/bin/node"
sha=lambda b:hashlib.sha256(b).hexdigest()
expectedExternal={'reviewed-northern-medical-state-observer.mjs': '179d110d39badeee017325f1f0c0f214a3b16733dc48d994d805b32c19156b9a', 'reviewed-medical-preparation-readonly-receipt.json': '11bd80626449713b283f5bf0f502123fa122e5f179a96cfbf4480e61b5d543a9', 'northern-medical-state-observer.mjs': 'fbe94292a6b64f7a23239a66cc36a0c6e66c8beaa0d781351c55d698c4bd4d54', 'entry-source-checks.json': '90501f41614c53757bccdcc73f5de4ad3896aaa8257805fd957e8a7c6ea96d1f', 'full942-before-source-hashes.json': '732725d7989c30f04cc44138919406fb5f7b3b58dd2ce76f888dec2869e097b5', 'reviewed-medical-preparation-proposal.md': '9b656e2a4867f0aa70fb02a3ebacfc831a59ae1e2ac640a343e66a327e77b683'}
metadata=json.loads((folder/'entry-metadata.json').read_text())
expectedExternal['run-once.py']=metadata['runner']['sha256']
expectedExternal['entry-metadata.json']=sha((folder/'entry-metadata.json').read_bytes())
entryDrift=[p for p,h in expectedExternal.items() if sha((folder/p).read_bytes())!=h]
assert not entryDrift,entryDrift
frozen=json.loads((folder/'full942-before-source-hashes.json').read_text())
paths=[p for p in frozen if p.startswith(('game/','tests/'))]
assert all(sha((repo/p).read_bytes())==frozen[p] for p in paths),'entry gameplay/test source drift'
assert not (folder/'run.log').exists(),'refuse an existing run.log'
assert not (folder/'pid.json').exists(),'refuse a repeated run'
env=os.environ.copy()
assert not env.get('GRANADEROS_RECOVERY_CHECKPOINT_PREFIX'),'unexpected extra save prefix'
assert not env.get('GRANADEROS_CAMPAIGN_FAILURE_DIR'),'unexpected extra battle recorder'
assert not env.get('"/opt/homebrew/Cellar/node/25.9.0_2/bin/node"_OPTIONS'),'unexpected inherited Node options'
command=[node,'--import',str(folder/'northern-medical-state-observer.mjs'),'--test','tests/fresh-campaign-recovery.test.mjs']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (folder/'run.log').open('xb') as log:
 process=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 (folder/'pid.json').write_text(json.dumps({'parent':os.getpid(),'child':process.pid,'command':command,'started':started})+'\n')
 print(json.dumps({'liveFolder':str(folder),'parent':os.getpid(),'child':process.pid,'command':command}),flush=True)
 code=process.wait()
closure=[]
for p in paths:
 h=sha((repo/p).read_bytes());closure.append({'path':p,'beforeSha256':frozen[p],'closureSha256':h,'equal':h==frozen[p]})
external=[{'path':p,'expectedSha256':h,'closureSha256':sha((folder/p).read_bytes()),'equal':sha((folder/p).read_bytes())==h} for p,h in expectedExternal.items()]
provenance=[]
for p in sorted((folder/'import-provenance').glob('*-imports.json')):
 provenance.append({'path':str(p),'sha256':sha(p.read_bytes()),'data':json.loads(p.read_text())})
union={record['path']:record for processRecord in provenance for record in processRecord['data']['imports']}
imports=[dict(record,closureSha256=sha((repo/p).read_bytes()),closureEqual=sha((repo/p).read_bytes())==record['sha256']) for p,record in sorted(union.items())]
captures=[]
for d in sorted((folder/'observer-captures').iterdir()) if (folder/'observer-captures').exists() else []:
 r=json.loads((d/'receipt.json').read_text());a=r['artifact'];data=(d/a['path']).read_bytes();captures.append({'path':str(d),'receiptSha256':sha((d/'receipt.json').read_bytes()),'receipt':r,'artifactBytesActual':len(data),'artifactSha256Actual':sha(data),'sizeEqual':len(data)==a['bytes'],'hashEqual':sha(data)==a['sha256']})
log=(folder/'run.log').read_text()
receipt={'schema':'granaderos-single-native-medical-observation-v1','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'command':command,'testFiles':['tests/fresh-campaign-recovery.test.mjs'],'executionCount':1,'additionalGameplayOrders':0,'additionalControllerCalls':0,'additionalSaves':0,'seedChanges':0,'sourceEdits':0,'full942GameplayTestSourceFiles':len(paths),'sourceDrift':[x for x in closure if not x['equal']],'externalHashes':external,'externalDrift':[x for x in external if not x['equal']],'sourceImportProvenance':provenance,'importsCount':len(imports),'importClosureChecks':imports,'captures':captures,'originalStrictAssertionObserved':('patient 112 must finish paid care' in log and '15 !== 64' in log),'log':{'path':str(folder/'run.log'),'bytes':(folder/'run.log').stat().st_size,'sha256':sha((folder/'run.log').read_bytes())}}
(folder/'closure-source-checks.json').write_text(json.dumps(closure,indent=2)+'\n')
(folder/'terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'terminalReceipt':str(folder/'terminal-receipt.json'),'receiptSha256':sha((folder/'terminal-receipt.json').read_bytes()),'exitCode':code,'sourceDrift':receipt['sourceDrift'],'externalDrift':receipt['externalDrift'],'imports':len(imports),'captures':len(captures),'originalStrictAssertionObserved':receipt['originalStrictAssertionObserved']}),flush=True)
assert not receipt['sourceDrift'] and not receipt['externalDrift'],'source or external drift'
assert all(x['closureEqual'] for x in imports),'import drift'
assert len(captures)==4 and all(x['sizeEqual'] and x['hashEqual'] for x in captures),'capture count or payload mismatch'
sys.exit(0 if code==1 and receipt['originalStrictAssertionObserved'] else 2)
