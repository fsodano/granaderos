# External medical preparation proposal

Status: proposal only. No observer, test, campaign, controller, prefix or native order was executed. Repository files and index are unchanged.

The current full942 run is terminal: 942 files selected, 6997 passed tests, 8 failed tests, 5 skipped, exit 1 and sourceDrift []. The original recovery failure is patient 112 HP15 versus maxHP64 at northern-route.mjs:250, called at fresh-campaign-recovery.test.mjs:84. The coastal hired route fails its stability assertion at fresh-coastal-fixture.mjs:176. Neither failure has a medical state payload.

## Proven source conflict

stageNorthernCare chooses stable doctors with HP >= 15, including wounded doctors (northern-route.mjs:147–149). prepareNorthernSquad includes every wounded local recruit in patients (178), sets those records to patient (221), then sets every selected doctor to doctor (222). A wounded selected doctor therefore loses the patient role. Native advanceMedicalCare selects only records assigned patient, and one doctor treats one different patient per hour (medical-care.js:139–149). Neither self-treatment nor treatment of a doctor-role record occurs. The final patient HP assertion is correct and must remain.

This conflict is proved from source. The assertion does not include the actual selected doctor IDs, assignments, start HP, supply or sleep state. It does not yet prove that actor 112 occupied both roles in this run. Observe that original state before installing a correction.

## One bounded observation

Entrypoint: tests/fresh-campaign-recovery.test.mjs. Run this one unchanged current recovery prefix once, only after root approval, with the external loader northern-medical-state-observer.mjs. Do not change the seed, content, controllers, original assertions or upstream combat. The original HP assertion remains and should retain its original failure.

Proposed command (not run):

```sh
/opt/homebrew/Cellar/node/25.9.0_2/bin/node --import /tmp/granaderos-medical-preparation-readonly-20261010T043331543729Z/northern-medical-state-observer.mjs --test tests/fresh-campaign-recovery.test.mjs
```

The loader checks the exact frozen northern source SHA ce34ec82c0caf30aa905ef3d06363d6de80f766c773727266c8a91c82eefd3ec. It requires all four exact source anchors to occur once. It adds an import plus passive capture calls, with no alternate gameplay branch. A mismatch leaves the original source unchanged and reports an observer error. Recorder errors do not suppress the original assertion. The observer runs no public engine selector or save encoder.

Four bounded snapshots are planned: the original prepare input; staged doctors/patients before supply collection; actual assigned roles immediately after the existing doctor assignments; and the complete campaign immediately before the unchanged full-health assertion. Each snapshot includes raw complete campaign records, declared doctor/patient IDs and available native event/supply histories. Original campaign values are cloned and compared in full without excluded fields. No independently deployed initial battle or official save is claimed. Each capture gets an exclusive PID/sequence/phase directory and a size/SHA receipt under /tmp/granaderos-medical-preparation-readonly-20261010T043331543729Z/observer-captures.

Use these snapshots to establish actor112 membership, HP trajectory, assignment overwrite, medical stock and retained local staff. Also inspect all selected doctors' HP/maxHP, bleeding, alive/captured, energy/fatigue/asleep, medkits, assignment, location/squad journey and contracts; actual content care rules; pending encounters/battle; care attention/logs; and the real finite supply debit. No new simulation is needed to inspect the retained snapshots.

## Minimal native-care method, after that observation

Limit the correction to wounded selected doctors in prepareNorthernSquad. Keep the same doctors, existing source gathering/courier mechanism, actual participants, strict final health assertion, native losses and finite supply accounting. Do not alter the engine's healing rate or custody rules.

1. Identify selected doctors who are also wounded patients from current records. While any remains, assign one such actor to patient and a different selected fit doctor to doctor. Use the native doctor qualification/admission gate before assignment: the treating doctor must be alive, uncaptured, local, stable at HP >= 15 with no bleeding, awake with energy > 10, and supplied. A wounded but stable doctor may legally treat another actor; this is how two wounded doctors can recover in sequence. First heal one through actual paid care, then swap roles and heal the other. Resume both doctor duties only after their actual wound care permits it.
2. If the treating doctor is sleeping or lacks energy, assign ordinary rest and wait actual paid campaign hours, retaining contracts and the target's valid patient/rest assignment. Re-evaluate after each actual hour. Do not force waking or promise a fixed number of healing ticks. Stable ordinary rest earns at most one HP per configured interval; patient assignment without a working physician does not earn ordinary health.
3. Give the treating doctor real carried/local dressings. If only the patient-doctor carries available stock, temporarily issue ordinary assignment and sectorInventory drop/take orders at the same clinic, with the public source key/expected object and an exact debit/credit check. Re-query reachable stock. Never duplicate kits or treat an abstract stock count as accessible inventory. If both lack stock, keep the existing gather/collectRouteMedicalSupplies path and use its real paid courier, route, capacity and source debit. Do not cycle recruitment or issue a refill.
4. Renew the actual doctors' and patients' contracts through existing renewContract orders before rest, treatment and courier travel. Use current expiry and quoted payment. A treatment hour consumes one native dressing and the configured energy/fatigue cost. Capture actual HP/bleeding/supply changes rather than assuming every hour healed: the first bleeding-care hour can stop bleeding without adding HP, and sleep/custody/transit or unsafe context can suspend care.
5. Never wait through an unresolved pendingEncounter. Preserve the current encounter guard and capture the actual blocker. If the caller already supplies a genuine encounter resolver, forward it to collectRouteMedicalSupplies and use its actual respondToEncounter/tactical/result dispatch path; require the real encounter to finish, native survivors/casualties to remain and pendingBattle to clear before resuming. Without such a resolver, stop with the unchanged strict encounter requirement. Do not add a synthetic result or a new combat policy to this care correction.
6. Return to the existing ordinary patient-care loop and unchanged all-patients-full-health assertion. Retain an honest terminal failure if supply, contracts, safe access, an actual defense or surviving medical capacity is insufficient. The current fixed 60-hour bound is not proof of progress. Decide whether its existing budget suffices from the genuine observed state and native rate; do not weaken the final requirement to fit the budget.

The smallest implementation is a care-role rotation at the existing per-hour loop, with explicit supplied treating-doctor selection and existing native rest/supply/contract gates. It is not a general rework of care or combat. No installable source patch is proposed until the original actor112 role conflict is captured.

Future bounded controls should declare two wounded stable selected doctors, one existing dressing holder, and no rival battle. Prove that only the patient gains native paid HP, the treating doctor spends one actual dressing/energy/fatigue, roles swap without grants, supplied rest resumes after exhaustion, insufficient stock remains an honest block, and input plus native result replay exactly. An actual earned prefix should be run only after root review; no test is run in this task.

## Separate coastal evidence

The field aid loop at fresh-coastal-fixture.mjs:139–140 considers only living nonrouted conscious actors and gives at most one self-heal when firstAidPlan is valid. Critical actors below15 are unconscious under native rules and cannot self-treat. An awake medic can legally aid a different critical patient through ordinary paid strokes, but the current general loop does not do that. autoBandageBattle is called only for the separate San Lorenzo mission-ally bleeding branch (124–137). firstAidPlan can need repeated finite strokes and does not restore ordinary wounded HP above the critical threshold. The hired clinic helper then schedules paid hires (172) and requires every field survivor already stable (176). This transition lacks a complete ordinary field-aid phase.

The current log does not name which coastal survivor failed, its HP/bleeding/energy/kit/position, or the sector. Do not invent those facts or call this a proven engine defect. No coastal instrument or policy is installed by this proposal. A separate later approved observation should retain the accepted post-battle exploration pair before the existing self-aid loop and the settled campaign/field/relief/hires/arrivals immediately before assertion176, without repeating settlement or combat.

## Native health and custody limits

Strategic medical care requires present recruited uncaptured actors, a safe site and no transit/deployment. One distinct patient per doctor per hour gets either bleeding stopped or configured HP healing; each hour spends one actual dressing. Ordinary rest needs no bleeding and HP >=15. Captives are excluded from ordinary care. Detention care uses confiscated physical dressings and an able guard, records each debit and only provides first aid to the critical threshold; it cannot fully heal a prisoner. Deaths cannot be restored by hiring, rest, first aid or a save round-trip. These rules remain unchanged.
