import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {appendFileSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/';
const out=process.env.GRANADEROS_OPENING_OBSERVER_DIR;
if(!out)throw Error('The external observer output directory is required.');
mkdirSync(out,{recursive:true});
const pid=process.pid,symbol=Symbol.for('granaderos.opening.observation.only');
const sha=raw=>createHash('sha256').update(raw).digest('hex');
const digest=value=>sha(JSON.stringify(value));
const snapshot=value=>structuredClone(value);
const append=(name,value)=>appendFileSync(`${out}/${name}`,JSON.stringify(value)+'\n');
const save=(name,value)=>writeFileSync(`${out}/${name}`,JSON.stringify(value,null,2)+'\n');
const hooks={
 'game/campaign.js':['dispatchCampaign'],
 'tests/northern-route.mjs':['fightNorthernSector','northernCombatOrder'],
 'tests/opening-driver.mjs':['fight','combatOrder'],
 'game/tactical.js':['actBattle','endTurn'],
};
const loaded=new Map(),errors=[],runs=[],northStack=[];
let api,diagnosticDepth=0,lastCampaign=null,currentRoute=null,currentFight=null,fightCount=0;
const counts={campaignCalls:0,acceptedCampaignCalls:0,actualApiCalls:0,northernDecisions:0,unsafeOriginalFires:0,unsafeWrapperNull:0,diagnosticAlternatives:0,diagnosticInputChecks:0,canonicalOrders:0};
const error=(stage,cause)=>{const row={pid,stage,message:cause?.stack??String(cause)};errors.push(row);append(`observer-errors-${pid}.ndjson`,row);};
const safely=(stage,callback)=>{try{return callback();}catch(cause){error(stage,cause);return undefined;}};
const diagnostic=(stage,inputs,callback)=>{
 const hashes=inputs.map(digest);diagnosticDepth++;
 try{return callback();}finally{
  diagnosticDepth--;
  inputs.forEach((input,index)=>assert.equal(digest(input),hashes[index],`${stage}: diagnostic changed a native input`));
  counts.diagnosticInputChecks+=inputs.length;
 }
};
const brief=b=>({battleId:b?.battleId,sector:b?.sectorId,turn:b?.turn,phase:b?.phase,mode:b?.mode,status:b?.status,startSeconds:b?.startSeconds,elapsedSeconds:b?.elapsedSeconds});
const pair=(name,campaign,battle)=>safely(`save pair ${name}`,()=>{
 const raw={campaign:snapshot(campaign),battle:snapshot(battle)};
 save(`${name}.native.json`,raw);
 const sourceHashes={campaign:digest(campaign),battle:digest(battle)};
 const official=diagnostic(`official pair ${name}`,[campaign,battle],()=>{
  const c=snapshot(campaign),b=snapshot(battle),before=[digest(c),digest(b)];
  const synced=api.syncBattleTime(c,b);assert.equal(synced.error,null);
  assert.equal(digest(c),before[0]);assert.equal(digest(b),before[1]);
  const text=api.encodeSave(synced.campaign,synced.battle),restored=api.decodeSave(text);
  assert.deepEqual(restored.campaign,synced.campaign);assert.deepEqual(restored.battle,synced.battle);
  writeFileSync(`${out}/${name}.save.json`,text+'\n');
  return {campaignSha256:digest(synced.campaign),battleSha256:digest(synced.battle),saveSha256:sha(text+'\n'),bytes:Buffer.byteLength(text+'\n'),clock:[synced.campaign.hour,synced.campaign.secondOfHour??0],battle:brief(synced.battle),roundTripExact:true};
 });
 save(`${name}.pair-receipt.json`,{pid,sourceHashes,official,scope:'Raw witnessed pair plus native clock/save on clones only. No tactical action or settlement.'});
 return {name,sourceHashes,official};
});

const observer={invoke(path,name,native,args){
 if(diagnosticDepth)return Reflect.apply(native,undefined,args);
 const routeBefore=currentRoute,fightBefore=currentFight;
 let north=null,beforeHash=null;
 safely(`before ${path}:${name}`,()=>{
  if(name==='fightNorthernSector'){
   currentRoute={number:runs.length+1,sector:args[1],start:snapshot(args[0]),startHash:digest(args[0]),inputSource:'actual unchanged fightNorthernSector argument',firstController:false,firstBlocked:false};
   runs.push(currentRoute);
   if(args[1]==='cordoba')save(`cordoba-route-${currentRoute.number}-accepted-campaign.native.json`,currentRoute.start);
  }
  if(name==='fight'){
   currentFight={number:++fightCount,route:currentRoute,request:snapshot(args[0]),previous:snapshot(args[1]),controllerName:args[2]?.controller?.name??'combatOrder',firstController:false,firstBlocked:false};
   if(currentRoute?.sector==='cordoba'){
    const id=args[0]?.id,candidates=[lastCampaign,currentRoute.start];
    currentFight.campaign=snapshot(candidates.find(c=>c?.pendingBattle?.id===id));
    assert.ok(currentFight.campaign,'the actual accepted campaign must match the exact native request');
    currentFight.prefix=`cordoba-fight-${currentFight.number}`;
    save(`${currentFight.prefix}-request-previous.native.json`,{request:currentFight.request,previous:currentFight.previous,controllerName:currentFight.controllerName,campaignSourceHash:digest(currentFight.campaign)});
   }
  }
  if(name==='northernCombatOrder'){
   counts.northernDecisions++;north={battle:args[0],unit:args[1],fight:currentFight,original:null};northStack.push(north);beforeHash=digest(args[0]);
   if(currentFight?.route?.sector==='cordoba'&&!currentFight.firstController){
    currentFight.firstController=true;
    currentFight.initial=pair('cordoba-before-first-controller',currentFight.campaign,args[0]);
   }
  }
  if(name==='dispatchCampaign')beforeHash=digest(args[0]);
 });
 let result;
 try{result=Reflect.apply(native,undefined,args);}catch(cause){
  safely(`native throw ${path}:${name}`,()=>append(`native-errors-${pid}.ndjson`,{path,name,battle:brief(args[0]),message:cause?.stack??String(cause)}));
  throw cause;
 }finally{
  if(name==='fightNorthernSector')currentRoute=routeBefore;
  if(name==='fight')currentFight=fightBefore;
 }
 const unchangedResultHash=digest(result??null);
 safely(`after ${path}:${name}`,()=>{
  if(name==='dispatchCampaign'){
   counts.campaignCalls++;if(!result.lastError){counts.acceptedCampaignCalls++;lastCampaign=result;}
   append(`campaign-orders-${pid}.ndjson`,{call:counts.campaignCalls,action:args[1],accepted:!result.lastError,error:result.lastError,beforeSha256:beforeHash,afterSha256:digest(result),clock:[result.hour,result.secondOfHour??0],pendingBattleId:result.pendingBattle?.id??null});
  }
  if(name==='combatOrder'){
   const enclosing=northStack.at(-1);if(enclosing&&enclosing.battle===args[0]&&enclosing.unit.id===args[1].id)enclosing.original=result;
  }
  if(name==='northernCombatOrder'){
   const b=args[0],u=args[1],original=north?.original;assert.equal(digest(b),beforeHash,'the original controller must leave its native battle unchanged');
   let preview=null,unsafe=false,alternative=null,known=null;
   if(original?.type==='fire'){
    preview=diagnostic('original public fire preview',[b,u,original,result],()=>{
     const target=b.units.find(v=>v.id===original.targetId);
     return target?api.firearmShotOptions(b,u,target,original.aim??0).find(v=>v.aim===(original.aim??0)&&v.hitLocation===(original.hitLocation??'torso'))??null:null;
    });
    unsafe=Boolean(preview?.interveningFriendly||preview?.shots?.some(v=>v.interveningFriendly));
   }
   if(unsafe){
    counts.unsafeOriginalFires++;
    if(!result){
     counts.unsafeWrapperNull++;
     if(north?.fight?.route?.sector==='cordoba'&&!north.fight.firstBlocked){north.fight.firstBlocked=true;north.fight.blocked=pair('cordoba-first-blocked-fire',north.fight.campaign,b);}
     alternative=diagnostic('native public alternative',[b,u,original,result],()=>{
      known=api.playerKnownBattle(b);const ids=new Set(known.units.map(v=>v.id)),npcs=new Set(known.npcs.map(v=>v.id)),guns=new Set(known.artillery.map(v=>v.id));
      const clone=snapshot(b);clone.units=clone.units.filter(v=>v.side==='player'||ids.has(v.id));clone.npcs=(clone.npcs??[]).filter(v=>npcs.has(v.id));clone.artillery=clone.artillery.filter(v=>v.side==='player'||guns.has(v.id));
      const own=clone.units.find(v=>v.id===u.id);assert.ok(own);const clonedBefore=digest(clone);
      const action=api.chooseEnemyAction(clone,own);assert.equal(digest(clone),clonedBefore,'the native alternative is a pure selection');
      let movement=null;
      if(action?.type==='move'){
       const point={x:action.x,y:action.y,tacticalLevel:action.tacticalLevel??api.tacticalLevel(own)},cells=new Set([...(known.tiles??[]),...(known.upperSurfaces??[])].map(api.spaceKey));
       const route=api.getReachable(clone,own,{stopAt:p=>api.spaceKey(p)===api.spaceKey(point)})[0];
       movement=route?{cost:route.cost,path:route.path,knownPath:route.path.every(p=>cells.has(api.spaceKey(p))),sameLevelPath:route.path.every(p=>api.tacticalLevel(p)===api.tacticalLevel(own)),remainingPA:own.ap-route.cost}:null;
      }
      counts.diagnosticAlternatives++;
      return {action,movement,unapplied:true,cloneInputUnchanged:true,knownUnitIds:[...ids],knownNpcIds:[...npcs],privateHiddenActorsExcluded:true};
     });
    }
   }
   const row={decision:counts.northernDecisions,fight:north?.fight?.number??null,battle:brief(b),actor:{id:u.id,x:u.x,y:u.y,tacticalLevel:api.tacticalLevel(u),ap:u.ap,hp:u.hp,stance:u.stance,loaded:u.loaded,ammo:u.ammo},original,current:result,unsafeOriginal:unsafe,preview:unsafe?preview:null,alternative,inputSha256:beforeHash,inputUnchanged:digest(b)===beforeHash};
   append(`controller-decisions-${pid}.ndjson`,row);
   if(unsafe&&north?.fight?.route?.sector==='cordoba')append(`cordoba-blocked-decisions-${pid}.ndjson`,row);
  }
  if(name==='actBattle'||name==='endTurn'){
   counts.actualApiCalls++;
   append(`battle-api-calls-${pid}.ndjson`,{call:counts.actualApiCalls,path,name,action:args[1]??{type:'endTurn'},before:brief(args[0]),after:brief(result),beforeSha256:digest(args[0]),afterSha256:digest(result),error:result.lastError,scope:'API call only. May be a controller preview; the unchanged fight result.orders is the canonical applied tape.'});
  }
  if(name==='fight'){
   // The completed native result is authoritative even when the parent then rejects retreat.
   const route=routeBefore;counts.canonicalOrders+=result.orders?.length??0;
   const number=fightCount,prefix=route?.sector==='cordoba'?`cordoba-fight-${number}`:`fight-${number}`;
   save(`${prefix}-native-orders.json`,result.orders);save(`${prefix}-terminal.native.json`,result.battle);
   append(`native-fight-results-${pid}.ndjson`,{number,sector:result.battle.sectorId,controller:args[2]?.controller?.name??'combatOrder',battle:brief(result.battle),actions:result.actions,orders:result.orders.length,battleSha256:digest(result.battle)});
   if(route?.sector==='cordoba'){
    const campaign=candidatesForTerminal(args[0]?.id,route);
    pair('cordoba-terminal',campaign,result.battle);
   }
  }
 });
 safely(`unchanged native result ${path}:${name}`,()=>assert.equal(digest(result??null),unchangedResultHash,'observation must not change the returned native result'));
 if(name==='northernCombatOrder')northStack.pop();
 return result;
}};
function candidatesForTerminal(id,route){const c=[route?.start,lastCampaign].find(c=>c?.pendingBattle?.id===id);assert.ok(c);return c;}
globalThis[symbol]=observer;

function transform(source,path){
 let runtime=source;
 for(const name of hooks[path]??[]){
  const token=`export function ${name}(`,start=runtime.indexOf(token);assert.ok(start>=0,`missing ${path}:${name}`);assert.equal(runtime.indexOf(token,start+token.length),-1,`duplicate ${path}:${name}`);
  const open=start+token.length-1;let depth=0,close=-1;
  for(let i=open;i<runtime.length;i++){if(runtime[i]==='(')depth++;else if(runtime[i]===')'&&!--depth){close=i;break;}}
  assert.ok(close>open);const parameters=runtime.slice(open,close+1),renamed=`__opening_observer_native_${name}`;
  runtime=runtime.slice(0,start)+runtime.slice(start).replace(`export function ${name}`,`function ${renamed}`);
  runtime+=`\nexport function ${name}${parameters}{return globalThis[Symbol.for('granaderos.opening.observation.only')].invoke(${JSON.stringify(path)},${JSON.stringify(name)},${renamed},Array.from(arguments));}\n`;
 }
 return runtime;
}
registerHooks({load(url,context,next){
 const result=next(url,context);if(!url.startsWith('file://'))return result;const absolute=fileURLToPath(url);if(!absolute.startsWith(repo)||result.source==null)return result;
 const path=absolute.slice(repo.length),original=typeof result.source==='string'?result.source:Buffer.from(result.source).toString('utf8'),runtime=transform(original,path),row={pid,path,originalSha256:sha(original),originalBytes:Buffer.byteLength(original),runtimeSha256:sha(runtime),runtimeBytes:Buffer.byteLength(runtime),wrapped:hooks[path]??[]};
 loaded.set(absolute,row);append(`source-original-runtime-${pid}.jsonl`,row);
 if(hooks[path])writeFileSync(`${out}/runtime-${pid}-${path.replaceAll('/','__')}`,runtime);
 return runtime===original?result:{...result,source:runtime};
}});

process.on('exit',code=>safely('exit receipt',()=>{
 const rows=[...loaded].map(([path,row])=>({...row,finalOriginalSha256:sha(readFileSync(path))})),drift=rows.filter(row=>row.originalSha256!==row.finalOriginalSha256);
 save(`source-final-receipt-${pid}.json`,{pid,exitCode:code,actualImports:rows.length,sourceDrift:drift,rows});
 save(`observer-final-receipt-${pid}.json`,{pid,exitCode:code,node:process.execPath,nodeVersion:process.version,counts,observerErrors:errors,sourceDrift:drift,runs:runs.map(r=>({number:r.number,sector:r.sector,startHash:r.startHash,inputSource:r.inputSource})),scope:'One unchanged original opening test execution. Native wrapper arguments/results passed unchanged. Diagnostic choices remain unapplied. Original and runtime source hashes are separate.'});
}));

const [tactical,ai,time,codec,known,space]=await Promise.all([
 import(repo+'game/tactical.js'),import(repo+'game/tactical-ai.js'),import(repo+'game/time.js'),import(repo+'game/save.js'),import(repo+'game/player-known-state.js'),import(repo+'game/tactical-space.js'),
]);
api={...tactical,chooseEnemyAction:ai.chooseEnemyAction,syncBattleTime:time.syncBattleTime,encodeSave:codec.encodeSave,decodeSave:codec.decodeSave,playerKnownBattle:known.playerKnownBattle,spaceKey:space.spaceKey,tacticalLevel:space.tacticalLevel};
save(`observer-start-${pid}.json`,{pid,node:process.execPath,nodeVersion:process.version,hooks,repo,out,scope:'Observation only. No native route has run during preload.'});
