# Unchanged opening observer proposal

This is a proposal only. No test, route, battle, replay, or native order was run to create it. The repository is frozen and unchanged.

## Execution after root authorization

Run the complete original tests/opening-playthrough.test.mjs once, with no test-name filter, no modified fixture, no changed controller, no injected report/executeBattle/deploy callback, and no replacement action. Proposed command from the active repair checkout:

    GRANADEROS_OPENING_OBSERVER_DIR=/tmp/granaderos-opening-current-safe-fire-observer-20261010 node --import /tmp/granaderos-opening-current-safe-fire-observer-20261010/preload.mjs --test tests/opening-playthrough.test.mjs > /tmp/granaderos-opening-current-safe-fire-observer-20261010/run.log 2>&1

The preload is not implemented or run by this proposal. It will use Node registerHooks and an external observer only. There will be one native test execution; observation is not a new policy trial.

## Hook boundary

Wrap only these seven named exports in four modules: game/campaign.js dispatchCampaign; tests/northern-route.mjs fightNorthernSector and northernCombatOrder; tests/opening-driver.mjs fight and combatOrder; game/tactical.js actBattle and endTurn. Each wrapper passes original arguments by reference, calls its original body once, and returns the identical native result by reference. Preserve the exported name and original formal/default parameters. Do not replace controller options or mutate any argument or result. Match each declaration exactly once; an unmatched transform is an observer error, never a silent rewritten source.

For every actual load, record the original returned source bytes before transformation, runtime bytes after transformation, byte lengths, file URL/path and both SHA256 values. Record a runtime file for each transformed module for review. At exit, compare all original imported bytes to current disk bytes, record exit code, observer errors, import count and drift. Four module runtime identities will differ deliberately; no source file on disk will change. Mark the untouched source test file separately.

## Genuine prefix and pair capture

Observe every original dispatchCampaign call/result and retain the accepted campaign command tape, with hours/seconds and before/after hashes. Capture the exact accepted campaign passed to the first fightNorthernSector call for sector cordoba before that native function runs. Preserve pendingBattle request, complete sector state, complete operative state and prior death/custody/resource/contract history.

On the first northernCombatOrder call in that same fight, capture the exact full battle argument before the original controller runs. Write the raw pair to cordoba-before-first-controller.native.json. Use native syncBattleTime and encodeSave on diagnostic clones only to write cordoba-before-first-controller.save.json; save the sync receipt and round-trip equality. Compare raw clock/startSeconds and pending battle identity. Preserve the raw pair even if sync/codec observation fails. This pairs the actual support-prepared campaign with the actual initial battle, without reconstructing a speculative attack or creating a new battle.

The current expected anchor is Córdoba startSeconds303070, 12 actual hired actors, original northernCombatOrder, and native retreat at turn11/134 actions/81seconds. These are comparison data only, not assertions that force an outcome. Any different input/result remains truthful evidence.

## Current decisions and alternatives

Maintain a call context keyed by the actual battle object and actor ID. Observe the combatOrder result which the original northernCombatOrder actually calls; do not call combatOrder again to manufacture an original decision. Observe the unchanged northernCombatOrder return value.

For an original fire order, use the current native firearmShotOptions forecast for exactly its actual target, aim and hitLocation. Record friendly-ray flags per hand, selected chance, damage factor and current public actor/target identity. When the original ray is unsafe, record whether the current wrapper chooses a safe shot, another paid action, or null.

Only for an unsafe original fire with current wrapper null, call the existing native chooseEnemyAction on a separate clone. This is a pure diagnostic selection; never apply its returned order. Exclude this diagnostic nesting from actual API/order tape recording. Check that its clone is unchanged. If the alternative is move, record its full native reachable path, actual AP cost and public known-cell/same-level coverage. Do not search alternate targets, seeds, forces, or controllers. Save the exact current input pair for the first such blocked decision as cordoba-first-blocked-fire.native.json and official save. Keep all diagnostic alternatives labelled unapplied; an alternative forecast is not a native admission or victory proof.

## Actual orders and terminal result

Capture original fight's returned result before fightNorthernSector asserts victory. Its returned orders array is the authority for the actual battle tape (including endTurn); record complete orders and terminal native battle in cordoba-native-orders.json and cordoba-terminal.native.json. actBattle/endTurn hook records are labelled API calls, because a controller may use actBattle for a pure candidate preview. Never treat every admitted API call as an applied player order. Reconcile only against the original fight result.orders and the actual controller input/result chain.

Write the official terminal campaign/battle pair on diagnostic clones and record clock sync/save round trip. The original victory assertion must still run and preserve its real failure/skip footer. Do not settle a new outcome or rerun controller actions. Capture any native assertion/error unchanged. If an invalid order prevents native fight from returning, preserve API/decision records and mark the canonical order tape incomplete.

## Receipts and limits

Produce campaign-orders.ndjson, controller-decisions.ndjson, battle-api-calls.ndjson, source-original-runtime-PID.jsonl, source-final-receipt-PID.json, input/source hashes, observer-errors.ndjson, native pairs/saves, native tape, run.log and final-receipt.json under this single external directory. Avoid stdout dumps of full private campaign payloads. Private records may be saved for exact replay but must not drive diagnostics or controls. Diagnostic choices use only existing native public forecasts/current sight and observed actor positions.

Observer failures must not change native returns, order selection, input, clocks, RNG, assertions or outcomes. Catch observer errors separately, retain them, and mark the receipt incomplete. Do not claim unchanged-run causal proof if source drift, injected actions, an incomplete genuine pair/tape, or observer failure occurs.

No result, admitted movement, altered battle outcome, or full campaign completion is claimed by this proposal. The exact full940 Córdoba pair has not yet been captured. Earlier Mendoza and Los Patos selection evidence is bounded to those genuine retained states.
