import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/';
const out='/tmp/granaderos-opening-current-safe-fire-observer-20261010';
const hooks={
 'game/campaign.js':['dispatchCampaign'],
 'tests/northern-route.mjs':['fightNorthernSector','northernCombatOrder'],
 'tests/opening-driver.mjs':['fight','combatOrder'],
 'game/tactical.js':['actBattle','endTurn'],
};
function transform(source,path){
 let runtime=source;
 for(const name of hooks[path]??[]){
  const token=`export function ${name}(`,start=runtime.indexOf(token);assert.ok(start>=0,`missing ${path}:${name}`);assert.equal(runtime.indexOf(token,start+token.length),-1,`duplicate ${path}:${name}`);
  const open=start+token.length-1;let depth=0,close=-1;
  for(let i=open;i<runtime.length;i++){if(runtime[i]==='(')depth++;else if(runtime[i]===')'&&!--depth){close=i;break;}}
  assert.ok(close>open);const parameters=runtime.slice(open,close+1),renamed=`__opening_observer_native_${name}`;
  runtime=runtime.slice(0,start)+runtime.slice(start).replace(`export function ${name}`,`function ${renamed}`);
  runtime+=`\nexport function ${name}${parameters}{return globalThis[Symbol.for('granaderos.opening.observation.only')].invoke(${JSON.stringify(path)},${JSON.stringify(name)},${renamed},Array.from(arguments));}\n`;
 }
 return runtime;
}
const rows=[];for(const path of Object.keys(hooks)){const original=readFileSync(repo+path,'utf8'),runtime=transform(original,path),target=out+'/syntax-'+path.replaceAll('/','__');writeFileSync(target,runtime);const result=spawnSync('/opt/homebrew/Cellar/node/25.9.0_2/bin/node',['--check',target],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);rows.push({path,exports:hooks[path],originalSha256:createHash('sha256').update(original).digest('hex'),runtimeSha256:createHash('sha256').update(runtime).digest('hex'),syntax:true});}writeFileSync(out+'/syntax-receipt.json',JSON.stringify({nativeExecution:false,rows},null,2)+'\n');console.log(JSON.stringify(rows));
