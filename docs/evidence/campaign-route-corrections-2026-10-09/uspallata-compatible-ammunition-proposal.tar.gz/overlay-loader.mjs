import {registerHooks} from 'node:module';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/';
const out='/tmp/granaderos-uspallata-compatible-ammunition-proposal-20261010/';
const overlays=new Map([[root+'tests/fresh-mountain-route.mjs',out+'fresh-mountain-route.candidate.mjs'],[root+'tests/fresh-mountain-ammunition.test.mjs',out+'fresh-mountain-ammunition.candidate.test.mjs']]);
const hashes=new Map();const sha=x=>createHash('sha256').update(x).digest('hex');
registerHooks({load(url,context,nextLoad){
 const result=nextLoad(url,context);
 if(!url.startsWith('file:'))return result;
 const path=fileURLToPath(url);if(!path.startsWith(root))return result;
 const original=readFileSync(path),source=overlays.has(path)?readFileSync(overlays.get(path)):result.source;
 hashes.set(path,{path:path.slice(root.length),originalSHA256:sha(original),runtimeSHA256:source===undefined||source===null?null:sha(source),overlay:overlays.get(path)??null});
 return overlays.has(path)?{...result,source}:result;
}});
process.on('exit',()=>{const modules=[...hashes.entries()].map(([path,r])=>({...r,afterSHA256:sha(readFileSync(path))}));writeFileSync(out+'overlay-runtime-'+process.pid+'.json',JSON.stringify({modules,originalSourceDrift:modules.filter(r=>r.originalSHA256!==r.afterSHA256)},null,2)+'\n');});
