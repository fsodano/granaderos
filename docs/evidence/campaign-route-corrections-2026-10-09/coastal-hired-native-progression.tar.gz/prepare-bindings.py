from pathlib import Path
import json,hashlib,subprocess,difflib
out=Path(__file__).resolve().parent;repo=Path('/Users/fsodano/.codex/worktrees/blast-structures/granaderos')
sha=lambda b:hashlib.sha256(b).hexdigest()
required={
 'tests/fresh-coastal-fixture.mjs':'8323db9352be2f08c92a9cf4e26d2b284f71eb52531a823b00f0f6245f888fd6',
 'tests/coastal-medical-readiness.mjs':'7e0caaac725fe9bcb395390bc10f06027facaa229f6e7c9b93ce91acd2794a77',
 'tests/coastal-medical-readiness.test.mjs':'afc7cd47df0cc6680f0320db09fe01c9c26a45ac2fbec908fe480f741df98b12',
 'tests/fixtures/coastal-medical-readiness.provenance.json':'e99f08dade64f4f4e44f9296d337878e4398f5c195ca0f217ec8668ed6238be8',
 'tests/fixtures/coastal-earned-ba-stable-005.json.gz':'222e2bce42f4603903e43b9c70d3a6be1e55bebfae914459a85950e19b429816',
 'tests/fixtures/coastal-earned-san-nicolas-empty-008.json.gz':'11cfc6ebfe3a2096c64a2a90af6ff4691c069966e51a7eaf2a0ef8c2e101ac4d',
 'tests/fresh-coastal-route.test.mjs':'8d3305f0fea5670bd72a9bdd2741e3d45df7dcab4407231172d8ee9f93558273'}
assert not (out/'preparation.json').exists(), 'Bindings already prepared; refuse overwrite'
for p,h in required.items():assert sha((repo/p).read_bytes())==h,p
paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard'],cwd=repo,text=True).splitlines()
manifest={p:sha((repo/p).read_bytes()) for p in sorted(set(paths)) if (repo/p).is_file() and Path(p).suffix in ['.js','.mjs','.cjs','.json','.ts','.tsx']}
(out/'current-source-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
cap=json.dumps(str(out/'observer-capture.mjs'))
def replace_once(s,a,b):
 assert s.count(a)==1, 'Passive anchor changed: '+a
 return s.replace(a,b)
transforms={}
for relative in ['tests/fresh-coastal-fixture.mjs','tests/coastal-medical-readiness.mjs','game/campaign.js']:
 original=(repo/relative).read_text();runtime=original
 if relative=='tests/fresh-coastal-fixture.mjs':
  runtime='import {coastalObserve,coastalObserveOrder} from '+cap+';\n'+runtime
  runtime=replace_once(runtime,"const tactical=(p,a)=>{const battle=a.type==='endTurn'?endTurn(p.battle):actBattle(p.battle,a);assert.equal(battle.lastError,null,battle.lastError);return sync({campaign:p.campaign,battle});};","const tactical=(p,a)=>{const battle=a.type==='endTurn'?endTurn(p.battle):actBattle(p.battle,a);assert.equal(battle.lastError,null,battle.lastError);const result=sync({campaign:p.campaign,battle});coastalObserveOrder(p,a,result);return result;};")
  runtime=replace_once(runtime,"  s=order(s,{type:'attack',sector});assert.ok(s.pendingBattle);", "  coastalObserve('before-original-departure',{kind,sector,campaign:s});\n  s=order(s,{type:'attack',sector});assert.ok(s.pendingBattle);")
  runtime=replace_once(runtime,"  const {battle,orders,actions}=engage(request,previous,", "  coastalObserve('before-original-battle',{kind,sector,campaign:s,request,previous});\n  const {battle,orders,actions}=engage(request,previous,")
  runtime=replace_once(runtime,"onBattleFinished?.({sector,battle,orders,actions});assert.equal(battle.status,'victory'", "coastalObserve('before-original-victory-assertion',{kind,sector,campaign:s,request,previous,battle,orders,actions});onBattleFinished?.({sector,battle,orders,actions});assert.equal(battle.status,'victory'")
  runtime=replace_once(runtime,"  let p={campaign:s,battle:enterSector(request,previous)};", "  let p={campaign:s,battle:enterSector(request,previous)};coastalObserve('before-existing-canonical-replay',{kind,sector,pair:p,orders,actions});")
  runtime=replace_once(runtime,"  p=tactical(p,{type:'explore'});", "  p=tactical(p,{type:'explore'});coastalObserve('before-all-existing-post-victory-aid',{kind,sector,pair:p});")
  runtime=replace_once(runtime,"   const fieldAid=autoBandageBattle(p.battle);for(const action of fieldAid.steps)p=tactical(p,action);", "   coastalObserve('before-native-hired-auto-aid',{kind,sector,pair:p});const fieldAid=autoBandageBattle(p.battle);coastalObserve('existing-native-auto-aid-result',{kind,sector,pair:p,aid:fieldAid});for(const action of fieldAid.steps)p=tactical(p,action);coastalObserve('after-native-aid-paid-replay',{kind,sector,pair:p,aid:fieldAid});")
  runtime=replace_once(runtime,"  p=saved(p);const resultReport={type:'battleResult'", "  coastalObserve('after-all-existing-post-victory-aid',{kind,sector,pair:p});\n  p=saved(p);const resultReport={type:'battleResult'")
  runtime=replace_once(runtime,"    if(auxiliary!==undefined){for(const id of field){assert.ok(s.operativeState[id].hp>=15&&!s.operativeState[id].bleeding,'stabilize the actual clinic patients before waiting for a physician');", "    coastalObserve('before-original-clinic-stability-assertion',{kind,sector,campaign:s,field,clinic,fieldSquad,auxiliary,hires,arrivals,quotes});\n    if(auxiliary!==undefined){for(const id of field){assert.ok(s.operativeState[id].hp>=15&&!s.operativeState[id].bleeding,'stabilize the actual clinic patients before waiting for a physician');")
  runtime=replace_once(runtime,"   const fieldAid=kind==='hired'?prepareCoastalFieldAid(s,{caregiverIds:auxiliary===undefined?[]:[auxiliary],report}):null;if(fieldAid)s=fieldAid.campaign;", "   coastalObserve('before-existing-field-readiness',{kind,sector,campaign:s,caregiverIds:auxiliary===undefined?[]:[auxiliary]});const fieldAid=kind==='hired'?prepareCoastalFieldAid(s,{caregiverIds:auxiliary===undefined?[]:[auxiliary],report}):null;if(fieldAid)s=fieldAid.campaign;coastalObserve('after-existing-field-readiness',{kind,sector,campaign:s,fieldAid});")
  runtime=replace_once(runtime," assert.equal(s.phase,2);assert.equal(s.flags.sanLorenzo,true);", " coastalObserve('before-original-route-final-assertions',{kind,campaign:s,notes,deaths:[...dead]});\n assert.equal(s.phase,2);assert.equal(s.flags.sanLorenzo,true);")
  runtime=replace_once(runtime," return {campaign:s,notes};", " coastalObserve('completed-original-route',{kind,campaign:s,notes});return {campaign:s,notes};")
 elif relative=='tests/coastal-medical-readiness.mjs':
  runtime='import {coastalObserve} from '+cap+';\n'+runtime
  runtime=replace_once(runtime,"  const found=collectRouteMedicalSupplies(c,courierId,needed,{report});c=found.campaign;safe();", "  coastalObserve('readiness-before-existing-native-collector',{campaign:c,courierId,needed,carried,medicId:medic.id,field,clinic});const found=collectRouteMedicalSupplies(c,courierId,needed,{report});c=found.campaign;coastalObserve('readiness-after-existing-native-collector',{campaign:c,courierId,needed,carried,medicId:medic.id,found});safe();")
  runtime=replace_once(runtime," return {campaign:saved({campaign:c}).campaign,readiness:proof};", " coastalObserve('before-existing-readiness-return-save',{campaign:c,readiness:proof});return {campaign:saved({campaign:c}).campaign,readiness:proof};")
 else:
  runtime='import {coastalObserveCampaignBefore,coastalObserveCampaignAfter} from '+cap+';\n'+runtime
  runtime=replace_once(runtime,"export function dispatchCampaign(previous,action){", "function coastalOriginalDispatchCampaign(previous,action){")
  runtime+='\nlet coastalObserverDispatchDepth=0;\nexport function dispatchCampaign(previous,action){const depth=coastalObserverDispatchDepth++;const token=coastalObserveCampaignBefore(previous,action,depth);try{const result=coastalOriginalDispatchCampaign(previous,action);coastalObserveCampaignAfter(previous,action,result,token);return result;}finally{coastalObserverDispatchDepth--;}}\n'
 name=relative.replace('/','--');(out/(name+'.original')).write_text(original);(out/(name+'.runtime')).write_text(runtime);(out/(name+'.observation.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True),runtime.splitlines(True),fromfile=relative+'.original',tofile=relative+'.runtime')))
 transforms[relative]={'originalSha256':sha(original.encode()),'runtimeSha256':sha(runtime.encode()),'runtimeFile':name+'.runtime','originalFile':name+'.original','scope':'Passive captures only; no extra gameplay API calls'}
files={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
prepared={'readyForNativeLaunch':True,'nativeCommandsExecuted':0,'scope':'Exactly one original hired coastal case with applied reviewed revision4. Three passive source transforms add logging only; original gameplay calls execute once at each original call site. No alternative controller/seed/deployment/checkpoint/model/engine/save/order calls. Original assertions remain.','repo':str(repo),'runtime':'/opt/homebrew/Cellar/node/25.9.0_2/bin/node','testFile':'tests/fresh-coastal-route.test.mjs','testName':'funded hired force wins the coastal opening with real losses, paid replacements and saved replay','requiredCandidateSources':{p:{'sha256':h,'bytes':(repo/p).stat().st_size} for p,h in required.items()},'transforms':transforms,'files':files,'sourceManifestCount':len(manifest),'orderTapeLimit':'Log actual dispatch calls and recursion depth. Only depth0 is the top-level native campaign tape; repeated rejected validation calls remain labeled. Logger never applies an action.','launchStatus':'Prepared only. Root controls and explicit launch approval are required.'}
(out/'preparation.json').write_text(json.dumps(prepared,indent=2)+'\n')
print('prepared',str(out));print('preparationSha256',sha((out/'preparation.json').read_bytes()));print('manifestCount',len(manifest));print(json.dumps(transforms,indent=2))
