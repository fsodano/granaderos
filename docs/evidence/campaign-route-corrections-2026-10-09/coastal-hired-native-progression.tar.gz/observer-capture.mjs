import assert from 'node:assert/strict';
import {writeFileSync,appendFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const out=new URL('.',import.meta.url).pathname.replace(/\/$/,'')+'/process-'+process.pid,sha=value=>createHash('sha256').update(value).digest('hex');let event=0,tacticalIndex=0,campaignIndex=0;
const clock=c=>({hour:c.hour,secondOfHour:c.secondOfHour??0});
const field=c=>c.squad.map(id=>({id,...Object.fromEntries(['alive','hp','bleeding','medkits','energy','fatigue','asleep','assignment'].map(key=>[key,c.operativeState[id]?.[key]]))}));
export function coastalObserve(name,value){
 const before=JSON.stringify(value),copy=structuredClone(value),raw=JSON.stringify(copy);assert.equal(JSON.stringify(value),before,'Passive capture changed an existing value');assert.deepEqual(copy,value);
 const filename=String(++event).padStart(3,'0')+'-'+name+'.json.gz',bytes=gzipSync(raw,{mtime:0});writeFileSync(out+'/'+filename,bytes,{flag:'wx'});appendFileSync(out+'/captures.jsonl',JSON.stringify({event,name,path:filename,rawSha256:sha(raw),gzipSha256:sha(bytes),rawBytes:Buffer.byteLength(raw),gzipBytes:bytes.length,diagnosticInputsUnchanged:true})+'\n');
}
export function coastalObserveOrder(before,action,after){
 const inputs={before,action,after},prior=JSON.stringify(inputs),copy=structuredClone(action),actor=pair=>pair.battle.units.find(u=>u.id===action.unitId),summary=u=>u?Object.fromEntries(['id','hp','bleeding','medkits','ap','energy','activeSlot','x','y','tacticalLevel'].map(key=>[key,u[key]])):null;
 appendFileSync(out+'/canonical-tactical-orders.jsonl',JSON.stringify({index:tacticalIndex++,action:copy,actorBefore:summary(actor(before)),actorAfter:summary(actor(after)),beforeClock:clock(before.campaign),afterClock:clock(after.campaign),elapsedBefore:before.battle.elapsedSeconds,elapsedAfter:after.battle.elapsedSeconds,lastError:after.battle.lastError,diagnosticInputsUnchanged:true})+'\n');assert.equal(JSON.stringify(inputs),prior,'Order logging changed native inputs/results');
}
export function coastalObserveCampaignBefore(previous,action,depth){
 const inputs={previous,action},prior=JSON.stringify(inputs),input=JSON.stringify(previous),copy=structuredClone(action),token={index:campaignIndex++,depth,action:copy,beforeSha256:sha(input),beforeString:input,beforeClock:clock(previous),beforeTreasury:previous.resources.treasury,beforeSeed:previous.seed,beforeField:field(previous)};assert.equal(JSON.stringify(inputs),prior,'Campaign input logging changed native inputs');return token;
}
export function coastalObserveCampaignAfter(previous,action,next,token){
 const inputs={previous,action,next},prior=JSON.stringify(inputs),result=JSON.stringify(next),{beforeString,...record}=token;
 const row={...record,afterSha256:sha(result),afterClock:clock(next),afterTreasury:next.resources.treasury,afterSeed:next.seed,afterField:field(next),accepted:next.lastError===null,lastError:next.lastError,diagnosticInputsUnchanged:true,nativePreviousChangedByOriginalCall:JSON.stringify(previous)!==beforeString};
 appendFileSync(out+'/native-campaign-calls.jsonl',JSON.stringify(row)+'\n');if(token.depth===0)appendFileSync(out+'/top-level-native-campaign-orders.jsonl',JSON.stringify(row)+'\n');
 if(next.lastError)coastalObserve('native-command-rejection',{previous,action:token.action,result:next,depth:token.depth});
 else if(next.pendingEncounter)coastalObserve('native-pending-encounter',{previous,action:token.action,result:next,depth:token.depth});
 else if(action.type==='sectorInventory'&&(action.item==='medkits'||action.expected?.includes('medkits')))coastalObserve('native-finite-medical-transfer',{previous,action:token.action,result:next,depth:token.depth});
 assert.equal(JSON.stringify(inputs),prior,'Campaign result logging changed native inputs/results');
}
