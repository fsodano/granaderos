import {registerHooks} from 'node:module';
import {readFileSync,appendFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const repo='/Users/fsodano/.codex/worktrees/blast-structures/granaderos/',out='/tmp/granaderos-full940-readonly-helper-audit-20261010',rows=new Map(),sha=v=>createHash('sha256').update(v).digest('hex');
registerHooks({load(url,c,next){const result=next(url,c);if(!url.startsWith('file://')||result.source==null)return result;const p=fileURLToPath(url);if(!p.startsWith(repo))return result;const row={path:p.slice(repo.length),sourceSha256:sha(result.source),bytes:Buffer.byteLength(result.source)};rows.set(p,row);appendFileSync(out+'/native-forecast-imports.jsonl',JSON.stringify(row)+'\n');return result;}});
process.on('exit',exitCode=>{const records=[...rows.entries()].map(([path,row])=>({...row,finalSha256:sha(readFileSync(path))}));writeFileSync(out+'/native-forecast-import-closure.json',JSON.stringify({exitCode,actualImports:records.length,sourceDrift:records.filter(r=>r.sourceSha256!==r.finalSha256),records},null,2)+'\n');});
