# San Lorenzo shot-safety proposal

This is an external proposal. The repository and index were not changed.
No game module, test, tactical order, replay, or strategy trial was executed.

The original coastal caller already passes avoidCivilians:true. The original
local San Lorenzo wrapper drops that option. The original ranked options do
not reject the public known-friendly flags, including each actual pistol hand.

The proposed wrapper honors only avoidCivilians. The existing shot score,
25-percent ranked threshold, iteration/tie order, aim limits, AP/movement
budgets, healing/melee/rally/search priorities, automatic fallback and opening
fight loop remain unchanged. A shared fire predicate rejects known unsafe rays
at final acceptance, so fallback cannot bypass the same checks. Non-fire orders
pass through that predicate without extra restrictions.

Known civilian risks come from firearmFlightPreview, which already limits the
forecast to visible/known bodies and uses canonical surfaces and typed body
impacts. The primary and actual paired offhand are checked separately. The
proposal does not inspect hidden civilians or draw RNG to predict a miss.

The new test file has eight declared geometry cases. It makes no earned
campaign wound, equipment, casualty, recovery, saved-replay or victory claim.
The original controller's immutable native legality probes remain in place;
selection leaves the supplied state unchanged. The direct final-boundary case
is labeled as a declared fallback-shaped action, not an observed automatic order.

Review the receipt limits before execution. All proposed geometry preconditions
are unverified. Source-freeze closure and root review are required before any
repository application or game/test execution. Native outcomes may change after
unsafe orders are excluded. The retained San Lorenzo defeat stays valid evidence.
