import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {decodeSave} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/save.js';
import {syncBattleTime} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/time.js';
const root='/tmp/granaderos-route-failure-recorder-control-20261010',witness='/tmp/granaderos-opening-current-safe-fire-observer-20261010';
const read=(base,name)=>JSON.parse(readFileSync(base+'/'+name,'utf8')),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const input=read(witness,'cordoba-before-first-controller.native.json'),rawResult={battle:read(witness,'cordoba-fight-3-terminal.native.json'),actions:134,orders:read(witness,'cordoba-fight-3-native-orders.json')};
const synced=syncBattleTime(structuredClone(input.campaign),structuredClone(rawResult.battle));assert.equal(synced.error,null);
const dirs=readdirSync(root);assert.equal(dirs.length,2);const captures=[];
for(const name of dirs){
 const base=root+'/'+name,receipt=read(base,'receipt.json');
 assert.equal(receipt.officialTerminalPair,true);assert.equal(receipt.orders,162);assert.equal(receipt.additionalOrders,0);assert.equal(receipt.settlementExecuted,false);
 assert.equal(receipt.trueInitialBattleCaptured,false);assert.equal(receipt.preExecutionInputIndependentlyCaptured,false);
 for(const row of receipt.artifacts){const bytes=readFileSync(base+'/'+row.path);assert.equal(bytes.length,row.bytes);assert.equal(sha(bytes),row.sha256);}
 assert.deepEqual(read(base,'native-input.json'),JSON.parse(JSON.stringify({campaign:input.campaign,request:input.campaign.pendingBattle,previous:input.campaign.sectorStates.cordoba})));
 assert.deepEqual(read(base,'native-result.json'),rawResult);
 const official=decodeSave(readFileSync(base+'/terminal.save.json','utf8'));assert.deepEqual(official.campaign,synced.campaign);assert.deepEqual(official.battle,synced.battle);
 captures.push({directory:name,receiptSha256:sha(readFileSync(base+'/receipt.json')),payloads:receipt.artifacts.length,officialPairExact:true,rawInputAndResultExact:true});
}
const receipt={scope:'Zero-order artifact exercise plus one read-only closure on its two retained captures. No additional recorder call, native order, turn, battle or settlement.',runtime:process.execPath,nodeVersion:process.version,initialArtifactExercise:{exitCode:1,disabledWrites:0,enabledCaptures:2,inputUnchangedAssertionPassedBeforeFailure:true,priorCaptureUnchangedAssertionPassed:true,failure:'The control incorrectly compared the saved/synced battle directly to the raw terminal. Only savedHour/savedSecond/syncedSeconds differ as required by native clock sync.'},readOnlyClosure:{exitCode:0,retainedCaptures:captures,allPayloadHashesExact:true,rawInputAndResultExact:true,officialSyncedPairsExact:true,additionalRecorderCalls:0,additionalOrders:0},helperSha256:sha(readFileSync('/Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/route-failure-evidence.mjs'))};
writeFileSync(root+'/control-receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
