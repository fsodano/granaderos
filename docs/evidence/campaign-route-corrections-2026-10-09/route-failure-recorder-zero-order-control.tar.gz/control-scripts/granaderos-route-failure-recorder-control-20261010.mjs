import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {recordRouteBattleFailure} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/route-failure-evidence.mjs';
import {decodeSave} from '/Users/fsodano/.codex/worktrees/blast-structures/granaderos/game/save.js';
const root='/tmp/granaderos-route-failure-recorder-control-20261010';
const witness='/tmp/granaderos-opening-current-safe-fire-observer-20261010';
const read=name=>JSON.parse(readFileSync(witness+'/'+name,'utf8'));
const input=read('cordoba-before-first-controller.native.json');
const result={battle:read('cordoba-fight-3-terminal.native.json'),actions:134,orders:read('cordoba-fight-3-native-orders.json')};
const args={campaign:input.campaign,request:input.campaign.pendingBattle,previous:input.campaign.sectorStates.cordoba,result,expectedOutcome:'victory'};
const before=structuredClone(args),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(result.orders.length,162);assert.equal(result.battle.status,'retreat');assert.ok(args.request);
assert.equal(existsSync(root),false);
delete process.env.GRANADEROS_CAMPAIGN_FAILURE_DIR;
recordRouteBattleFailure(args);assert.equal(existsSync(root),false);assert.deepEqual(args,before);
process.env.GRANADEROS_CAMPAIGN_FAILURE_DIR=root;
recordRouteBattleFailure(args);
const first=readdirSync(root);assert.equal(first.length,1);
const originalReceipt=readFileSync(root+'/'+first[0]+'/receipt.json');
recordRouteBattleFailure(args);
const directories=readdirSync(root);assert.equal(directories.length,2);assert.deepEqual(args,before);
assert.deepEqual(readFileSync(root+'/'+first[0]+'/receipt.json'),originalReceipt);
const results=[];
for(const name of directories){
 const base=root+'/'+name,receipt=JSON.parse(readFileSync(base+'/receipt.json','utf8'));
 assert.equal(receipt.orders,162);assert.equal(receipt.additionalOrders,0);assert.equal(receipt.settlementExecuted,false);
 assert.equal(receipt.officialTerminalPair,true,receipt.officialTerminalPairError);
 assert.equal(receipt.trueInitialBattleCaptured,false);assert.equal(receipt.preExecutionInputIndependentlyCaptured,false);
 for(const row of receipt.artifacts){const bytes=readFileSync(base+'/'+row.path);assert.equal(bytes.length,row.bytes);assert.equal(sha(bytes),row.sha256);}
 assert.deepEqual(JSON.parse(readFileSync(base+'/native-result.json','utf8')),result);
 const saved=decodeSave(readFileSync(base+'/terminal.save.json','utf8'));
 assert.deepEqual(saved.battle,result.battle);
 results.push({directory:name,receiptSha256:sha(readFileSync(base+'/receipt.json')),officialTerminalPair:true,artifactHashesExact:true});
}
const receipt={scope:'Zero-order artifact control on retained genuine original Córdoba failed result. Its162 orders are copied as payload only; no tactical/campaign order, turn, new battle/controller or settlement is executed.',runtime:process.execPath,nodeVersion:process.version,inputUnchanged:true,disabledWrites:0,enabledCaptures:2,independentDirectories:true,priorCaptureUnchanged:true,additionalOrders:0,results,sourceSha256:sha(readFileSync('/Users/fsodano/.codex/worktrees/blast-structures/granaderos/tests/route-failure-evidence.mjs'))};
writeFileSync(root+'/control-receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
