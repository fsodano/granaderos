# External bounded northern posture fallback

This proposal changes only the known-unsafe original firearm branch after its native known-view chooser returns null. The existing native move/nonfire alternative stays first. A new paid posture must leave an affordable safe shot with chance at least 25 percent and positive damage factor. It uses the lowest native stance cost, lowered gun readiness, reduced AP, real momentum reset and the public squad view. Original firearm scores, ties and other actions remain unchanged. The clinic roof veto is unchanged.

The earned original Córdoba and genuine Mendoza fixtures are pure selector controls. No alternate order was applied there. The fixture is the exact already retained official Córdoba save, compressed without content changes. The physical stance payment controls use a separate declared tactical arena, with explicit initial AP/readiness and finite inventory. Validated JSON replay is not an official campaign save proof. No campaign battle, fire, turn loop or outcome grant was run.

Unchanged-current baseline: two pass, one missing-posture failure. Patched external controls: twelve pass. Candidate inputs: 302 files, no drift. The full campaign outcomes remain unproved by these bounded controls.

To install after root review, apply northern-safe-posture-text-install.patch and copy northern-known-friendly-posture.save.json.gz to tests/fixtures/northern-known-friendly-posture.save.json.gz. This external copy has not been installed in the candidate by this agent.

The single authorized pure AP12 input clone did not reach the unsafe-original-fire branch: ordinary combatOrder already returned null. Its crouch quote leaves nine AP against ten AP fire costs. This negative probe is retained; no extra budget or policy search was made and no branch regression was added.
