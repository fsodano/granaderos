import {writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
const sha=v=>createHash('sha256').update(v).digest('hex');
export function captureReturnedKitObservation({c,ids,operativeId,slot,worn,model,carried,source,originalRoster,blade}){
 const context=globalThis[Symbol.for('granaderos.passive.returned-kit.observer')];
 if(!context)throw Error('Passive observer context is missing');
 try{
  const beforeCampaign=sha(JSON.stringify(c)),beforeModel=sha(JSON.stringify(model));
  const raw=JSON.stringify(c,null,2)+'\n',record=c.operativeState?.[operativeId];
  const locals=JSON.stringify({ids,operativeId,slot,worn:worn??null,wornUndefined:worn===undefined,wornRecordHasSlot:Object.hasOwn(record??{},slot),model,carried:carried??null,source:source??null,originalRoster,blade:blade??null},null,2)+'\n';
  const receipt={scope:'Existing local values captured immediately before unchanged original missing-kit assertion. No extra native model/engine/save/order call.',capturePhase:'immediate pre-assertion',pid:process.pid,operativeId,slot,campaignBytes:Buffer.byteLength(raw),campaignSha256:sha(raw),localsBytes:Buffer.byteLength(locals),localsSha256:sha(locals),beforeCampaignSha256:beforeCampaign,afterCampaignSha256:sha(JSON.stringify(c)),beforeModelSha256:beforeModel,afterModelSha256:sha(JSON.stringify(model)),originalAssertionUnchanged:true,additionalOrders:0,additionalModelCalls:0,additionalEngineCalls:0,officialSaveClaimed:false};
  if(receipt.beforeCampaignSha256!==receipt.afterCampaignSha256||receipt.beforeModelSha256!==receipt.afterModelSha256)throw Error('Passive serialization changed input');
  if(context.captured||existsSync(context.directory+'/pre-assertion.campaign.json'))throw Error('A passive checkpoint already exists; refuse overwrite');
  context.captured=true;
  writeFileSync(context.directory+'/pre-assertion.campaign.json',raw,{flag:'wx'});
  writeFileSync(context.directory+'/pre-assertion.locals.json',locals,{flag:'wx'});
  writeFileSync(context.directory+'/pre-assertion.receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
  console.error('PASSIVE_RETURNED_KIT_CAPTURE '+JSON.stringify({directory:context.directory,operativeId,slot,campaignSha256:receipt.campaignSha256,localsSha256:receipt.localsSha256}));
 }catch(error){console.error('PASSIVE_RETURNED_KIT_CAPTURE_ERROR '+String(error));}
}
