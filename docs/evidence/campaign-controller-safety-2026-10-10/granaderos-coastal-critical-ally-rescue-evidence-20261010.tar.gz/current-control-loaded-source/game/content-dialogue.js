import {validateContentQuestState} from './content-quests.js';
import {validateDialogueEffects,dialogueEffectQuote,applyDialogueEffects,validateDialogueReceipts,validateLastDialogueEffect} from './dialogue-effects.js';
import {validateDialogueConditions,dialogueConditionsMet} from './dialogue-conditions.js';
import {characterForOperative} from './content-character-ids.js';
const need=(ok,message)=>{if(!ok)throw Error(message);};
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const id=v=>typeof v==='string'&&/^[a-z][a-z0-9-]{0,59}$/.test(v)&&!['constructor','prototype'].includes(v);
const text=(v,max)=>typeof v==='string'&&v.trim().length>0&&v.length<=max;
const fields=(v,keys)=>object(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
export function validateDialogue(graph,characters,quests){
 need(fields(graph,['entry','nodes'])&&id(graph.entry)&&Array.isArray(graph.nodes)&&graph.nodes.length>=1&&graph.nodes.length<=30,'El diálogo necesita un comienzo y entre 1 y 30 pasajes.');
 const ids=new Set();
 for(const node of graph.nodes){
  need(fields(node,['id','title','text','choices'])&&id(node.id)&&!ids.has(node.id)&&text(node.title,80)&&text(node.text,1000)&&Array.isArray(node.choices)&&node.choices.length<=12,'Cada pasaje necesita identidad, título, texto y hasta 12 opciones válidas.');ids.add(node.id);
  const choices=new Set();for(const c of node.choices){need(object(c)&&['id','label','next'].every(k=>Object.hasOwn(c,k))&&Object.keys(c).every(k=>['id','label','next','conditions','effects'].includes(k))&&id(c.id)&&!choices.has(c.id)&&text(c.label,160)&&id(c.next),'Las opciones del diálogo no son válidas.');choices.add(c.id);validateDialogueConditions(c.conditions,characters,quests);validateDialogueEffects(c.effects,quests,characters);}
 }
 need(ids.has(graph.entry)&&graph.nodes.every(n=>n.choices.every(c=>ids.has(c.next))),'El comienzo o un destino del diálogo no existe.');

}
const definition=(s,npc)=>characterForOperative(s,npc?.operativeId)?.encounter?.dialogue;
const view=(s,npc,node,battle)=>({node:node.id,text:node.text,choices:node.choices.filter(c=>dialogueConditionsMet(s,c.conditions,battle)).map(c=>{const quote=dialogueEffectQuote(s,npc,node.id,c,battle);return {id:c.id,label:c.label,...(quote?{effectLabel:quote.label,available:quote.available,reason:quote.reason}:{})};})});
export function dialogueForNPC(s,npc,battle=null){
 const graph=definition(s,npc);if(!graph)return null;
 const node=graph.nodes.find(n=>n.id===(s.conversations?.[npc.id]?.dialogueNode??graph.entry));
 need(node,'El pasaje guardado no pertenece al diálogo.');
 return view(s,npc,node,battle);
}
export function chooseDialogue(s,npc,choice,expectedNode,battle=null){
 const current=dialogueForNPC(s,npc,battle);need(current,'Este habitante no tiene un diálogo con opciones.');
 if(choice===undefined){need(expectedNode===undefined,'Falta la opción del diálogo.');return current;}
 need(expectedNode===current.node,'La conversación cambió. Elegí una opción del pasaje actual.');
 const graph=definition(s,npc),node=graph.nodes.find(n=>n.id===current.node),selected=node.choices.find(c=>c.id===choice);need(selected,'Esa opción no pertenece al pasaje actual.');need(current.choices.some(c=>c.id===choice),'Esa opción no está disponible en este momento.');
 const effect=applyDialogueEffects(s,npc,node.id,selected,battle),next=graph.nodes.find(n=>n.id===selected.next);return {...view(s,npc,next,battle),...(effect?{effect}:{})};
}
export function validateSavedDialogues(s,npcs){
 for(const [npcId,record]of Object.entries(s.conversations??{})){
  const npc=npcs.find(n=>n.id===npcId),graph=definition(s,npc);validateDialogueReceipts(s,graph,record);
  if(record.dialogueNode!==undefined)need(graph?.nodes.some(n=>n.id===record.dialogueNode),'El pasaje guardado no pertenece al diálogo.');
  if(record.lastApproach==='dialogue')need(record.dialogueNode!==undefined&&graph,'Falta el pasaje de la conversación guardada.');
 }
 validateContentQuestState(s,npcs);
 const last=s.lastConversation,npc=npcs.find(n=>n.id===last?.npcId);validateLastDialogueEffect(s,npc,definition(s,npc),last);if(last?.outcome!=='dialogue')return;
 const current=dialogueForNPC(s,npc);
 need(current&&last.dialogueNode===current.node&&last.text===current.text&&s.conversations[last.npcId]?.lastApproach==='dialogue','El texto guardado no coincide con el diálogo del habitante.');
}
