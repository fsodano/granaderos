import {readFileSync,writeFileSync,existsSync,statSync} from 'node:fs';
import {resolve,dirname,relative} from 'node:path';
import {createHash} from 'node:crypto';
const repository='/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos',directory=process.argv[2],phase=process.argv[3];
const pending=[resolve(repository,'tests/tucuman-earned-ammunition.test.mjs'),resolve(repository,'tests/fixtures/tucuman-earned-ammunition-preparation.save.json.gz'),resolve(repository,'tests/fixtures/tucuman-earned-ammunition-preparation.provenance.json')],seen=new Set(),files=[];
while(pending.length){const file=pending.pop();if(seen.has(file))continue;seen.add(file);const bytes=readFileSync(file);files.push({path:relative(repository,file),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
 if(!/\.(?:m?js|cjs)$/.test(file))continue;
 const text=bytes.toString('utf8');
 for(const match of text.matchAll(/(?:\bfrom\s*|\bimport\s*)(['"])([^'"\n]+)\1/g))if(match[2].startsWith('.')){const imported=resolve(dirname(file),match[2]);if(existsSync(imported)&&statSync(imported).isFile())pending.push(imported);}
}
files.sort((a,b)=>a.path.localeCompare(b.path));
const snapshot={node:process.version,repository,entry:'tests/tucuman-earned-ammunition.test.mjs',fixtureAdmission:'official decodeSave of identical independently earned save bytes',files};writeFileSync(resolve(directory,phase+'-source-graph.json'),JSON.stringify(snapshot,null,2)+'\n');
if(phase==='after'){const prior=JSON.parse(readFileSync(resolve(directory,'before-source-graph.json'))),old=new Map(prior.files.map(file=>[file.path,file.sha256])),current=new Map(files.map(file=>[file.path,file.sha256]));const drift=[...new Set([...old.keys(),...current.keys()])].filter(path=>old.get(path)!==current.get(path));writeFileSync(resolve(directory,'source-drift.json'),JSON.stringify({files:files.length,drift})+'\n');if(drift.length)process.exitCode=1;}
else writeFileSync(resolve(directory,'invocation.json'),JSON.stringify({node:process.version,test:snapshot.entry,admission:'corrected official decoder',authorizedInvocations:1,previousAdmissionFailure:'/tmp/granaderos-tucuman-earned-ammunition-correction-2026-10-10T085004629Z',previousNativeEvents:[],scope:'One original corrected preparation. No full route or battle execution.'})+'\n');
console.log(JSON.stringify({phase,files:files.length}));
