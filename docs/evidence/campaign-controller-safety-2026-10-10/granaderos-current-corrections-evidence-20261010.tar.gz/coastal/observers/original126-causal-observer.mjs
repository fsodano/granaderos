import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {enterSector} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/world.js';
import {actBattle,endTurn,teamCanSee,firearmShotOptions,firearmFlightPreview,actionCosts,hasFirearm} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/tactical.js';
const root='/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos';
const inputRoot='/tmp/granaderos-current-coastal-single-diagnostic-2026-10-10T083117310Z';
const output='/tmp/granaderos-coastal-original126-causal-20261010';
mkdirSync(output);
const hash=b=>createHash('sha256').update(b).digest('hex');
const bound=name=>{const bytes=readFileSync(inputRoot+'/'+name);return {name,bytes:bytes.length,sha256:hash(bytes)};};
const input=JSON.parse(readFileSync(inputRoot+'/san_lorenzo-before-execution.json'));
const result=JSON.parse(readFileSync(inputRoot+'/san_lorenzo-raw-result.json'));
assert.equal(result.orders.length,126);
const expectedPin=JSON.parse(readFileSync(inputRoot+'/before-source-hashes.json'));
const imports=['game/world.js','game/tactical.js','tests/local-san-lorenzo-driver.mjs','tests/opening-driver.mjs','tests/route-fire-safety.mjs','tests/fresh-coastal-fixture.mjs'];
const checkSources=()=>Object.fromEntries(imports.map(path=>{const actual=hash(readFileSync(root+'/'+path));assert.equal(actual,expectedPin[path],path);return [path,actual];}));
const sourceBefore=checkSources();
const live=u=>u.hp>0&&!u.departure&&!u.surrendered&&!u.unconscious&&!u.routed;
const publicEnemies=b=>b.units.filter(u=>u.side==='enemy'&&live(u)&&teamCanSee(b,'player',u));
const brief=u=>Object.fromEntries(['id','side','missionAlly','x','y','tacticalLevel','hp','maxHp','bleeding','energy','morale','ap','loaded','ammo','jammed','activeSlot','stance','weaponReady','weaponDropped','routed','unconscious','medkits','condition'].filter(k=>u[k]!==undefined).map(k=>[k,u[k]]));
const newLog=(a,b)=>{let overlap=Math.min(a.length,b.length);while(overlap&&!a.slice(-overlap).every((line,i)=>line===b[i]))overlap--;return b.slice(overlap);};
const commanderView=b=>{
 const u=b.units.find(u=>u.id==='57'),infantry=b.units.filter(u=>u.side==='player'&&!u.missionAlly&&live(u)&&u.hp>=15),visible=publicEnemies(b);
 const distances=infantry.map(t=>({id:t.id,distance:Math.hypot(t.x-u.x,t.y-u.y)})).sort((a,b)=>a.distance-b.distance);
 const shots=[];
 if(live(u)&&hasFirearm(u)&&u.loaded&&!u.jammed)for(const target of visible){
  const cost=actionCosts(b,u,target);if(u.ap<cost.fire)continue;
  const maxAim=Math.min(4,Math.floor((u.ap-cost.fire)/cost.aim));
  for(const shot of firearmShotOptions(b,u,target,maxAim)){
   const flight=firearmFlightPreview(b,u,target,shot.hitLocation);
   if(shot.chance>=25&&!shot.interveningFriendly&&!shot.shots?.some(hand=>hand.interveningFriendly)&&flight.victimKind!=='npc'&&!flight.bodyImpacts?.some(impact=>impact.victimKind==='npc'))shots.push({target:target.id,aim:shot.aim,hitLocation:shot.hitLocation,chance:shot.chance,fireAP:cost.fire,aimAP:cost.aim});
  }
 }
 return {actor:brief(u),supported:!infantry.length||distances.some(d=>d.distance<8),nearestInfantry:distances[0]??null,visibleEnemies:visible.map(brief),affordableSafeShots:shots};
};
let battle=enterSector(input.request,input.previous);
const initial=structuredClone(battle);writeFileSync(output+'/derived-initial-battle.json',JSON.stringify(initial,null,2)+'\n');
const rows=[];const initialPlayers=battle.units.filter(u=>u.side==='player').map(brief);
for(let index=0;index<result.orders.length;index++){
 const action=result.orders[index],before=battle,unit=before.units.find(u=>u.id===action.unitId),commander=commanderView(before),visible=publicEnemies(before);
 const forecast=action.type==='fire'?firearmShotOptions(before,unit,before.units.find(u=>u.id===action.targetId),action.aim??0).find(s=>s.aim===(action.aim??0)&&s.hitLocation===(action.hitLocation??'torso')):null;
 battle=action.type==='endTurn'?endTurn(before):actBattle(before,action);assert.equal(battle.lastError,null,`order ${index+1}`);
 const changes=battle.units.flatMap(after=>{const old=before.units.find(u=>u.id===after.id);return old&&['hp','bleeding','morale','routed','unconscious'].some(k=>old[k]!==after[k])?[{before:brief(old),after:brief(after)}]:[];});
 rows.push({order:index+1,action,turnBefore:before.turn,turnAfter:battle.turn,phaseBefore:before.phase,phaseAfter:battle.phase,statusAfter:battle.status,elapsedBefore:before.elapsedSeconds,elapsedAfter:battle.elapsedSeconds,actorBefore:unit?brief(unit):null,actorAfter:unit?brief(battle.units.find(u=>u.id===unit.id)):null,visibleEnemiesBefore:visible.map(brief),commanderBefore:commander,forecast:forecast?{chance:forecast.chance,damageFactor:forecast.damageFactor,aim:forecast.aim,hitLocation:forecast.hitLocation,interveningFriendly:forecast.interveningFriendly}:null,changes,newLog:newLog(before.log??[],battle.log??[])});
}
assert.deepEqual(battle,result.battle);const sourceAfter=checkSources();assert.deepEqual(sourceAfter,sourceBefore);
writeFileSync(output+'/order-observations.json',JSON.stringify(rows,null,2)+'\n');
const casualties=rows.flatMap(row=>row.changes.filter(c=>c.after.side==='player'&&(c.after.hp===0||c.before.routed!==c.after.routed||c.before.unconscious!==c.after.unconscious)).map(c=>({order:row.order,action:row.action,turn:row.turnAfter,...c,newLog:row.newLog})));
const receipt={inputRoot,inputs:['san_lorenzo-before-execution.json','san_lorenzo-raw-result.json'].map(bound),originalOrders:126,originalActions:result.actions,allOrdersAccepted:true,rawTerminalDeepEqual:true,initialCapture:'derived once from independently observed pre-execution request and previous state; not an independently observed live initial battle',initialPlayers,terminalPlayers:battle.units.filter(u=>u.side==='player').map(brief),casualties,sourceBefore,sourceAfter,sourceDrift:[],controllerInvocations:0,alternativeOrders:0,additionalCampaignSettlement:0};
writeFileSync(output+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({output,orders:rows.length,rawTerminalDeepEqual:true,sourceDrift:0,receiptBytes:readFileSync(output+'/receipt.json').length,receiptSha256:hash(readFileSync(output+'/receipt.json'))}));
