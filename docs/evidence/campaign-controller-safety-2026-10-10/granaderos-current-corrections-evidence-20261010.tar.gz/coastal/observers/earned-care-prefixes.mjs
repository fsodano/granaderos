import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {enterSector} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/world.js';
import {actBattle,endTurn,interruptAvailable,actionCosts,hasLineOfSight} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/tactical.js';
import {sameSurface} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/tactical-space.js';
import {firstAidPlan,criticalFirstAidNeeded} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/first-aid.js';
import {localSanLorenzoOrder} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/tests/local-san-lorenzo-driver.mjs';
const inputRoot='/tmp/granaderos-current-coastal-single-diagnostic-2026-10-10T083117310Z';
const output='/tmp/granaderos-coastal-earned-care-prefixes-20261010';mkdirSync(output);
const input=JSON.parse(readFileSync(inputRoot+'/san_lorenzo-before-execution.json'));
const result=JSON.parse(readFileSync(inputRoot+'/san_lorenzo-raw-result.json'));
const hash=b=>createHash('sha256').update(b).digest('hex');
const driverPath='/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/tests/local-san-lorenzo-driver.mjs';
const driverBytes=readFileSync(driverPath);writeFileSync(output+'/baseline-driver.mjs',driverBytes);
let battle=enterSector(input.request,input.previous);const states=[];const eligible=[];
for(let index=0;index<result.orders.length;index++){
 const order=index+1;
 const local=[];
 for(const doctor of battle.units.filter(u=>u.side==='player'&&interruptAvailable(battle,u)&&u.medkits>0&&u.medical>0))for(const patient of battle.units.filter(u=>u.side==='player'&&u.id!==doctor.id&&u.hp>0&&!u.departure&&!u.surrendered&&(u.bleeding>0||criticalFirstAidNeeded(u)))){
  const costs=actionCosts(battle,doctor),plan=firstAidPlan(doctor,patient,{baseCost:costs.heal,budgetAP:doctor.ap-(doctor.activeSlot==='medical'?0:costs.weapon)});
  if(plan.valid&&sameSurface(doctor,patient)&&Math.hypot(doctor.x-patient.x,doctor.y-patient.y)<=1.5&&hasLineOfSight(battle,doctor,patient))local.push({doctorId:doctor.id,patientId:patient.id,doctorAP:doctor.ap,doctorMedkits:doctor.medkits,patientHP:patient.hp,patientBleeding:patient.bleeding,oldOrder:localSanLorenzoOrder(battle,doctor,{avoidCivilians:true})});
 }
 if(local.length)eligible.push({beforeOriginalOrder:order,turn:battle.turn,phase:battle.phase,local});
 if([25,41,97].includes(order)){
  const copy=structuredClone(battle),actorId=order===97?'113':'57',actor=battle.units.find(u=>u.id===actorId),baselineOrder=localSanLorenzoOrder(battle,actor,{avoidCivilians:true});assert.deepEqual(battle,copy);
  states.push({beforeOriginalOrder:order,originalOrder:result.orders[index],actorId,baselineOrder,battle:copy});
 }
 battle=result.orders[index].type==='endTurn'?endTurn(battle):actBattle(battle,result.orders[index]);assert.equal(battle.lastError,null,`order ${order}`);
}
assert.deepEqual(battle,result.battle);assert.deepEqual(readFileSync(driverPath),driverBytes);
writeFileSync(output+'/states.json',JSON.stringify({states},null,2)+'\n');
const receipt={inputRoot,inputs:['san_lorenzo-before-execution.json','san_lorenzo-raw-result.json'].map(name=>({name,bytes:readFileSync(inputRoot+'/'+name).length,sha256:hash(readFileSync(inputRoot+'/'+name))})),originalOrders:result.orders.length,rawTerminalDeepEqual:true,allOriginalOrdersAccepted:true,originalDriverSha256:hash(driverBytes),states:states.map(({battle,...meta})=>({...meta,turn:battle.turn,phase:battle.phase,actor:battle.units.find(u=>u.id===meta.actorId)})),eligible,alternativeOrders:0,settlement:0,limits:'States derive from an independently observed original request and exact original prefixes; live initial battle was not independently captured. Baseline selection makes native immutable legality probes but applies no alternative order.'};
writeFileSync(output+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({output,states:states.map(({battle,...row})=>({...row,turn:battle.turn,phase:battle.phase,actorAP:battle.units.find(u=>u.id===row.actorId).ap})),eligible,rawTerminalDeepEqual:true,driverSha256:hash(driverBytes)}));
