import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {createBattle,actBattle,actionCosts,firearmShotOptions,getReachable,stanceCost,teamCanSee} from '../game/tactical.js';
import {sameCell} from '../game/tactical-space.js';
import {combatOrder} from './opening-driver.mjs';
import {northernCombatOrder} from './northern-route.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const packed=readFileSync(new URL('./fixtures/opening-cordoba-unproductive-posture.battle.json.gz',import.meta.url));
const proof=JSON.parse(readFileSync(new URL('./fixtures/opening-cordoba-unproductive-posture.provenance.json',import.meta.url)));
const raw=gunzipSync(packed);
assert.equal(sha(packed),proof.compressedSha256);assert.equal(sha(raw),proof.rawSha256);
const earned=JSON.parse(raw);
const finite=unit=>Object.fromEntries(['hp','bleeding','loaded','ammo','ammunition','ammunitionChoice','medkits','inventory','weapon','condition'].map(key=>[key,unit[key]]));

test('earned Cordoba firing posture leaves ordinary paid movement available when its best shot is eight percent',()=>{
 const battle=earned.battle,before=structuredClone(battle),unit=battle.units.find(u=>u.id===earned.originalOrder.unitId);
 assert.deepEqual([battle.sectorId,battle.turn,unit.stance,unit.ap,unit.loaded],['cordoba',1,'crouched',81,1]);
 const position={...unit,stance:'prone',movementMode:'prone',momentum:0,weaponReady:false,ap:unit.ap-stanceCost(unit,'prone')};
 const posed={...battle,units:battle.units.map(u=>u.id===unit.id?position:u)};
 const targets=battle.units.filter(u=>u.side==='enemy'&&u.hp>=15&&!u.routed&&!u.unconscious&&teamCanSee(battle,'player',u));
 const chances=targets.flatMap(target=>{
  const cost=actionCosts(posed,position,target),aim=Math.min(4,Math.floor((position.ap-cost.fire)/cost.aim));
  return firearmShotOptions(posed,position,target,aim).map(o=>o.chance);
 });
 assert.equal(Math.max(...chances),8,'the actual paid pose cannot meet the existing useful-fire threshold');
 const chosen=northernCombatOrder(battle,unit);
 assert.notDeepEqual(chosen,earned.originalOrder,'do not spend the actor\'s AP on the unusable firing pose');
 // The native scorer holds this position. The independently observed legal
 // adjacent route still remains affordable; its availability is a separate
 // claim from the controller choosing it or the campaign winning.
 assert.equal(chosen,null);
 const publicView={...battle,units:battle.units.filter(u=>u.side===unit.side||teamCanSee(battle,unit.side,u)),npcs:battle.npcs.filter(u=>teamCanSee(battle,unit.side,u))};
 const action={type:'move',unitId:unit.id,x:62,y:27,tacticalLevel:0};
 const route=getReachable(publicView,unit).find(point=>sameCell(point,action));
 assert.ok(route?.path.length&&route.cost>0&&route.cost<=unit.ap);
 assert.deepEqual(battle,before,'selection does not change the earned state');
 const next=actBattle(battle,action),moved=next.units.find(u=>u.id===unit.id);
 assert.equal(next.lastError,null);assert.equal(moved.ap,unit.ap-route.cost);
 assert.equal(next.elapsedSeconds,battle.elapsedSeconds,'this combat move pays AP; the native combat clock stays unchanged for the order');
 assert.deepEqual(finite(moved),finite(unit));
 assert.deepEqual(battle,before);
});

test('ordinary useful prone fire setup retains its native cost and finite equipment',()=>{
 const width=18,height=5,battle=createBattle([{id:'shooter',x:2,y:2,facing:2,weapon:1800,loaded:1,ammo:2,marksmanship:90,condition:100,stance:'standing',medkits:0}],{
  width,height,seed:45,hour:12,tiles:Array.from({length:width*height},(_,i)=>({x:i%width,y:Math.floor(i/width),type:'grass',cover:0,blocked:false})),
  enemies:[{id:'contact',x:8,y:2,weapon:0,activeSlot:'unarmed',loaded:0,ammo:0,patrol:false,overwatch:false}],
 }),before=structuredClone(battle),unit=battle.units.find(u=>u.id==='shooter');
 const action=combatOrder(battle,unit);
 assert.deepEqual(action,{type:'stance',unitId:unit.id,stance:'prone'});
 const next=actBattle(battle,action),posed=next.units.find(u=>u.id===unit.id),target=next.units.find(u=>u.id==='contact');
 assert.equal(next.lastError,null);assert.equal(posed.ap,unit.ap-stanceCost(unit,'prone'));assert.equal(posed.stance,'prone');
 assert.ok(next.elapsedSeconds>battle.elapsedSeconds);assert.deepEqual(finite(posed),finite(unit));assert.deepEqual(battle,before);
 const cost=actionCosts(next,posed,target),aim=Math.min(4,Math.floor((posed.ap-cost.fire)/cost.aim));
 assert.ok(firearmShotOptions(next,posed,target,aim).some(o=>o.hitLocation==='torso'&&o.chance>=25&&o.damageFactor>0));
});
