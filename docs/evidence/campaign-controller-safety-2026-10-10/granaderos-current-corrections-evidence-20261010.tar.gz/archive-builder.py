from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, tarfile, gzip, io

BASE=Path('/tmp/granaderos-current-corrections-evidence-20261010')
ARCHIVE=BASE.with_suffix('.tar.gz')
EXTERNAL_MANIFEST=BASE.with_suffix('.manifest.json')
EXTERNAL_REPORT=BASE.with_suffix('.report.md')
VERIFY=BASE.with_suffix('.verification.json')
SHA_FILE=BASE.with_suffix('.sha256')
ROOT=Path('/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos')
FOCUS=Path('/tmp/granaderos-current-corrections-focused-2026-10-10T091029769Z')
COMPANION=Path('/tmp/granaderos-three-original-diagnostics-20261010.tar.gz')
COMPANION_SHA='54ca73378c2f277d20178ea5eef76d29ed5949eb7e7d692b375c0c88cf52b830'
COMPANION_BYTES=11597718

def sha(data): return hashlib.sha256(data).hexdigest()
def inspect(p):
    data=p.read_bytes()
    return {'bytes':len(data),'sha256':sha(data)}
def dump(p,x): p.write_text(json.dumps(x,indent=2)+'\n')

for p in (BASE,ARCHIVE,EXTERNAL_MANIFEST,EXTERNAL_REPORT,VERIFY,SHA_FILE):
    if p.exists(): raise RuntimeError('Refuse to replace existing evidence: '+str(p))
assert inspect(COMPANION)=={'bytes':COMPANION_BYTES,'sha256':COMPANION_SHA}
focus_receipt=json.loads((FOCUS/'final-receipt.json').read_text())
assert focus_receipt['complete'] and focus_receipt['exitCode']==0 and focus_receipt['counts']['pass']==54 and not focus_receipt['sourceDrift']
source_pin=json.loads((FOCUS/'before-source-hashes.json').read_text())

payload=[]
def add_file(source,member,kind='recorded-artifact'):
    source=Path(source)
    if not source.is_file() or source.is_symlink(): raise RuntimeError('Missing or non-regular bounded source: '+str(source))
    if member.startswith('/') or '..' in Path(member).parts: raise RuntimeError('Unsafe member: '+member)
    payload.append((source,member,kind))
def add_directory(source,dest):
    source=Path(source)
    if not source.is_dir() or source.is_symlink(): raise RuntimeError('Missing or non-regular bounded directory: '+str(source))
    for p in sorted(source.rglob('*')):
        if p.is_symlink(): raise RuntimeError('Unexpected symlink in bounded evidence: '+str(p))
        if p.is_file(): add_file(p,str(Path(dest)/p.relative_to(source)))

for source,dest in [
('/tmp/granaderos-mendoza-care-two-controls-2026-10-10T084708386Z','care/two-controls'),
('/tmp/granaderos-tucuman-earned-ammunition-correction-2026-10-10T085004629Z','ammunition/failed-admission-1'),
('/tmp/granaderos-tucuman-earned-ammunition-correct-admission-2026-10-10T085204511Z','ammunition/failed-admission-2'),
('/tmp/granaderos-tucuman-earned-ammunition-native-preparation-2026-10-10T085336574Z','ammunition/native-preparation'),
('/tmp/granaderos-coastal-original126-causal-20261010','coastal/original126-replay'),
('/tmp/granaderos-coastal-earned-care-prefixes-20261010','coastal/earned-prefixes'),
('/tmp/granaderos-opening-original164-causal-20261010','opening/original164-replay'),
('/tmp/granaderos-opening-posture-regression-20261010','opening/posture-fixture'),
('/tmp/granaderos-controller-safety-full-2026-10-10T075355015Z/native-failures/60706-1-cordoba-108-18026106-30Ggpv','opening/original-native-failure'),
(str(FOCUS),'focused-gate')]: add_directory(source,dest)

for name,dest in [
('granaderos-coastal-original126-causal-observer-20261010.mjs','coastal/observers/original126-causal-observer.mjs'),
('granaderos-coastal-earned-care-prefixes-20261010.mjs','coastal/observers/earned-care-prefixes.mjs'),
('granaderos-coastal-bounded-care-rule-20261010.md','coastal/bounded-care-rule.md'),
('granaderos-coastal-bounded-care-controls-receipt-20261010.json','coastal/bounded-care-controls-receipt.json'),
('granaderos-mendoza-care-two-controls-20261010.mjs','care/executed-wrapper-original-location.mjs'),
('granaderos-opening-original164-causal-20261010.mjs','opening/observers/original164-causal-original-location.mjs'),
('granaderos-opening-order10-posture-analysis-20261010.json','opening/order10-posture-analysis.json'),
('granaderos-opening-order10-posture-analysis-20261010.mjs','opening/observers/order10-posture-analysis.mjs'),
('granaderos-opening-posture-fixture-20261010.mjs','opening/observers/posture-fixture.mjs'),
('granaderos-three-original-diagnostics-manifest-20261010.json','companions/three-original-diagnostics-manifest.json')]: add_file(Path('/tmp')/name,dest)

for name in (
'granaderos-coastal-bounded-care-red-20261010.log',
'granaderos-coastal-bounded-care-green-20261010.log',
'granaderos-coastal-bounded-care-final-baseline-red-20261010.log',
'granaderos-coastal-bounded-care-final-controls-20261010.log',
'granaderos-coastal-bounded-care-final-green-20261010.log',
'granaderos-coastal-bounded-care-frozen-controls-20261010.log'):
    add_file(Path('/tmp')/name,'coastal/controls/'+name)

source_paths=[
 'tests/stock-mendoza-care-admission.test.mjs',
 'tests/created-cuyo-route.mjs',
 'tests/fixtures/mendoza-earned-survivor-care.json.gz',
 'tests/fixtures/mendoza-earned-survivor-care.provenance.json',
 'tests/tucuman-earned-ammunition.test.mjs',
 'tests/fresh-campaign-route.mjs',
 'tests/campaign-ammunition-driver.mjs',
 'tests/fixtures/tucuman-earned-ammunition-preparation.save.json.gz',
 'tests/fixtures/tucuman-earned-ammunition-preparation.provenance.json',
 'tests/local-san-lorenzo-driver.mjs',
 'tests/local-san-lorenzo-field-care.test.mjs',
 'tests/local-san-lorenzo-safety.test.mjs',
 'tests/fresh-coastal-fixture.mjs',
 'tests/fixtures/san-lorenzo-earned-wounded-commander.battle.json.gz',
 'tests/fixtures/san-lorenzo-earned-wounded-commander.provenance.json',
 'tests/opening-driver.mjs',
 'tests/northern-route.mjs',
 'tests/route-fire-safety.mjs',
 'tests/opening-posture-readiness.test.mjs',
 'tests/fixtures/opening-cordoba-unproductive-posture.battle.json.gz',
 'tests/fixtures/opening-cordoba-unproductive-posture.provenance.json']
missing=[]
for rel in source_paths:
    p=ROOT/rel
    if not p.exists():
        missing.append({'path':str(p),'reason':'Selected archive-time source snapshot is absent; not guessed or substituted.'})
        continue
    current=inspect(p)
    expected=source_pin.get(rel)
    if expected is None:
        raise RuntimeError('Archive-time candidate source not in focused frozen source pin: '+rel)
    if isinstance(expected,dict): expected=expected.get('sha256')
    if current['sha256']!=expected: raise RuntimeError('Frozen candidate source mismatch: '+rel)
    add_file(p,'source-at-archive/'+rel,'current-frozen-source-snapshot')

add_file(Path(__file__),'archive-builder.py','archive-tooling-only')
assert len({member for _,member,_ in payload})==len(payload)
BASE.mkdir()
entries=[]
for source,member,kind in payload:
    data=source.read_bytes()
    dest=BASE/member;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    entries.append({'member':member,'source':str(source),'kind':kind,'bytes':len(data),'sha256':sha(data)})

report='''# Current corrections evidence, 10 October 2026

This archive contains bounded, closed evidence for care admission, finite ammunition preparation, coastal field care and opening posture correction. It contains complete selected artifact directories, not reduced state projections. Creating this archive ran no tests, campaign routes, battles, native orders or settlement. No candidate source or original diagnostic directory was changed.

## Closed results

- Mendoza: the two-control wrapper exited 0, with no source drift. The full corrected-care JSON is retained (25,709,082 bytes), with earned starting campaign, hourly checkpoint, returned campaign and 29 recorded events. Its accepted summary records 26 orders, one hourly dressing, two tactical dressings, 40 clinical PA and renewal cost 172. The original one-action control preserves the captured 26-second approach that killed patient 129 before a dressing was spent. This is bounded care evidence, not a full campaign ending.
- Ammunition: both failed fixture admissions are retained. The first entered the helper once, then rejected the wrong campaign representation before native orders/checkpoints. The second passed a Buffer to the public save loader and failed before helper entry, native orders or checkpoints. Their error output and receipts are not counted as preparation outcomes. After the UTF-8 loader correction, one actual preparation invocation passed. Complete campaign checkpoints, events, native preparation records and final campaign are retained. Thirteen earned survivors have one loaded and nine reserve compatible rounds each. The recorded transfer is six rifle rounds and 58 musket rounds, from finite stock. The receipt conserves family pools and records earned time, real treasury and contract renewals. There was no battle, full route or stock grant in this focused preparation.
- Coastal: the exact original 126-order replay accepted every recorded order and matched the entire raw terminal defeat. The original request was independently captured before execution; the initial battle is derived from that request and retained previous state, not independently observed. Fixed original-prefix controls preserve states before orders 25, 41 and 97. The baseline final controls passed one case and failed two because the old wounded-commander selector returned no order. The final corrected care/safety controls passed all 11 cases. Their scope is three native care orders on one earned clone, one paid defensive order on another, and a zero-AP medic control with no order. No corrected full coastal battle or route acceptance is established by these controls.
- Opening: the complete bounded original failure pack and exact 164-order replay are retained. Every original order was accepted and the entire raw terminal retreat matched, with zero source drift. The initial battle is derived from the retained after-execution request and sector state, not independently observed. The order-10 analysis and fixture show a paid prone setup whose best native chance is eight percent. The current earned regression leaves the actor unchanged and selects no order; it separately proves an affordable adjacent native move with real AP. It does not claim that the controller chooses that move or wins the battle. The companion useful-fire case retains an affordable ordinary posture.
- Combined focused gate: the closed wrapper selected 13 files, passed all 54 tests, failed/skipped none and recorded no source drift. Its executed wrapper, complete log, receipt and before/after source hash maps are retained. This result does not replace original route acceptance or a full repository gate.

## Failed controls and development history

The coastal preliminary control log is retained as executed: nine cases passed and two failed because the test incorrectly assumed that every combat order advances seconds. The native round had already charged its six seconds. The corrected controls require the exact already charged clock plus real AP deductions and finite dressing use. Baseline and later final logs are retained without rewriting.

Opening development history was supplied by the parent agent, and has no durable transcript log in the selected artifacts. The reported two-case sequence was: one pass/one failure from assuming that the selector moves; one pass/one failure after the correction because the native scorer actually holds; one pass/one failure from assuming that a combat move advances seconds. The reported native probe paid 10 AP and retained clock 21. The assertion was narrowed to native selector/legality scope, after which both cases passed. This paragraph is explicitly parent-reported history, not reconstructed log evidence. The final opening cases are present in the closed combined focused log. No missing logs were fabricated.

## Provenance and limits

The immutable three-original passive diagnostics remain in the unchanged companion archive `granaderos-three-original-diagnostics-20261010.tar.gz`, 11,597,718 bytes, SHA256 `54ca73378c2f277d20178ea5eef76d29ed5949eb7e7d692b375c0c88cf52b830`. That archive was verified but not repacked or copied into this archive. Its member manifest is included under `companions/`. Restore that companion alongside this evidence when reviewing the original care/ammunition/coastal captures.

The bounded opening native failure pack is duplicated here for portable provenance; the original full950 archive remains separate. Current source copies under `source-at-archive/` were read from the frozen candidate and checked against the combined focused source hash map. They are archive-time snapshots, not a claim that every earlier development attempt used those exact final bytes. Earlier execution receipts retain their own source pins. The full transitive source tree, dependency tree, engine checkout and runtime installation are not included. The preserved original observers keep their executed absolute import/output paths; this evidence archive is portable for inspection, not a standalone automatically executable test environment.

Known unavailable evidence is disclosed: no full original Mendoza care action tape; no independently observed initial tactical battle for coastal/opening; no comparable raw hired-coastal tape from the earlier full948 pass; no durable opening development failure transcripts. These records cannot prove a precise full948-to-full950 cause, corrected full-route victory, browser performance, JA2 parity or full campaign completion. Affected/full gate results that close after this archive are outside its closed snapshot.

## Archive verification

`MANIFEST.json` binds every payload member (including this report) to its original source path, byte size and SHA256. The internal manifest excludes only itself to avoid a self-hash cycle. The matching external `.manifest.json` and `.verification.json` include every tar member, including `MANIFEST.json`. All source bytes are checked again after archiving. Every tar member is read back, hashed and compared with the staged file and recorded source. The tar has regular files only, safe relative paths and no dependency symlinks. No artifact content is rewritten.

Extract with `tar -xzf granaderos-current-corrections-evidence-20261010.tar.gz`. Consult the report and manifest before any attempt to rerun an observer. No rerun is part of this archive creation.
'''
report+="\n## Missing selected source files\n\n"+ ('None.\n' if not missing else '\n'.join('- '+x['path']+': '+x['reason'] for x in missing)+'\n')
report_bytes=report.encode()
(BASE/'REPORT.md').write_bytes(report_bytes);EXTERNAL_REPORT.write_bytes(report_bytes)
entries.append({'member':'REPORT.md','source':str(EXTERNAL_REPORT),'kind':'generated-archive-report','bytes':len(report_bytes),'sha256':sha(report_bytes)})
internal={
 'schemaVersion':1,'scope':'Closed current corrections evidence; no original diagnostic repack and no new gameplay execution',
 'createdUtc':datetime.now(timezone.utc).isoformat(),'sourceRoot':str(ROOT),'members':sorted(entries,key=lambda x:x['member']),
 'manifestSelfHashExcluded':True,'missingSelectedSourceFiles':missing,
 'companion':{'archive':str(COMPANION),'bytes':COMPANION_BYTES,'sha256':COMPANION_SHA,'includedInThisArchive':False},
 'parentReportedHistoryOnly':['Opening development control failures have no durable transcript logs.'],
 'sourceAtArchiveBoundTo':{'path':str(FOCUS/'before-source-hashes.json'),**inspect(FOCUS/'before-source-hashes.json')}
}
dump(BASE/'MANIFEST.json',internal)
all_entries=entries+[{'member':'MANIFEST.json','source':str(BASE/'MANIFEST.json'),'kind':'generated-internal-manifest',**inspect(BASE/'MANIFEST.json')}]
all_entries=sorted(all_entries,key=lambda x:x['member'])

with ARCHIVE.open('wb') as out:
    with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for row in all_entries:
                data=(BASE/row['member']).read_bytes()
                ti=tarfile.TarInfo(row['member']);ti.size=len(data);ti.mtime=0;ti.mode=0o644;ti.uid=ti.gid=0;ti.uname=ti.gname=''
                tar.addfile(ti,io.BytesIO(data))

expected={row['member']:row for row in all_entries};verified=[]
with tarfile.open(ARCHIVE,'r:gz') as tar:
    actual=tar.getmembers()
    assert len(actual)==len(expected)
    assert len({m.name for m in actual})==len(actual)
    assert {m.name for m in actual}==set(expected)
    for member in actual:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        data=tar.extractfile(member).read();row=expected[member.name]
        check={'bytes':len(data),'sha256':sha(data)}
        assert check=={'bytes':row['bytes'],'sha256':row['sha256']},member.name
        assert inspect(BASE/member.name)==check,member.name
        verified.append({'member':member.name,**check})
source_checks=[]
for row in all_entries:
    check=inspect(Path(row['source']))
    assert check=={'bytes':row['bytes'],'sha256':row['sha256']},'Source changed: '+row['source']
    source_checks.append({'source':row['source'],**check,'unchanged':True})
assert inspect(COMPANION)=={'bytes':COMPANION_BYTES,'sha256':COMPANION_SHA}
archive_info={'path':str(ARCHIVE),**inspect(ARCHIVE)}
external={'schemaVersion':1,'archive':archive_info,'regularMembersOnly':True,'members':all_entries,'memberCount':len(all_entries),'uncompressedMemberBytes':sum(row['bytes'] for row in all_entries),'internalManifestSelfHashExcluded':True,'externalManifestCoversEveryTarMember':True,'missingSelectedSourceFiles':missing,'companion':internal['companion']}
dump(EXTERNAL_MANIFEST,external)
verification={'schemaVersion':1,'complete':True,'verifiedUtc':datetime.now(timezone.utc).isoformat(),'archive':archive_info,'memberCount':len(verified),'everyMemberByteAndHashVerified':True,'allOriginalSourceBytesUnchanged':True,'companionArchiveUnchanged':True,'newTests':0,'newGameplayOrders':0,'candidateWrites':0,'originalArtifactWrites':0,'members':verified,'sourceChecks':source_checks,'externalManifest':{'path':str(EXTERNAL_MANIFEST),**inspect(EXTERNAL_MANIFEST)},'report':{'path':str(EXTERNAL_REPORT),**inspect(EXTERNAL_REPORT)}}
dump(VERIFY,verification)
SHA_FILE.write_text(''.join(inspect(p)['sha256']+'  '+p.name+'\n' for p in (ARCHIVE,EXTERNAL_MANIFEST,EXTERNAL_REPORT,VERIFY)))
print(json.dumps({'archive':archive_info,'memberCount':len(verified),'memberBytes':external['uncompressedMemberBytes'],'manifest':str(EXTERNAL_MANIFEST),'report':str(EXTERNAL_REPORT),'verification':str(VERIFY),'sha256':str(SHA_FILE),'missingSelectedSourceFiles':missing,'everyMemberVerified':True,'sourceBytesUnchanged':True},indent=2))
