import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {actBattle,endTurn} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/tactical.js';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const original='/tmp/granaderos-controller-safety-full-2026-10-10T075355015Z/native-failures/60706-1-cordoba-108-18026106-30Ggpv';
const out='/tmp/granaderos-opening-posture-regression-20261010';
const result=JSON.parse(fs.readFileSync(original+'/native-result.json'));
let battle=JSON.parse(fs.readFileSync('/tmp/granaderos-opening-original164-causal-20261010/derived-initial-battle.json'));
const prefix=result.orders.slice(0,10);
for(const action of prefix){battle=action.type==='endTurn'?endTurn(battle):actBattle(battle,action);assert.equal(battle.lastError,null);}
const raw=Buffer.from(JSON.stringify({battle,originalOrder:result.orders[10],originalIndex:10})+'\n');
const compressed=gzipSync(raw,{level:9});
const provenance={schemaVersion:1,sector:'cordoba',originalIndex:10,rawSha256:sha(raw),compressedSha256:sha(compressed),
 inputCapture:'Native initial battle derived from retained after-execution request; no independently observed live initial battle. Exact original accepted prefix then yields this fixture.',
 prefix,originalPackFiles:['native-input.json','native-result.json','receipt.json'].map(name=>({name,bytes:fs.statSync(original+'/'+name).size,sha256:sha(fs.readFileSync(original+'/'+name))})),
 exactFullTapeReplayReceiptSha256:sha(fs.readFileSync('/tmp/granaderos-opening-original164-causal-20261010/receipt.json')),
 originalFullTapeOrders:164,originalFullTapeTerminalDeepEqual:true,seedChanges:0,alternativeOrders:0,settlementExecuted:false};
fs.mkdirSync(out);
fs.writeFileSync(out+'/opening-cordoba-unproductive-posture.battle.json.gz',compressed);
fs.writeFileSync(out+'/opening-cordoba-unproductive-posture.provenance.json',JSON.stringify(provenance,null,2)+'\n');
console.log(JSON.stringify({out,rawBytes:raw.length,compressedBytes:compressed.length,rawSha256:sha(raw),compressedSha256:sha(compressed)},null,2));
