import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {registerHooks} from 'node:module';
import {fileURLToPath} from 'node:url';

const repo='/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos';
const root='/tmp/granaderos-controller-safety-full-2026-10-10T075355015Z';
const pack=path.join(root,'native-failures/60706-1-cordoba-108-18026106-30Ggpv');
const out='/tmp/granaderos-opening-original164-causal-20261010';
const sha=data=>crypto.createHash('sha256').update(data).digest('hex');
const pin=JSON.parse(fs.readFileSync(path.join(root,'before-source-hashes.json')));
const sources=new Map();
registerHooks({load(url,context,nextLoad){
 const result=nextLoad(url,context);
 if(url.startsWith('file:')){
  const file=fileURLToPath(url);
  if(file.startsWith(repo+'/')){
   const rel=path.relative(repo,file),hash=sha(fs.readFileSync(file));
   assert.equal(hash,pin[rel],`Original loaded source ${rel}`);
   sources.set(rel,hash);
  }
 }
 return result;
}});
const {enterSector}=await import(path.join(repo,'game/world.js'));
const {actBattle,endTurn,firearmShotOptions}=await import(path.join(repo,'game/tactical.js'));
const input=JSON.parse(fs.readFileSync(path.join(pack,'native-input.json')));
const result=JSON.parse(fs.readFileSync(path.join(pack,'native-result.json')));
fs.mkdirSync(out);
fs.copyFileSync(fileURLToPath(import.meta.url),path.join(out,'executed-observer.mjs'));
const project=u=>({id:u.id,x:u.x,y:u.y,tacticalLevel:u.tacticalLevel??0,hp:u.hp,bleeding:u.bleeding,
 energy:u.energy,morale:u.morale,stance:u.stance,ap:u.ap,loaded:u.loaded,ammo:u.ammo,
 medkits:u.medkits,routed:u.routed,unconscious:u.unconscious,weaponDropped:u.weaponDropped});
let battle=enterSector(input.request,input.campaign.sectorStates[input.request.sector]);
fs.writeFileSync(path.join(out,'derived-initial-battle.json'),JSON.stringify(battle));
const initial=battle.units.filter(u=>u.side==='player').map(project);
const observations=[],counts={};
for(const [index,action] of result.orders.entries()){
 const before=battle;
 const actor=before.units.find(u=>u.id===action.unitId);
 let shot=null;
 if(action.type==='fire'){
  const target=before.units.find(u=>u.id===action.targetId);
  const options=firearmShotOptions(before,actor,target,action.aim??0);
  const option=options.find(o=>o.aim===(action.aim??0)&&o.hitLocation===(action.hitLocation??'torso'));
  shot=option?{chance:option.chance,damageFactor:option.damageFactor,hitLocation:option.hitLocation,
   interveningFriendly:option.interveningFriendly??null}:null;
 }
 battle=action.type==='endTurn'?endTurn(before):actBattle(before,action);
 assert.equal(battle.lastError,null,`Accepted original order ${index}`);
 const changes=before.units.filter(u=>u.side==='player').flatMap(u=>{
  const next=battle.units.find(v=>v.id===u.id);
  return next&&(u.hp!==next.hp||u.routed!==next.routed||u.unconscious!==next.unconscious)
   ?[{before:project(u),after:project(next)}]:[];
 });
 if(action.unitId){counts[action.unitId]??={};counts[action.unitId][action.type]=(counts[action.unitId][action.type]??0)+1;}
 observations.push({index,action,turn:before.turn,phase:before.phase,elapsedBefore:before.elapsedSeconds,
  elapsedAfter:battle.elapsedSeconds,actor:actor?project(actor):null,shot,playerChanges:changes});
}
assert.deepEqual(battle,result.battle,'Exact raw terminal result');
for(const [rel,hash] of sources)assert.equal(sha(fs.readFileSync(path.join(repo,rel))),hash,`Source remained fixed ${rel}`);
fs.writeFileSync(path.join(out,'observations.json'),JSON.stringify(observations,null,2)+'\n');
const receipt={originalPack:pack,originalOrders:result.orders.length,allOrdersAccepted:true,
 rawTerminalDeepEqual:true,initialCapture:'Derived from retained request and sector state; the full950 recorder did not independently capture live initial battle.',
 sourceFiles:sources.size,sourceDrift:0,sourceHashes:Object.fromEntries(sources),
 originalInputs:['native-input.json','native-result.json'].map(name=>({name,bytes:fs.statSync(path.join(pack,name)).size,sha256:sha(fs.readFileSync(path.join(pack,name)))})),
 initialPlayers:initial,originalOrderCounts:counts,terminalStatus:battle.status,terminalTurn:battle.turn,
 controllerInvocations:0,alternativeOrders:0,settlementExecuted:false};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({out,orders:result.orders.length,allOrdersAccepted:true,rawTerminalDeepEqual:true,
 sourceFiles:sources.size,status:battle.status,turn:battle.turn,counts},null,2));
