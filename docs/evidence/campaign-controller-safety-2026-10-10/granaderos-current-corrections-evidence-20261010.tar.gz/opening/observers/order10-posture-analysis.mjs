import fs from 'node:fs';
import assert from 'node:assert/strict';
import {actBattle,endTurn,firearmShotOptions,stanceCost,actionCosts,getReachable,teamCanSee,hasLineOfSight} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/game/tactical.js';
import {northernCombatOrder} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/tests/northern-route.mjs';
const root='/tmp/granaderos-opening-original164-causal-20261010';
const orders=JSON.parse(fs.readFileSync('/tmp/granaderos-controller-safety-full-2026-10-10T075355015Z/native-failures/60706-1-cordoba-108-18026106-30Ggpv/native-result.json')).orders;
let b=JSON.parse(fs.readFileSync(root+'/derived-initial-battle.json'));
for(const action of orders.slice(0,10)){
 b=action.type==='endTurn'?endTurn(b):actBattle(b,action);
 assert.equal(b.lastError,null);
}
const u=b.units.find(u=>u.id==='124');
assert.deepEqual(northernCombatOrder(b,u),orders[10]);
const stance='prone',cost=stanceCost(u,stance);
const p={...u,stance,movementMode:'prone',momentum:0,weaponReady:false,ap:u.ap-cost};
const posed={...b,units:b.units.map(v=>v.id===u.id?p:v)};
const targets=b.units.filter(t=>t.side==='enemy'&&t.hp>=15&&!t.departure&&!t.surrendered&&!t.unconscious&&!t.routed&&teamCanSee(b,'player',t));
const options=targets.map(t=>{
 const c=actionCosts(posed,p,t),aim=Math.min(4,Math.floor((p.ap-c.fire)/c.aim));
 return {id:t.id,los:hasLineOfSight(posed,p,t),options:p.ap>=c.fire?firearmShotOptions(posed,p,t,aim).map(o=>({aim:o.aim,hitLocation:o.hitLocation,chance:o.chance,damageFactor:o.damageFactor})):[]};
});
const publicView={...b,units:b.units.filter(v=>v.side===u.side||teamCanSee(b,u.side,v)),npcs:(b.npcs??[]).filter(v=>teamCanSee(b,u.side,v))};
const routes=getReachable(publicView,u).filter(v=>v.cost>0&&v.x<u.x&&v.cost<=32).map(({x,y,cost,tacticalLevel})=>({x,y,cost,tacticalLevel}));
const out={originalIndex:10,originalAction:orders[10],sameControllerChoiceVerified:true,actor:{id:u.id,stance:u.stance,ap:u.ap,loaded:u.loaded,weapon:u.weapon,x:u.x,y:u.y},paidPostureCost:cost,afterPaidAp:p.ap,targets:options,legalPaidWestwardRoutes:routes,controllerInvocations:1,newOrders:0,settlement:false};
fs.writeFileSync('/tmp/granaderos-opening-order10-posture-analysis-20261010.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({actor:out.actor,originalAction:out.originalAction,paidPostureCost:cost,maximumPostureChance:Math.max(0,...options.flatMap(t=>t.options.map(o=>o.chance))),legalWestwardRoutes:routes.length,controllerInvocations:1,newOrders:0},null,2));
