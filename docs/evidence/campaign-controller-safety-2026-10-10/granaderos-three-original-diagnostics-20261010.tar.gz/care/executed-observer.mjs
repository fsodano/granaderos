import {writeFileSync,appendFileSync} from 'node:fs';
import {freshCuyoRoute} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/tests/fresh-cuyo-fixture.mjs';
const out=process.argv[2];
const write=(name,value)=>writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n');
let failure=null,careOrderReports=0,mendozaObserved=false;
try{
 const result=freshCuyoRoute({
  onCheckpoint:(stage,campaign)=>{if(stage==='mendoza'){write('earned-mendoza-before-care.json',campaign);mendozaObserved=true;}},
  report:value=>{
   if(value.event==='stockMendozaCareOrder'){appendFileSync(out+'/existing-care-order-reports.jsonl',JSON.stringify(value)+'\n');careOrderReports++;}
   if(value.event==='stockMendozaCareStopped')write('existing-care-stopped-report.json',value);
  },
 });
 write('unexpected-return.json',result);
}catch(error){failure={name:error.name,code:error.code??null,message:error.message,stack:error.stack};write('original-error.json',failure);}
write('observer-receipt.json',{invocations:1,routeKind:'created default',seed:'unchanged default',controllers:'unchanged defaults',optionChanges:'passive callbacks only',mendozaObserved,careOrderReports,careReportsAreCompleteTape:false,failure,additionalOrders:0,additionalSynchronization:0,additionalSettlement:0,sourceSnapshot:process.env.GRANADEROS_CAMPAIGN_SOURCE_SNAPSHOT});
console.log(JSON.stringify({observer:'care',mendozaObserved,careOrderReports,error:failure?.message??null}));process.exitCode=failure?1:0;
