import {writeFileSync} from 'node:fs';
import {freshCoastalRoute} from '/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos/tests/fresh-coastal-fixture.mjs';
const out=process.argv[2];
const write=(name,value)=>writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n');
let failure=null;const battles=[];
try{
 const result=freshCoastalRoute('hired',{
  onBeforeBattle:value=>{write(value.sector+'-before-execution.json',value);battles.push(value.sector);},
  onBattleFinished:value=>write(value.sector+'-raw-result.json',value),
 });
 write('unexpected-return.json',result);
}catch(error){failure={name:error.name,code:error.code??null,message:error.message,stack:error.stack};write('original-error.json',failure);}
write('observer-receipt.json',{invocations:1,kind:'hired',seed:8,controllers:'unchanged defaults',optionChanges:'passive callbacks only',independentPreExecutionInputCaptured:true,independentLiveInitialBattleCaptured:false,battles,failure,additionalOrders:0,additionalSettlement:0,sourceSnapshot:process.env.GRANADEROS_CAMPAIGN_SOURCE_SNAPSHOT});
console.log(JSON.stringify({observer:'coastal',battles,error:failure?.message??null}));process.exitCode=failure?1:0;
