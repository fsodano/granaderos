Unchanged primary main baseline at 462abba

The sole original five-file gate ended with exit 1: 16 tests, 6 passed, 5 failed, 5 skipped. Main remained clean and all 14,098 source hashes matched before and after.

Four actual barriers account for five failed TAP tests: Córdoba care-defense defeat; Mendoza victory followed by campaign defeat; Los Patos retreat; opening Córdoba retreat plus its failed parent. The five downstream opening subtests stayed skipped.

The funded hired coastal test passed on main. Its failure after combat in the c7 candidate gate is a candidate regression.

The complete gate artifacts, all four native failure packs, exact wrapper/args/PIDs/log/counts, full source hash maps and clean receipts are included. A recovery checkpoint prefix was enabled; no checkpoint file was emitted by this run. Native inputs were retained after execution, not independently captured preparation inputs. No extra actions or trials occurred.
