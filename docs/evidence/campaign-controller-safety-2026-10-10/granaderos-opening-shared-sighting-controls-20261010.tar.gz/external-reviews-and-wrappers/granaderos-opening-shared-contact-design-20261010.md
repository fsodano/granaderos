This is a design report. No correction described here is implemented or accepted. No chooser, preview, native order, reproduction, or campaign trial was run for this report. Only the separately approved passive null-boundary recorder was added to the candidate.

The original opening driver has been restored. Removing the passive recorder import and call from its current source reconstructs original HEAD bytes exactly. The original defensive-prone returns, 25 percent firing threshold, native action costs, and null returns remain intact.

The failed five-file gate at `/tmp/granaderos-current-corrections-affected-2026-10-10T091133583Z` finished with 4 passing and 5 failing tests, exit 1, and no source drift. Its opening driver included the outgoing-shot posture guard. Those results do not isolate that guard from every other candidate correction. Root rejected the guard and ordered its removal. A restored-source route result is still pending.

An outgoing shot and a defensive posture are different decisions. The saved order-10 analysis proves that actor 124's paid prone shot reaches at most 8 percent. It does not prove that lying prone has no defensive value. `game/tactical.js:634` subtracts up to 40 accuracy points for a prone target, versus 20 for a crouched target, before the remaining range factors and clamping. `game/sight-geometry.js:6` also gives prone bodies different physical heights. The native `firingPosture` fallback at `game/tactical-ai.js:99-112` requires useful outgoing fire because that fallback serves a firing purpose. The original opening contact-posture branch has a broader purpose. Do not replace its defensive admission with an outgoing-shot threshold.

The source shows a shared-contact gap. Original `tests/opening-driver.mjs:17` uses squad sight. Actor 124 is at (63,27), loaded, with 81 AP. Every original enemy is more than 20 cells away. Native sight reaches at most 16 cells (`game/tactical.js:374-379`). Scout 137 at (58,26) sees enemy 8 at (42,26). Actor 124 has neither personal remembered contact, heard noise, nor patrol origin in the saved order-10 state.

The native chooser filters targets through personal sight (`game/tactical-ai.js:310`). With no personal target or remembered point, its existing branch returns the patrol chooser (`:354-356`), which holds without a patrol origin (`:34`). The opening controller then holds because squad contact exists (original opening `:49`). Its reconnaissance search is not reached. The native fire/cover movement scorer at `:421-445` is also not reached. This is a knowledge handoff gap. It is not evidence that that scorer rejected all legal movement cells.

The bounded design is to supply a validated, temporary shared contact to the existing native investigation branch. Keep one ordinary native chooser call. Activate the extra context only after all original defensive-posture, aid, weapon, reload, and mission-ally priorities. The context must contain only the currently shared contact's identity, coordinates, level, and observation turn. Validate it against a living opponent that a current eligible squad observer can see. Do not write `lastKnownEnemy`, `lastHeardNoise`, personal sight, AP, or any campaign field.

Initially bound admission to an ordinary, already-prone, stable player infantry actor with a loaded serviceable primary firearm, no personal visible target, no valid personal remembered contact, and no patrol origin. An explicit patrol hold and the mission-ally hold remain authoritative. Use the opening controller's existing selected shared target; do not introduce another target-ranking policy.

In the native no-personal-target branch, preserve maintenance, sharing, scavenging, and any admitted patrol action first. Only its existing no-admitted-action case may consider the validated shared point. Reuse `investigate` at `game/tactical-ai.js:244-280`, rather than introducing a new movement scorer or enlarging the firing target set. Its existing bounds reserve fire plus two aim increments, limit ordinary movement to 24 internal AP and three steps, and limit interruptions to 16 AP and one step. Its current interruption, cover, line-of-sight, detour, and exposure rules remain in force. Use only known occupants for the movement preview, as the actual player movement authority does at `game/tactical.js:2026-2030`.

A new context must not make an unseen target personally visible or admit a below-threshold shot. Once actual movement produces personal contact, the ordinary chooser and safe-fire wrapper resume. Every returned order must still pass the native execution guards. No free stance change, full-health reset, extra ammunition, altered chance, seed change, contract relief, casualty removal, or weakened victory assertion is part of this design.

The saved 10-AP westward route was quoted while crouched. Do not carry that price into a post-prone decision. The original accepted trace later shows prone actor 124 spending 16 AP on one westward cell. All prices must be read from the actual captured posture and current route.

The next required evidence is an actual post-prone null decision boundary. The original 164-order tape records accepted orders, not null chooser invocations. Its initial battle was derived from the retained request and sector state, although its terminal native battle matched the original result exactly. It therefore cannot establish the complete live null-decision sequence. The approved passive recorder now captures the raw battle, actor, shared contacts, and actual native result at the unchanged shared-contact null return. It records at most eight declared distinct decision keys per sector/deployment/start clock. The next original gate can establish whether this specific admission gap occurs after the original defensive posture.

No correction should be accepted from the order-10 firing-pose result alone. The evidence must first show a real post-prone null boundary with current shared contact and a lawful paid investigation opportunity. Any later authorized correction needs the original full-route acceptance checks, because this shared driver serves earlier encounters too.

Source and evidence SHA256 values used for this report:

- Original restored opening HEAD: `143eaaf3d2bafffecaae6cb82476257ef9264b95aec57e55f0cfd0b70948a6f3`.
- Opening with passive null recorder: `3b8b0c4d4f4f60dea5a972d55a0008afeab9b676235b50a83ce10f4f73154dcd`.
- Passive decision recorder: `20a3695167eaed2d661b3f0aafbd578b506a7427e2be932ae0a04eae23f6ec66`.
- Northern wrapper: `6623ef2b1396d3f4abf0c331cc0ca9cffb0b7070395280e98282c81868949ac7`.
- Native chooser: `d683bf0accd844b4b67e282688112a03332f08c1212403c3880d9cafde2fc6e4`.
- Native tactical source: `0caf35fbdc2ebde38743d5d2de862230cdfc9931ec4f46156ac9e95a7e06b1f3`.
- Original observations: `9acf4c0122358ae2510d2a0c2884cdaf6437b85cce91c3663b4bd90ebb73e7a7`.
- Saved order-10 analysis: `a8fd74ed7c5c8a8274041997baf71db3e1d29f2b3bc327fa43caea56a01ba5c9`.
