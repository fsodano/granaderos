import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync,statSync} from 'node:fs';
import {resolve,dirname,relative,join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
const root='/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos';
const runtime='/opt/homebrew/Cellar/node/25.9.0_2/bin/node';
const entry='tests/opening-shared-sighting-investigation.test.mjs';
const output='/tmp/granaderos-opening-shared-sighting-corrected-two-controls-'+new Date().toISOString().replace(/[:.]/g,'')+'/';
mkdirSync(output,{recursive:true});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const write=(name,value)=>writeFileSync(join(output,name),JSON.stringify(value,null,2)+'\n');
const seen=new Set(),queue=[resolve(root,entry)];
while(queue.length){const path=queue.pop();if(seen.has(path))continue;seen.add(path);const source=readFileSync(path,'utf8');
 for(const match of source.matchAll(/(?:\bfrom\s*|\bimport\s*)['"]([^'"]+)['"]/g)){
  if(!match[1].startsWith('.'))continue;const target=resolve(dirname(path),match[1]);
  if(existsSync(target)&&/\.(?:m?js|json)$/.test(target))queue.push(target);
 }
}
const runtimeImports=[...seen].map(path=>relative(root,path)).sort();
for(const path of ['tests/fixtures/opening-cordoba-shared-sighting.json.gz','tests/fixtures/opening-cordoba-shared-sighting.provenance.json'])seen.add(resolve(root,path));
const walk=directory=>{for(const name of readdirSync(directory)){const path=join(directory,name);if(statSync(path).isDirectory())walk(path);else if(statSync(path).isFile())seen.add(path);}};
walk(resolve(root,'game'));
const sourcePaths=[...seen].sort();
const snapshot=()=>sourcePaths.map(path=>{const bytes=readFileSync(path);return {path:relative(root,path),bytes:bytes.length,sha256:hash(bytes)};});
const before=snapshot();write('before-source-hashes.json',before);
const reviewed=JSON.parse(readFileSync('/tmp/granaderos-opening-shared-sighting-corrected-scoped-review-20261010.json','utf8'));
for(const expected of reviewed.changed){const current=before.find(item=>item.path===expected.path);if(JSON.stringify(current)!==JSON.stringify(expected))throw new Error('Reviewed source drift: '+expected.path);}
write('reviewed-source.json',reviewed);
const sourceSnapshotSha256=hash(readFileSync(join(output,'before-source-hashes.json')));
const gameRows=before.filter(row=>row.path.startsWith('game/'));
const productionIdentity=hash(JSON.stringify(gameRows));
writeFileSync(join(output,'executed-wrapper.mjs'),readFileSync(import.meta.filename));
const env={...process.env,GRANADEROS_CAMPAIGN_FAILURE_DIR:join(output,'native-failures'),GRANADEROS_CAMPAIGN_SOURCE_SNAPSHOT:join(output,'before-source-hashes.json'),GRANADEROS_OPENING_CONTROL_DIR:join(output,'raw-controls'),GRANADEROS_BUILD_REVISION:'0b53d3fb+working-'+sourceSnapshotSha256};delete env.NODE_OPTIONS;
const started=new Date().toISOString();
write('metadata.json',{root,runtime,nodeVersion:process.version,entry,started,controls:2,fullRouteInvocations:0,controllerTrials:0,seedVariants:0,sourceFiles:sourcePaths.length,runtimeImports,productionGameFilesBound:true,priorFailedTestExpectationReceipt:'ad5ee4788629c1863b29bbf530cb832b74ddcb295889b9dac8ab45507609ff1f',testExpectationCorrected:true,productionAndControllerChangedSincePriorControl:false,sourceSnapshotSha256,productionIdentity,originalWitnessBuildRevision:reviewed.changed?'462abba277a47dafbfed1f60fc4529c8a4721cdc+working-c7a3e4fca512b42d80b0ee3e5bd26daad0967822b60713f50a39411e66d224bd':null});
const child=spawn(runtime,['--test',entry],{cwd:root,env,stdio:['ignore','pipe','pipe']});
write('pid.json',{parent:process.pid,child:child.pid});
const append=(await import('node:fs')).appendFileSync;
for(const stream of [child.stdout,child.stderr])stream.on('data',chunk=>{append(join(output,'run.log'),chunk);process.stdout.write(chunk);});
console.log(JSON.stringify({event:'CONTROLS_STARTED',output,parent:process.pid,child:child.pid,sourceFiles:sourcePaths.length}));
child.on('error',error=>{write('spawn-error.json',{message:error.message});process.exitCode=1;});
child.on('close',(exitCode,signal)=>{
 const after=snapshot();write('after-source-hashes.json',after);
 const sourceDrift=after.filter((value,index)=>JSON.stringify(value)!==JSON.stringify(before[index]));
 const artifacts=[];
 const collect=directory=>{if(!existsSync(directory))return;for(const name of readdirSync(directory)){const path=join(directory,name);if(statSync(path).isDirectory())collect(path);else {const bytes=readFileSync(path);artifacts.push({path:relative(output,path),bytes:bytes.length,sha256:hash(bytes)});}}};
 collect(output);
 const complete=signal===null&&sourceDrift.length===0;
 const receipt={started,finished:new Date().toISOString(),exitCode,signal,complete,sourceFiles:sourcePaths.length,sourceDrift,sourceSnapshotSha256,productionIdentity,controls:2,fullRouteInvocations:0,controllerTrials:0,seedVariants:0,artifacts};
 write('final-receipt.json',receipt);
 console.log(JSON.stringify({event:'CONTROLS_CLOSED',output,exitCode,signal,complete,sourceDrift:sourceDrift.length}));process.exitCode=complete?exitCode:1;
});
