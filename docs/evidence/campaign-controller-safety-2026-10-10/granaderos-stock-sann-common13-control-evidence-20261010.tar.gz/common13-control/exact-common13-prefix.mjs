import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,statSync} from 'node:fs';
import {join,relative,dirname} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';

const output=dirname(fileURLToPath(import.meta.url));
const candidate='/Users/fsodano/.codex/worktrees/campaign-controller-safety/granaderos';
const original='/tmp/granaderos-current-corrections-affected-2026-10-10T092945091Z/native-failures/coastal-boundaries/78260-1-stock-san_nicolas-san_nicolas-60-1027220423-caQpZS';
const current='/tmp/granaderos-current-corrections-v2-affected-2026-10-10T101340233Z/native-failures/coastal-boundaries/89510-1-stock-san_nicolas-san_nicolas-60-1027220423-smgghd';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const serialize=value=>JSON.stringify(value,null,2)+'\n';
const write=(name,value)=>writeFileSync(join(output,name),serialize(value));
const readBound=(root,name,expected)=>{
 const bytes=readFileSync(join(root,name));assert.equal(sha(bytes),expected,name);
 return {name,path:join(root,name),bytes:bytes.length,sha256:sha(bytes),value:JSON.parse(bytes)};
};
const files=[];
const walk=dir=>{for(const name of readdirSync(dir).sort()){const path=join(dir,name);if(statSync(path).isDirectory())walk(path);else files.push(relative(candidate,path));}};
walk(join(candidate,'game'));
const snapshot=()=>Object.fromEntries(files.map(path=>[path,sha(readFileSync(join(candidate,path)))]));
const identity=pair=>({
 campaign:{hour:pair.campaign.hour,secondOfHour:pair.campaign.secondOfHour,seed:pair.campaign.seed,location:pair.campaign.location,phase:pair.campaign.phase,defeated:pair.campaign.defeated,resources:pair.campaign.resources,squad:pair.campaign.squad,contracts:pair.campaign.contracts,hiringArrivals:pair.campaign.hiringArrivals,operativeState:pair.campaign.operativeState,pendingBattle:pair.campaign.pendingBattle},
 battle:{battleId:pair.battle.battleId,seed:pair.battle.seed,turn:pair.battle.turn,phase:pair.battle.phase,status:pair.battle.status,mode:pair.battle.mode,startSeconds:pair.battle.startSeconds,elapsedSeconds:pair.battle.elapsedSeconds,syncedSeconds:pair.battle.syncedSeconds,roundTimeCharged:pair.battle.roundTimeCharged,units:pair.battle.units,groundItems:pair.battle.groundItems,droppedWeapons:pair.battle.droppedWeapons,artillery:pair.battle.artillery},
});
const clock=pair=>({turn:pair.battle.turn,phase:pair.battle.phase,status:pair.battle.status,elapsedSeconds:pair.battle.elapsedSeconds,hour:pair.campaign.hour,secondOfHour:pair.campaign.secondOfHour});
const counts={enterSector:0,nativeTacticalOrders:0,synchronizations:0,encodeSave:0,decodeSave:0,selectors:0,settlements:0};
const events=[];
const receipt={runKind:'exact-earned-stock-san-nicolas-common-13-prefix',scope:'One exact replay of the 13 native tactical orders common to both recorded original route executions. Stop before order 14. No selector, new decision, battle continuation, exploration, aid, campaign wait or settlement.',candidate,pid:process.pid,runtime:process.execPath,nodeVersion:process.version,startedAt:new Date().toISOString(),complete:false,counts,events:[],sourceScope:'Every game/ file; native imports only. Controller test files are not imported or executed.'};
write('initial-receipt.json',receipt);
let beforeSource,pair;
try{
 assert.equal(process.version,'v25.9.0');
 beforeSource=snapshot();write('native-source-before.json',beforeSource);receipt.nativeSourceBeforeSha256=sha(serialize(beforeSource));
 receipt.candidateHead=execFileSync('git',['rev-parse','HEAD'],{cwd:candidate,encoding:'utf8'}).trim();
 receipt.wrapperSha256=sha(readFileSync(fileURLToPath(import.meta.url)));
 const oldEntry=readBound(original,'before-battle-execution.json','7fb5d2f322a75d1956e5ecfba4b7761a798df2b62a8ce184b3356c17f4195ab4');
 const newEntry=readBound(current,'before-battle-execution.json','7fb5d2f322a75d1956e5ecfba4b7761a798df2b62a8ce184b3356c17f4195ab4');
 const oldInitial=readBound(original,'replay-initial-pair.json','8802a07969db33ee1eae19f2304942e669cfb1923114b43bcd93431a8e4a4a92');
 const newInitial=readBound(current,'replay-initial-pair.json','8802a07969db33ee1eae19f2304942e669cfb1923114b43bcd93431a8e4a4a92');
 const oldResult=readBound(original,'native-combat-result.json','ebe3844ab08c46d83f559fc45ee85283ce25ac7492dfdb64ee6a92a519584b4e');
 const newResult=readBound(current,'native-combat-result.json','8f605280868e1a3de034813f6d3619c6448041eec5bf17b10c90695c61ed8c68');
 const oldTape=readBound(original,'accepted-local-tactical-orders.json','10dfcf888228c4e2f6f74c2afb64090136480dfa68d4b3bf2f076b971d9dd683');
 const newTape=readBound(current,'accepted-local-tactical-orders.json','68383b742b77d69bff16f68dc6524f999859dc3d8ae408ad34cdf21803133c09');
 const bounds=[oldEntry,newEntry,oldInitial,newInitial,oldResult,newResult,oldTape,newTape];
 receipt.inputs=bounds.map(({value,...bound})=>bound);write('bound-inputs.json',receipt.inputs);
 assert.deepEqual(oldEntry.value,newEntry.value);assert.deepEqual(oldInitial.value,newInitial.value);
 const orders=oldResult.value.orders.slice(0,13);
 assert.equal(orders.length,13);assert.deepEqual(orders,newResult.value.orders.slice(0,13));
 assert.deepEqual(orders,oldTape.value.slice(0,13).map(record=>record.action));
 assert.deepEqual(orders,newTape.value.slice(0,13).map(record=>record.action));
 assert.notDeepEqual(oldResult.value.orders[13],newResult.value.orders[13]);
 receipt.recordedNextOrder={original:oldResult.value.orders[13],current:newResult.value.orders[13],executed:false};
 write('common-native-orders.json',orders);
 writeFileSync(join(output,'actual-before-battle-execution.json'),readFileSync(newEntry.path));
 writeFileSync(join(output,'actual-recorded-replay-initial-pair.json'),readFileSync(newInitial.path));
 const {enterSector}=await import(pathToFileURL(join(candidate,'game/world.js')));
 const {actBattle,endTurn}=await import(pathToFileURL(join(candidate,'game/tactical.js')));
 const {syncBattleTime}=await import(pathToFileURL(join(candidate,'game/time.js')));
 const {encodeSave,decodeSave}=await import(pathToFileURL(join(candidate,'game/save.js')));
 const {campaign,request,previous}=newEntry.value;
 counts.enterSector++;pair={campaign,battle:enterSector(request,previous)};
 assert.deepEqual(pair,newInitial.value,'native entry is identical to the independently recorded entry');
 const initialIdentity=identity(pair);write('raw-before-values.json',initialIdentity);
 for(let index=0;index<orders.length;index++){
  const action=orders[index],before=identity(pair),beforeClock=clock(pair);
  assert.deepEqual(beforeClock,oldTape.value[index].before);assert.deepEqual(beforeClock,newTape.value[index].before);
  counts.nativeTacticalOrders++;
  const battle=action.type==='endTurn'?endTurn(pair.battle):actBattle(pair.battle,action);
  const event={index,orderNumber:index+1,action,nativeAccepted:battle.lastError===null,before:beforeClock,afterNativeBattleSeed:battle.seed,nativeError:battle.lastError};
  events.push(event);write('accepted-prefix-events.json',events);
  assert.equal(battle.lastError,null,JSON.stringify(action));
  counts.synchronizations++;
  const synced=syncBattleTime(pair.campaign,battle);event.synchronizationError=synced.error;
  assert.equal(synced.error,null,JSON.stringify(action));pair={campaign:synced.campaign,battle:synced.battle};
  event.after=clock(pair);event.synchronizationCompleted=true;
  assert.deepEqual(event.after,oldTape.value[index].after);assert.deepEqual(event.after,newTape.value[index].after);
  write(`order-${String(index+1).padStart(2,'0')}-raw-values.json`,{action,before,after:identity(pair)});write('accepted-prefix-events.json',events);
 }
 assert.equal(counts.nativeTacticalOrders,13);assert.equal(counts.synchronizations,13);
 assert.equal(pair.battle.status,'active');assert.equal(pair.battle.turn,1);assert.equal(pair.battle.phase,'player');
 assert.equal(pair.battle.elapsedSeconds,109);assert.equal(pair.campaign.hour,60);assert.equal(pair.campaign.secondOfHour,798);
 assert.deepEqual(pair.campaign.resources,initialIdentity.campaign.resources);
 assert.deepEqual(pair.campaign.contracts,initialIdentity.campaign.contracts);
 assert.deepEqual(pair.campaign.squad,initialIdentity.campaign.squad);
 write('raw-after-values.json',identity(pair));write('actual-pre-order-14-pair.json',pair);
 const battleBytes=Buffer.from(serialize(pair.battle));writeFileSync(join(output,'actual-pre-order-14-battle.json.gz'),gzipSync(battleBytes,{level:9}));
 counts.encodeSave++;const save=encodeSave(pair.campaign,pair.battle);writeFileSync(join(output,'official-pre-order-14-save.json.gz'),gzipSync(Buffer.from(save),{level:9}));
 counts.decodeSave++;const restored=decodeSave(save);
 assert.deepEqual(restored,pair,'the official save boundary retains the exact earned pair');
 write('official-save-boundary-receipt.json',{encodeSave:1,decodeSave:1,structuralPairEqual:true,rawSaveSha256:sha(save),rawSaveBytes:Buffer.byteLength(save),savedAt:JSON.parse(save).savedAt});
 const afterSource=snapshot();write('native-source-after.json',afterSource);assert.deepEqual(afterSource,beforeSource,'native source cannot drift during the prefix control');
 for(const bound of bounds)assert.equal(sha(readFileSync(bound.path)),bound.sha256,'original input remains immutable');
 receipt.nativeSourceAfterSha256=sha(serialize(afterSource));receipt.sourceDrift=0;
 receipt.initial={seed:newInitial.value.battle.seed,clock:clock(newInitial.value)};
 receipt.final={seed:pair.battle.seed,campaignSeed:pair.campaign.seed,clock:clock(pair),treasury:pair.campaign.resources.treasury,field:pair.battle.units.filter(u=>u.side==='player').map(u=>({id:u.id,hp:u.hp,bleeding:u.bleeding,ap:u.ap,energy:u.energy,loaded:u.loaded,ammo:u.ammo,carriedAmmo:u.carriedAmmo,carriedLoaded:u.carriedLoaded,medkits:u.medkits,inventory:u.inventory,x:u.x,y:u.y,stance:u.stance}))};
 receipt.complete=true;receipt.stoppedBeforeOrder14=true;receipt.originalInputsUnchanged=true;receipt.officialSavePairEqual=true;
}catch(error){
 receipt.failure={name:error.name,message:error.message,stack:error.stack};
 if(pair)write('actual-partial-pair-at-failure.json',pair);
 process.exitCode=1;
}finally{
 receipt.events=events;receipt.finishedAt=new Date().toISOString();receipt.exitCode=process.exitCode??0;
 if(beforeSource){const after=snapshot();write('native-source-after.json',after);receipt.nativeSourceAfterSha256=sha(serialize(after));receipt.sourceDrift=Object.keys(after).filter(path=>after[path]!==beforeSource[path]).length;}
 receipt.artifacts=readdirSync(output).filter(name=>name!=='final-receipt.json').map(name=>{const bytes=readFileSync(join(output,name));return {path:name,bytes:bytes.length,sha256:sha(bytes)};});
 write('final-receipt.json',receipt);
 console.log(JSON.stringify({output,complete:receipt.complete,exitCode:receipt.exitCode,counts,sourceDrift:receipt.sourceDrift,failure:receipt.failure?.message??null}));
}
