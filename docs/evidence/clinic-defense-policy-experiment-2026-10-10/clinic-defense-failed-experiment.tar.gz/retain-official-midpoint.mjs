import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {decodeSave,encodeSave} from './game/save.js';
import {dispatchCampaign} from './game/campaign.js';
import {enterSector} from './game/world.js';
import {actBattle,endTurn} from './game/tactical.js';
import {syncBattleTime} from './game/time.js';
const folder=resolve(process.argv[2]),load=name=>JSON.parse(readFileSync(resolve(folder,name),'utf8')),sha=value=>createHash('sha256').update(value).digest('hex');
const raid=decodeSave(gunzipSync(readFileSync(resolve(folder,'actual-earned-raid.save.json.gz'))).toString()).campaign,request=load('actual-native-request.json'),snapshot=load('actual-native-snapshot.json'),orders=load('actual-native-defense-tape.json'),result=JSON.parse(gunzipSync(readFileSync(resolve(folder,'actual-native-battle-result.json.gz'))).toString()),receipt=load('trial-receipt.json');
const prepared=dispatchCampaign(raid,{type:'respondToEncounter',groupId:raid.pendingEncounter.groupId,choice:'tactical'});assert.equal(prepared.lastError,null);assert.deepEqual(prepared.pendingBattle,request);
let pair=decodeSave(encodeSave(prepared,enterSector(request,snapshot))),midpointRaw;
for(let index=0;index<orders.length;index++){
 const action=orders[index];pair.battle=action.type==='endTurn'?endTurn(pair.battle):actBattle(pair.battle,action);assert.equal(pair.battle.lastError,null);
 if(index===receipt.settlement.midpoint){const synced=syncBattleTime(pair.campaign,pair.battle);assert.equal(synced.error,null);midpointRaw=encodeSave(synced.campaign,synced.battle);pair=decodeSave(midpointRaw);}
}
const actual=syncBattleTime(pair.campaign,pair.battle),expected=syncBattleTime(prepared,result.battle);assert.equal(actual.error,null);assert.equal(expected.error,null);assert.deepEqual(decodeSave(encodeSave(actual.campaign,actual.battle)),decodeSave(encodeSave(expected.campaign,expected.battle)));assert.ok(midpointRaw);
const compressed=gzipSync(midpointRaw);writeFileSync(resolve(folder,'actual-official-midpoint.save.json.gz'),compressed);const proof={scope:'Replay of the already admitted trial tape only; no new battle decision or result rewrite',orders:orders.length,midpoint:receipt.settlement.midpoint,rawSha256:sha(midpointRaw),gzipSha256:sha(compressed),terminalPairMatches:true,status:result.battle.status};writeFileSync(resolve(folder,'actual-official-midpoint-proof.json'),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof));
