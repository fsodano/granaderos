import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {gunzipSync,gzipSync} from 'node:zlib';
import {decodeSave,encodeSave} from './game/save.js';
import {prepareRescueClinicGuards,restRescuePatients,resolveRescueClinicEncounter} from './tests/rescue-clinic-readiness.mjs';
import {prepareRescueClinicGroundCrew,rescueClinicDefenseOrder} from './tests/rescue-clinic-defense-driver.mjs';
import {fight} from './tests/opening-driver.mjs';

const output=resolve(process.argv[2]??'trial-artifacts');mkdirSync(output,{recursive:true});
const sha=value=>createHash('sha256').update(value).digest('hex');
const write=(name,value)=>{const text=typeof value==='string'?value:JSON.stringify(value,null,2)+'\n';writeFileSync(resolve(output,name),text);return {path:resolve(output,name),sha256:sha(text),bytes:Buffer.byteLength(text)};};
const save=(name,campaign)=>{const raw=encodeSave(campaign),compressed=gzipSync(raw);writeFileSync(resolve(output,name),compressed);return {path:resolve(output,name),gzipSha256:sha(compressed),rawSha256:sha(raw),gzipBytes:compressed.length};};
const provenance=JSON.parse(readFileSync(new URL('./tests/fixtures/opening-clinic-earned-exhaustion.provenance.json',import.meta.url),'utf8'));
const fixture=readFileSync(new URL('./tests/fixtures/opening-clinic-earned-exhaustion.save.json.gz',import.meta.url)),raw=gunzipSync(fixture);
assert.equal(sha(fixture),provenance.fixtures['opening-clinic-earned-exhaustion.save.json.gz'].gzipSha256);assert.equal(sha(raw),provenance.fixtures['opening-clinic-earned-exhaustion.save.json.gz'].rawSha256);
const preflight=JSON.parse(readFileSync(process.argv[3],'utf8'));
const initial=decodeSave(raw.toString()).campaign,initialBefore=structuredClone(initial),patients=[121,126,129,130],doctors=[112,122],courier=102;
const receipt={started:new Date().toISOString(),scope:'ONE declared earned clinic policy trial. No seed changes, resource/health/outcome grants or assertion relaxation. Preparation begins at the existing actual finite exhaustion input; original finite long-gun/round staging remains unchanged.',input:{gzipSha256:sha(fixture),rawSha256:sha(raw),hour:initial.hour,second:initial.secondOfHour,treasury:initial.resources.treasury},patients,doctors,courier,executions:0,encounterRequests:0,artifacts:{},checkpoints:[],fullHealth:false,strictVictory:false};
let settled=null,result=null,completed=null,preparation=null,ground=null;
const checkpoint=(name,campaign,evidence)=>{
 receipt.checkpoints.push({name,hour:campaign.hour,second:campaign.secondOfHour,treasury:campaign.resources.treasury});
 if(name==='rescue-clinic-defense'){settled=structuredClone(campaign);receipt.settlement={status:evidence.status,groupId:evidence.groupId,exactNativeReplay:evidence.exactNativeReplay,midpoint:evidence.midpoint,hour:campaign.hour,second:campaign.secondOfHour,owner:campaign.sectors.tucuman.owner,deaths:Object.entries(campaign.operativeState).filter(([id,record])=>initial.operativeState[id]?.alive&&!record.alive).map(([id])=>Number(id)),captives:Object.entries(campaign.operativeState).filter(([id,record])=>record.captured&&!initial.operativeState[id]?.captured).map(([id])=>Number(id))};receipt.artifacts.settled=save('actual-settled.save.json.gz',campaign);receipt.artifacts.defenseEvidence=write('actual-defense-evidence.json',evidence);}
};
try{
 preparation=prepareRescueClinicGuards(initial,{courier});assert.deepEqual(initial,initialBefore);receipt.artifacts.existingPreparation=write('existing-finite-preparation.json',preparation.evidence);
 ground=prepareRescueClinicGroundCrew(preparation.campaign,{ids:preparation.evidence.ids});receipt.artifacts.groundPreparation=write('ground-crew-preparation.json',ground.evidence);receipt.artifacts.prepared=save('actual-ground-prepared.save.json.gz',ground.campaign);
 assert.equal(sha(raw),preflight.inputRawSha256);assert.deepEqual(preparation.evidence.ids,preflight.guardIds);assert.deepEqual(ground.evidence.ids,preflight.groundCrewIds);assert.deepEqual(ground.evidence.positions,preflight.positions);assert.deepEqual(ground.evidence.gun,preflight.gun);assert.equal(ground.evidence.elapsedSeconds,preflight.groundElapsedSeconds);assert.equal(ground.campaign.hour,preflight.hour);assert.equal(ground.campaign.secondOfHour,preflight.second);assert.deepEqual(decodeSave(encodeSave(ground.campaign)),preflight.preparedPair);receipt.preCombatPreparationMatchesIndependentPreflight=true;
 const resolved=restRescuePatients(ground.campaign,{patients,doctors,courier,exhaustedSources:['cordoba'],onCheckpoint:checkpoint,resolveEncounter:(campaign,options)=>{
  receipt.encounterRequests++;assert.equal(receipt.encounterRequests,1,'the declared trial admits one real clinic battle only; a later raid needs separate authorization');
  receipt.artifacts.raid=save('actual-earned-raid.save.json.gz',campaign);
  return resolveRescueClinicEncounter(campaign,{...options,controller:rescueClinicDefenseOrder,executeBattle:(request,snapshot,settings)=>{
   receipt.executions++;assert.equal(receipt.executions,1);assert.equal(settings.controller,rescueClinicDefenseOrder);
   receipt.artifacts.request=write('actual-native-request.json',request);receipt.artifacts.snapshot=write('actual-native-snapshot.json',snapshot);
   result=fight(request,snapshot,settings);receipt.artifacts.tape=write('actual-native-defense-tape.json',result.orders);
   writeFileSync(resolve(output,'actual-native-battle-result.json.gz'),gzipSync(JSON.stringify(result)));receipt.artifacts.battleResult={path:resolve(output,'actual-native-battle-result.json.gz'),gzipSha256:sha(readFileSync(resolve(output,'actual-native-battle-result.json.gz')))};
   receipt.battle={status:result.battle.status,turns:result.battle.turn,actions:result.actions,elapsedSeconds:result.battle.elapsedSeconds,seed:result.battle.seed,units:result.battle.units.map(unit=>({id:unit.id,side:unit.side,hp:unit.hp,energy:unit.energy,bleeding:unit.bleeding,tacticalLevel:unit.tacticalLevel,x:unit.x,y:unit.y,loaded:unit.loaded,ammo:unit.ammo,medkits:unit.medkits,knockedDown:unit.knockedDown,routed:unit.routed})),artillery:result.battle.artillery};
   return result;
  }});
 }});
 completed=resolved.campaign;receipt.strictVictory=receipt.settlement?.status==='victory';receipt.fullHealth=patients.every(id=>completed.operativeState[id].alive&&!completed.operativeState[id].captured&&!completed.operativeState[id].bleeding&&completed.operativeState[id].hp===completed.operativeState[id].maxHp);
 assert.equal(receipt.strictVictory,true);assert.equal(receipt.fullHealth,true);
 receipt.artifacts.completed=save('actual-full-health.save.json.gz',completed);receipt.artifacts.restEvidence=write('actual-rest-recovery.json',resolved.evidence);receipt.outcome='strict victory and actual full-health follow-up passed';
}catch(error){receipt.outcome='retained native failure';receipt.failure={name:error.name,message:error.message,stack:error.stack};receipt.strictVictory=receipt.settlement?.status==='victory';}
receipt.finished=new Date().toISOString();receipt.guardIds=preparation?.evidence.ids;receipt.groundCrewIds=ground?.evidence.ids;receipt.initialUnchanged=JSON.stringify(initial)===JSON.stringify(initialBefore);receipt.inputPreviousDeathsRemain=settled?Object.entries(initial.operativeState).every(([id,record])=>record.alive||settled.operativeState[id].alive===false):null;
write('trial-receipt.json',receipt);console.log(JSON.stringify({output,executions:receipt.executions,outcome:receipt.outcome,battle:receipt.battle?.status,strictVictory:receipt.strictVictory,fullHealth:receipt.fullHealth,failure:receipt.failure?.message,groundCrewIds:receipt.groundCrewIds}));process.exitCode=receipt.strictVictory&&receipt.fullHealth?0:1;
