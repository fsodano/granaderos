import test from 'node:test';
import assert from 'node:assert/strict';
import {createBattle,actBattle,artilleryCosts,canSee} from '../game/tactical.js';
import {validateBattleSnapshot} from '../game/validate-battle.js';
import {rescueClinicDefenseOrder} from './rescue-clinic-defense-driver.mjs';

function field({helperAP=100,roof=false}={}){
 const width=64,height=12,level=roof?1:0,upperSurfaces=[];
 if(roof)for(let y=3;y<=6;y++)for(let x=1;x<=8;x++)upperSurfaces.push({id:`roof:${x}:${y}`,x,y,tacticalLevel:1,elevation:3,type:'floor',kind:'roof',blocked:false,cover:20});
 const state=createBattle([
  {id:'gunner',x:2,y:5,tacticalLevel:level,facing:2,stance:'crouched',movementMode:'crouch',medical:0,medkits:0},
  {id:'helper',x:3,y:4,tacticalLevel:level,facing:2,stance:'crouched',movementMode:'crouch',medical:0,medkits:0},
  {id:'spotter',x:22,y:3,facing:2,medical:0,medkits:0},
 ],{width,height,seed:45,hour:12,tiles:Array.from({length:width*height},(_,i)=>({x:i%width,y:Math.floor(i/width),type:'grass',blocked:false,cover:0})),upperSurfaces,
  enemies:[{id:'contact',x:30,y:5,facing:6,patrol:false,overwatch:false},{id:'hidden',x:58,y:10,patrol:false,overwatch:false}],
  artillery:[{id:'owned',type:'bronze4',side:'player',x:3,y:5,facing:0,loaded:true,ammo:2}],
 });
 state.units.find(unit=>unit.id==='helper').ap=helperAP;return validateBattleSnapshot(state);
}
const gunner=state=>state.units.find(unit=>unit.id==='gunner');

test('declared clinic crew uses the real friendly gun and pays both native crew budgets',()=>{
 const state=field(),before=structuredClone(state),action=rescueClinicDefenseOrder(state,gunner(state));
 assert.equal(action?.type,'artillery');assert.equal(action.artilleryId,'owned');assert.deepEqual(state,before);
 const next=actBattle(state,action);assert.equal(next.lastError,null);assert.equal(next.artillery[0].loaded,false);assert.equal(next.artillery[0].ammo,state.artillery[0].ammo);
 const paid=artilleryCosts(state,gunner(state),state.artillery[0]).fire;
 for(const id of ['gunner','helper'])assert.equal(next.units.find(unit=>unit.id===id).ap,state.units.find(unit=>unit.id===id).ap-paid);
 assert.doesNotThrow(()=>validateBattleSnapshot(next));
});

test('missing crew AP and roof-separated crew cannot issue native gun work',()=>{
 const short=field({helperAP:0}),before=structuredClone(short);assert.notEqual(rescueClinicDefenseOrder(short,gunner(short))?.type,'artillery');assert.deepEqual(short,before);
 const rejected=actBattle(short,{type:'artillery',unitId:'gunner',artilleryId:'owned',x:30,y:5});assert.ok(rejected.lastError);assert.deepEqual(rejected.artillery,short.artillery);assert.deepEqual(rejected.units,short.units);assert.equal(rejected.elapsedSeconds,short.elapsedSeconds);
 const roof=field({roof:true});assert.notEqual(rescueClinicDefenseOrder(roof,gunner(roof))?.artilleryId,'owned');
});

test('unseen enemy positions and private load do not alter the clinic order',()=>{
 const state=field(),hidden=state.units.find(unit=>unit.id==='hidden');assert.equal(state.units.filter(unit=>unit.side==='player').some(unit=>canSee(state,unit,hidden)),false);
 const before=structuredClone(state),changed=structuredClone(state),other=changed.units.find(unit=>unit.id==='hidden');other.x=62;other.y=9;other.loaded=0;other.ammo=0;
 assert.deepEqual(rescueClinicDefenseOrder(changed,gunner(changed)),rescueClinicDefenseOrder(state,gunner(state)));assert.deepEqual(state,before);
});
