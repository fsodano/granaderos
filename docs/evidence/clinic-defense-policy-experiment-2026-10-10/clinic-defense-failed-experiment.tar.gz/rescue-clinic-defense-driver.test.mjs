import test from 'node:test';
import assert from 'node:assert/strict';
import {createBattle,actBattle,artilleryCosts,canSee} from '../game/tactical.js';
import {validateBattleSnapshot} from '../game/validate-battle.js';
import {rescueClinicDefenseOrder,prepareRescueClinicGroundCrew} from './rescue-clinic-defense-driver.mjs';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {decodeSave,encodeSave} from '../game/save.js';
import {prepareRescueClinicGuards} from './rescue-clinic-readiness.mjs';

function field({helperAP=100,roof=false}={}){
 const width=64,height=12,level=roof?1:0,upperSurfaces=[];
 if(roof)for(let y=3;y<=6;y++)for(let x=1;x<=8;x++)upperSurfaces.push({id:`roof:${x}:${y}`,x,y,tacticalLevel:1,elevation:3,type:'floor',kind:'roof',blocked:false,cover:20});
 const state=createBattle([
  {id:'gunner',x:2,y:5,tacticalLevel:level,facing:2,stance:'crouched',movementMode:'crouch',medical:0,medkits:0},
  {id:'helper',x:3,y:4,tacticalLevel:level,facing:2,stance:'crouched',movementMode:'crouch',medical:0,medkits:0},
  {id:'spotter',x:22,y:3,facing:2,medical:0,medkits:0},
 ],{width,height,seed:45,hour:12,tiles:Array.from({length:width*height},(_,i)=>({x:i%width,y:Math.floor(i/width),type:'grass',blocked:false,cover:0})),upperSurfaces,
  enemies:[{id:'contact',x:30,y:5,facing:6,patrol:false,overwatch:false},{id:'hidden',x:58,y:10,patrol:false,overwatch:false}],
  artillery:[{id:'owned',type:'bronze4',side:'player',x:3,y:5,facing:0,loaded:true,ammo:2}],
 });
 state.units.find(unit=>unit.id==='helper').ap=helperAP;return validateBattleSnapshot(state);
}
const gunner=state=>state.units.find(unit=>unit.id==='gunner');

test('declared clinic crew uses the real friendly gun and pays both native crew budgets',()=>{
 const state=field(),before=structuredClone(state),action=rescueClinicDefenseOrder(state,gunner(state));
 assert.equal(action?.type,'artillery');assert.equal(action.artilleryId,'owned');assert.deepEqual(state,before);
 const next=actBattle(state,action);assert.equal(next.lastError,null);assert.equal(next.artillery[0].loaded,false);assert.equal(next.artillery[0].ammo,state.artillery[0].ammo);
 const paid=artilleryCosts(state,gunner(state),state.artillery[0]).fire;
 for(const id of ['gunner','helper'])assert.equal(next.units.find(unit=>unit.id===id).ap,state.units.find(unit=>unit.id===id).ap-paid);
 assert.doesNotThrow(()=>validateBattleSnapshot(next));
});

test('missing crew AP and roof-separated crew cannot issue native gun work',()=>{
 const short=field({helperAP:0}),before=structuredClone(short);assert.notEqual(rescueClinicDefenseOrder(short,gunner(short))?.type,'artillery');assert.deepEqual(short,before);
 const rejected=actBattle(short,{type:'artillery',unitId:'gunner',artilleryId:'owned',x:30,y:5});assert.ok(rejected.lastError);assert.deepEqual(rejected.artillery,short.artillery);assert.deepEqual(rejected.units,short.units);assert.equal(rejected.elapsedSeconds,short.elapsedSeconds);
 const roof=field({roof:true});assert.notEqual(rescueClinicDefenseOrder(roof,gunner(roof))?.artilleryId,'owned');
});

test('unseen enemy positions and private load do not alter the clinic order',()=>{
 const state=field(),hidden=state.units.find(unit=>unit.id==='hidden');assert.equal(state.units.filter(unit=>unit.side==='player').some(unit=>canSee(state,unit,hidden)),false);
 const before=structuredClone(state),changed=structuredClone(state),other=changed.units.find(unit=>unit.id==='hidden');other.x=62;other.y=9;other.loaded=0;other.ammo=0;
 assert.deepEqual(rescueClinicDefenseOrder(changed,gunner(changed)),rescueClinicDefenseOrder(state,gunner(state)));assert.deepEqual(state,before);
});


test('earned finite roof preparation admits real ground contact and an official paired midpoint without combat',t=>{
 const provenance=JSON.parse(readFileSync(new URL('./fixtures/opening-clinic-earned-exhaustion.provenance.json',import.meta.url),'utf8'));
 const compressed=readFileSync(new URL('./fixtures/opening-clinic-earned-exhaustion.save.json.gz',import.meta.url)),raw=gunzipSync(compressed),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
 assert.equal(sha(compressed),provenance.fixtures['opening-clinic-earned-exhaustion.save.json.gz'].gzipSha256);assert.equal(sha(raw),provenance.fixtures['opening-clinic-earned-exhaustion.save.json.gz'].rawSha256);
 const initial=decodeSave(raw.toString()).campaign,before=structuredClone(initial),roofs=prepareRescueClinicGuards(initial,{courier:102}),preparedBefore=structuredClone(roofs.campaign);
 const ground=prepareRescueClinicGroundCrew(roofs.campaign,{ids:roofs.evidence.ids});assert.deepEqual(initial,before);assert.deepEqual(roofs.campaign,preparedBefore);
 assert.equal(ground.evidence.ids.length,2);assert.ok(ground.evidence.positions.every(point=>point.tacticalLevel===0));assert.ok(ground.evidence.orders.some(order=>order.type==='move'&&order.tacticalLevel===0));
 assert.equal(ground.evidence.officialMidpointSave,true);assert.equal(ground.evidence.exactNativeReplay,true);assert.ok(ground.evidence.elapsedSeconds>0);assert.equal(ground.evidence.cost,0);
 assert.deepEqual(ground.campaign.recruited,preparedBefore.recruited);assert.deepEqual(ground.campaign.contracts,preparedBefore.contracts);assert.equal(ground.campaign.resources.treasury,preparedBefore.resources.treasury);
 assert.deepEqual(ground.campaign.sectorStates.tucuman.artillery,preparedBefore.sectorStates.tucuman.artillery);
 for(const [id,record]of Object.entries(preparedBefore.operativeState)){assert.equal(ground.campaign.operativeState[id].medkits,record.medkits);if(!record.alive)assert.equal(ground.campaign.operativeState[id].alive,false);assert.equal(ground.campaign.operativeState[id].captured,record.captured);}
 assert.deepEqual(decodeSave(encodeSave(ground.campaign)).campaign,ground.campaign);
 const fallback=prepareRescueClinicGroundCrew(roofs.campaign,{ids:[roofs.evidence.ids[0]]});assert.deepEqual(fallback.campaign,roofs.campaign);assert.deepEqual(fallback.evidence.ids,[]);assert.equal(fallback.evidence.elapsedSeconds,0);assert.equal(fallback.evidence.cost,0);assert.match(fallback.evidence.reason,/lacks the required capable crew/);
 t.diagnostic(JSON.stringify({scope:'native ground preparation only; no combat or victory claim',groundCrewIds:ground.evidence.ids,positions:ground.evidence.positions,gun:ground.evidence.gun,orders:ground.evidence.orders,payments:ground.evidence.payments,elapsedSeconds:ground.evidence.elapsedSeconds,cost:ground.evidence.cost,officialMidpointSave:true,exactNativeReplay:true,noCapableCrewFallback:fallback.evidence}));
});
