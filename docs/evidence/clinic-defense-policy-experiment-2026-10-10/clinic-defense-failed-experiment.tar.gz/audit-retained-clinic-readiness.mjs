import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {decodeSave,encodeSave} from './game/save.js';
import {dispatchCampaign} from './game/campaign.js';
import {enterSector} from './game/world.js';
import {actBattle,endTurn,firearmShotOptions,teamCanSee,artilleryShotTrace,artilleryCrewPlan,artilleryCosts} from './game/tactical.js';
import {syncBattleTime} from './game/time.js';
import {availableAmmunition} from './game/ammunition-types.js';
const folder=resolve(process.argv[2]),load=name=>JSON.parse(readFileSync(resolve(folder,name),'utf8'));
const raid=decodeSave(gunzipSync(readFileSync(resolve(folder,'actual-earned-raid.save.json.gz'))).toString()).campaign,request=load('actual-native-request.json'),snapshot=load('actual-native-snapshot.json'),orders=load('actual-native-defense-tape.json'),result=JSON.parse(gunzipSync(readFileSync(resolve(folder,'actual-native-battle-result.json.gz'))).toString()),receipt=load('trial-receipt.json');
const prepared=dispatchCampaign(raid,{type:'respondToEncounter',groupId:raid.pendingEncounter.groupId,choice:'tactical'});assert.equal(prepared.lastError,null);assert.deepEqual(prepared.pendingBattle,request);
let pair=decodeSave(encodeSave(prepared,enterSector(request,snapshot)));
const ids=new Set(request.squad.map(unit=>String(unit.id))),ready=unit=>({id:unit.id,hp:unit.hp,maxHp:unit.maxHp,weapon:unit.weapon,loaded:unit.loaded,reserves:unit.ammo,compatibleReserves:availableAmmunition(unit),condition:unit.condition,energy:unit.energy,medical:unit.medical,medkits:unit.medkits,activeSlot:unit.activeSlot,stance:unit.stance,tacticalLevel:unit.tacticalLevel??0,x:unit.x,y:unit.y,ap:unit.ap});
const opening=pair.battle.units.filter(unit=>ids.has(unit.id)).map(ready),openingGun=structuredClone(pair.battle.artillery),knownFireOrders=[],gunTransactions=[];
for(let index=0;index<orders.length;index++){
 const action=orders[index],actor=pair.battle.units.find(unit=>unit.id===action.unitId),view={...pair.battle,units:pair.battle.units.filter(unit=>unit.side==='player'||teamCanSee(pair.battle,'player',unit)),npcs:(pair.battle.npcs??[]).filter(npc=>teamCanSee(pair.battle,'player',npc))};
 if(action.type==='fire'){
  const target=view.units.find(unit=>unit.id===action.targetId),option=target&&firearmShotOptions(view,actor,target,action.aim??0).find(option=>option.aim===(action.aim??0)&&option.hitLocation===(action.hitLocation??'torso'));
  knownFireOrders.push({index,turn:pair.battle.turn,action,teamKnown:Boolean(target),publicOptionPresent:Boolean(option),chance:option?.chance,interveningFriendly:option?.interveningFriendly??null,pairedHandFriendly:option?.shots?.some(shot=>shot.interveningFriendly)??false,knownSafe:Boolean(option&&!option.interveningFriendly&&!option.shots?.some(shot=>shot.interveningFriendly))});
 }
 let gunEntry;
 if(['artillery','artilleryReload','artilleryPivot'].includes(action.type)){
  const gun=pair.battle.artillery.find(gun=>gun.id===action.artilleryId),trace=action.type==='artillery'?artilleryShotTrace(view,actor,gun,action,action.mode??'solid'):null,impacts=trace?.events.filter(event=>event.type==='impact')??[],friendlies=impacts.filter(hit=>hit.victimKind==='npc'||view.units.find(unit=>unit.id===hit.unitId)?.side==='player');
  const cost=action.type==='artillery'?artilleryCosts(pair.battle,actor,gun).fire:0,crew=artilleryCrewPlan(pair.battle,actor,gun,cost);
  gunEntry={index,turn:pair.battle.turn,action,before:structuredClone(gun),crew:crew.crew,crewReason:crew.reason,crewBefore:crew.crew.map(id=>ready(pair.battle.units.find(unit=>unit.id===id))),knownImpacts:impacts,knownFriendlyImpacts:friendlies,knownSafe:action.type==='artillery'?friendlies.length===0:null};gunTransactions.push(gunEntry);
 }
 pair.battle=action.type==='endTurn'?endTurn(pair.battle):actBattle(pair.battle,action);assert.equal(pair.battle.lastError,null);
 if(gunEntry){gunEntry.after=structuredClone(pair.battle.artillery.find(gun=>gun.id===action.artilleryId));gunEntry.crewAfter=gunEntry.crew.map(id=>ready(pair.battle.units.find(unit=>unit.id===id)));}
 if(index===receipt.settlement.midpoint){const synced=syncBattleTime(pair.campaign,pair.battle);assert.equal(synced.error,null);pair=decodeSave(encodeSave(synced.campaign,synced.battle));}
}
const actual=syncBattleTime(pair.campaign,pair.battle),expected=syncBattleTime(prepared,result.battle);assert.equal(actual.error,null);assert.equal(expected.error,null);assert.deepEqual(decodeSave(encodeSave(actual.campaign,actual.battle)),decodeSave(encodeSave(expected.campaign,expected.battle)));
const diagnostic={scope:'Read-only opening and known safe-fire audit of the already retained intended policy tape; no new combat decisions',inputSeed:request.seed,opening,openingGun,preparedGuardIds:receipt.guardIds,localCourierNativeAdmission:ids.has('102'),knownFireOrders,knownFireOrdersAllSafe:knownFireOrders.every(order=>order.knownSafe),gunTransactions,finiteShots:gunTransactions.filter(entry=>entry.action.type==='artillery').length,finiteReloads:gunTransactions.filter(entry=>entry.action.type==='artilleryReload').length,exactTerminalPair:true,status:result.battle.status};writeFileSync(resolve(folder,'opening-readiness-and-known-safe-fire.json'),JSON.stringify(diagnostic,null,2)+'\n');console.log(JSON.stringify({opening,knownFireOrders:knownFireOrders.length,knownFireOrdersAllSafe:diagnostic.knownFireOrdersAllSafe,finiteShots:diagnostic.finiteShots,finiteReloads:diagnostic.finiteReloads,exactTerminalPair:true}));
