import assert from 'node:assert/strict';
import {dispatchCampaign,rosterFor} from '../game/campaign.js';
import {decodeSave,encodeSave} from '../game/save.js';
import {enterSector} from '../game/world.js';
import {syncBattleTime} from '../game/time.js';
import {actBattle,actionCosts,artilleryContact,artilleryCrewPlan,canSee,firearmShotOptions,getReachable,hasLineOfSight,stanceCost,teamCanSee} from '../game/tactical.js';
import {artilleryProfile} from '../game/artillery-definitions.js';
import {sameCell,sameSurface,spacePoint,surfaceAt} from '../game/tactical-space.js';
import {playerKnownBattle} from '../game/player-known-state.js';
import {directionTo} from '../game/tactical-awareness.js';
import {cautiousCombatOrder} from './cautious-driver.mjs';
import {northernClinicDefenseOrder} from './northern-route.mjs';
import {teamArtilleryOrder} from './team-artillery-driver.mjs';

const fit=unit=>unit.hp>=15&&!unit.unconscious&&!unit.asleep&&!unit.knockedDown&&!unit.entangled&&!unit.routed&&!unit.surrendered&&!unit.departure&&!unit.fled&&!unit.mounted&&(unit.energy??100)>10;
const compareId=(a,b)=>String(a.id).localeCompare(String(b.id));
const perceived=battle=>({...battle,units:battle.units.filter(unit=>unit.side==='player'||teamCanSee(battle,'player',unit)),npcs:(battle.npcs??[]).filter(npc=>teamCanSee(battle,'player',npc))});
const targets=battle=>battle.units.filter(unit=>unit.side==='enemy'&&unit.hp>=15&&!unit.unconscious&&!unit.routed&&!unit.surrendered&&!unit.departure&&!unit.fled&&teamCanSee(battle,'player',unit));
const safe=option=>!option.interveningFriendly&&!option.shots?.some(shot=>shot.interveningFriendly);
function shotValue(battle,unit,budget){
 if(!unit.loaded||unit.jammed||unit.weaponDropped)return 0;
 let best=0;
 for(const target of targets(battle)){
  if(!canSee(battle,unit,target))continue;
  const costs=actionCosts(battle,unit,target);if(costs.fire>budget)continue;
  const aim=Math.min(4,Math.floor((budget-costs.fire)/Math.max(1,costs.aim)));
  for(const option of firearmShotOptions(battle,unit,target,aim))if(safe(option))best=Math.max(best,option.chance*option.damageFactor);
 }
 return best;
}
function positionValue(battle,unit,budget){
 const exposure=targets(battle).filter(target=>hasLineOfSight(battle,target,unit)).length;
 return shotValue(battle,unit,budget)+(surfaceAt(battle,unit)?.cover??0)*.8-exposure*10;
}

// Existing finite gun/rifle/round preparation must already be complete. This
// adds only a real local squad and paid descent/contact orders for a real gun.
export function prepareRescueClinicGroundCrew(start,{ids,report=()=>{}}={}){
 assert.ok(ids?.length);let campaign=decodeSave(encodeSave(start)).campaign;
 const sector='tucuman',previous=campaign.activeSquadId,initialSeconds=campaign.hour*3600+(campaign.secondOfHour??0),initialCash=campaign.resources.treasury;
 assert.equal(campaign.pendingBattle,null);assert.equal(campaign.pendingEncounter,null);assert.equal(campaign.sectors[sector].owner,'patriot');
 const guns=(campaign.sectorStates[sector]?.artillery??[]).filter(gun=>gun.side==='player'&&(gun.tacticalLevel??0)===0&&(gun.loaded||gun.ammo>0)).sort(compareId);
 if(!guns.length){const evidence={event:'rescueClinicGroundCrew',sector,ids:[],reason:'No real serviceable local gun.',elapsedSeconds:0};report(evidence);return {campaign,evidence};}
 const gun=structuredClone(guns[0]),required=artilleryProfile(campaign.sectorStates[sector],gun).crew;
 const candidates=rosterFor(campaign).filter(op=>ids.includes(op.id)&&campaign.recruited.includes(op.id)&&campaign.operativeState[op.id].location===sector&&campaign.operativeState[op.id].alive&&!campaign.operativeState[op.id].captured&&!campaign.operativeState[op.id].bleeding&&fit(campaign.operativeState[op.id]));
 // Preserve the physicians as roof infantry when other capable guards exist;
 // use current own health, artillery aptitude and IDs, never enemy data.
 candidates.sort((a,b)=>Number(a.medical>=60)-Number(b.medical>=60)||campaign.operativeState[b.id].hp-campaign.operativeState[a.id].hp||(b.explosives??0)-(a.explosives??0)||compareId(a,b));
 assert.ok(candidates.length>=required,'the real serviceable clinic gun needs its actual capable local crew');
 const crewIds=candidates.slice(0,required).map(op=>op.id),assignments=crewIds.map(id=>({id,assignment:campaign.operativeState[id].assignment})),campaignActions=[];
 const order=action=>{campaign=dispatchCampaign(campaign,action);assert.equal(campaign.lastError,null,JSON.stringify(action)+': '+campaign.lastError);campaignActions.push(structuredClone(action));};
 order({type:'createSquad',name:'Dotación real de la clínica',ids:crewIds,sector});
 for(const operativeId of crewIds)order({type:'assignCare',operativeId,assignment:'active'});
 order({type:'visitSector'});
 const entryCampaign=decodeSave(encodeSave(campaign)).campaign,request=structuredClone(campaign.pendingBattle),snapshot=structuredClone(campaign.sectorStates[sector]);
 let battle=enterSector(request,snapshot);const initialBattle=structuredClone(battle),orders=[],positions=[];
 const knownGun=playerKnownBattle(battle).artillery.find(piece=>piece.id===gun.id);assert.ok(knownGun,'the ordinary visit must disclose the same real friendly clinic gun');
 assert.deepEqual(battle.artillery.find(piece=>piece.id===gun.id),gun);
 const act=action=>{battle=actBattle(battle,action);assert.equal(battle.lastError,null,JSON.stringify(action)+': '+battle.lastError);orders.push(structuredClone(action));};
 for(const id of crewIds){
  const unitId=String(id);act({type:'movement',unitId,movement:'walk'});
  let unit=battle.units.find(unit=>unit.id===unitId);
  if(unit.stance!=='standing')act({type:'stance',unitId,stance:'standing'});
  unit=battle.units.find(unit=>unit.id===unitId);
  const view=perceived(battle),destination=getReachable(view,unit).filter(point=>(point.tacticalLevel??0)===0&&artilleryContact(view,{...unit,...point},gun)).sort((a,b)=>a.cost-b.cost||a.y-b.y||a.x-b.x)[0];
  assert.ok(destination,'the chosen guard needs an ordinary reachable ground contact cell');
  for(let leg=0;!sameCell(battle.units.find(unit=>unit.id===unitId),destination)&&leg<64;leg++){
   const before=spacePoint(battle.units.find(unit=>unit.id===unitId));act({type:'move',unitId,...spacePoint(destination)});assert.notDeepEqual(spacePoint(battle.units.find(unit=>unit.id===unitId)),before);
  }
  unit=battle.units.find(unit=>unit.id===unitId);assert.ok(sameCell(unit,destination));assert.ok(artilleryContact(battle,unit,gun));
  act({type:'stance',unitId,stance:'crouched'});positions.push({id,...spacePoint(battle.units.find(unit=>unit.id===unitId))});
 }
 assert.equal(artilleryCrewPlan(battle,battle.units.find(unit=>unit.id===String(crewIds[0])),gun,0).reason,null);
 assert.deepEqual(battle.artillery.find(piece=>piece.id===gun.id),gun,'preparation cannot change the existing gun, load or reserves');
 // Replay the admitted extra preparation only, with an official campaign save.
 let replay={campaign:entryCampaign,battle:enterSector(request,snapshot)};const midpoint=Math.floor(orders.length/2);
 for(let i=0;i<orders.length;i++){
  replay.battle=actBattle(replay.battle,orders[i]);assert.equal(replay.battle.lastError,null);
  if(i===midpoint){const synced=syncBattleTime(replay.campaign,replay.battle);assert.equal(synced.error,null);replay=decodeSave(encodeSave(synced.campaign,synced.battle));}
 }
 const expected=syncBattleTime(entryCampaign,battle),actual=syncBattleTime(replay.campaign,replay.battle);assert.equal(expected.error,null);assert.equal(actual.error,null);
 assert.deepEqual(decodeSave(encodeSave(actual.campaign,actual.battle)),decodeSave(encodeSave(expected.campaign,expected.battle)));
 campaign=expected.campaign;order({type:'leaveSector',battleId:campaign.pendingBattle.id,sectorState:expected.battle,survivors:expected.battle.units.filter(unit=>unit.side==='player')});
 for(const {id,assignment}of assignments)if(assignment!=='active')order({type:'assignCare',operativeId:id,assignment});
 if(campaign.activeSquadId!==previous)order({type:'selectSquad',id:previous});
 assert.equal(campaign.resources.treasury,initialCash);assert.deepEqual(campaign.contracts,start.contracts);assert.deepEqual(campaign.recruited,start.recruited);
 for(const [id,record]of Object.entries(start.operativeState)){assert.equal(campaign.operativeState[id].medkits,record.medkits);if(!record.alive)assert.equal(campaign.operativeState[id].alive,false);assert.equal(campaign.operativeState[id].captured,record.captured);}
 const evidence={event:'rescueClinicGroundCrew',sector,ids:crewIds,selection:'nonphysicians first, then actual hp, explosives, stable id',gun,positions,orders,campaignActions,midpoint,officialMidpointSave:true,exactNativeReplay:true,elapsedSeconds:campaign.hour*3600+(campaign.secondOfHour??0)-initialSeconds,cost:initialCash-campaign.resources.treasury};
 report(evidence);return {campaign,evidence};
}

// No saved controller jobs, hidden targets, free stance changes or gun issues.
export function rescueClinicDefenseOrder(battle,unit){
 if(unit.knockedDown||unit.entangled)return northernClinicDefenseOrder(battle,unit);
 const view=perceived(battle),normal=northernClinicDefenseOrder(view,unit);
 if(normal?.type==='useItem'||normal?.slot==='medical'||['reload','reprime'].includes(normal?.type))return normal;
 const observed=targets(view),close=observed.some(target=>sameSurface(unit,target)&&Math.hypot(unit.x-target.x,unit.y-target.y)<=2.5);
 const gun=(view.artillery??[]).filter(piece=>piece.side===unit.side&&(piece.loaded||piece.ammo>0)&&artilleryContact(view,unit,piece)&&!artilleryCrewPlan(view,unit,piece,0).reason).sort(compareId)[0];
 if(gun&&!close){
  if(unit.stance==='prone')return unit.ap>=stanceCost(unit,'crouched')?{type:'stance',unitId:unit.id,stance:'crouched'}:null;
  const artillery=teamArtilleryOrder({...view,artillery:[gun]},unit,observed);if(artillery)return artillery;
  if(unit.stance==='standing')return unit.ap>=stanceCost(unit,'crouched')?{type:'stance',unitId:unit.id,stance:'crouched'}:null;
  return null;
 }
 let action=cautiousCombatOrder(view,unit);
 if(action?.type==='fire'){
  const target=view.units.find(target=>target.id===action.targetId),options=target&&firearmShotOptions(view,unit,target,action.aim??0);
  if(!options?.some(option=>option.aim===(action.aim??0)&&option.hitLocation===(action.hitLocation??'torso')&&safe(option)))return null;
 }
 if((unit.tacticalLevel??0)===0)return action;
 if(action?.type==='charge'||action?.type==='climb')return battle.turn>=20&&!observed.length?action:null;
 if(action?.type==='move'){
  const route=getReachable(view,unit,{stopAt:point=>sameCell(point,action)})[0];if(!route)return null;
  const reserve=unit.loaded&&!unit.jammed?actionCosts(view,unit).fire:0;
  const roofOnly=sameSurface(unit,route)&&route.path.every(point=>sameSurface(unit,point)&&point.kind!=='climb');
  if(!roofOnly)return battle.turn>=20&&!observed.length?action:null;
  if(route.cost<=0||route.cost>Math.min(24,unit.ap-reserve)||route.path.length>3)return null;
  const positioned={...unit,...spacePoint(route),weaponReady:false,facing:directionTo(route.path.at(-2)??unit,route)};
  if(positionValue(view,positioned,unit.ap-route.cost)-route.cost*.2<=positionValue(view,unit,unit.ap)+5)return null;
  return action;
 }
 if(action?.type==='stance'&&action.stance==='standing'){
  const cost=stanceCost(unit,'standing'),positioned={...unit,stance:'standing',weaponReady:false};
  if(battle.turn>=20&&!observed.length)return action;
  if(cost>unit.ap||shotValue(view,positioned,unit.ap-cost)<=shotValue(view,unit,unit.ap)+5)return null;
 }
 return action;
}
